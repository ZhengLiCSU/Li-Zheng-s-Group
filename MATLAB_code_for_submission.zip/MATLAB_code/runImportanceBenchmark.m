function summary = runImportanceBenchmark(profile)
%runImportanceBenchmark Independent existing mixture-IS probability baseline.
% Same scale-mixture probability model and the same analytic-node PWL event.
% Also compares a paired finite capacity change; not an mLS/SDM implementation
% or an infinitesimal derivative benchmark.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","study"])} = "study"
end
root = fileparts(mfilename('fullpath'));
oldPath = path;
cleanup = onCleanup(@() path(oldPath));
addpath(root);
nReplicate = 12;
nOuter = 32;
nInner = 32;
nConditional = 256;
if profile=="smoke"
    nReplicate = 2;
    nOuter = 4;
    nInner = 8;
    nConditional = 16;
end
folder = fullfile(root,'results','importance_'+profile);
if ~isfolder(folder)
    mkdir(folder);
end
summary = table();
for name = ["sdof","building"]
    cfg = mrfp.makeConfig(name,"study");
    time = (0:0.01:cfg.duration)';
    estimates = zeros(nReplicate,2,2*(cfg.nMode+1));
    seconds = zeros(nReplicate,2);
    for rep = 1:nReplicate
        % The amplitude and structure are integrated OUTSIDE Gaussian IS.
        outside = mrfp.sampleInputs(nOuter,3,122411+rep);
        values = zeros(nOuter,2*(cfg.nMode+1));
        clockIS = tic;
        for i = 1:nOuter
            operator = mrfp.makeGaussianOperator(cfg,outside(i,1:2),time);
            amplitude = cfg.amplitudeMedian*exp(cfg.amplitudeLogSd*outside(i,3));
            is = mrfp.sampleGaussianUnion(amplitude*operator,nInner,250011+1000*rep+i);
            cause = zeros(nInner,cfg.nMode+1);
            changed = cause;
            for j = 1:nInner
                response = reshape(is.response(:,j),numel(time),cfg.nMode);
                event = mrfp.firstEvent(time,response,1);
                assert(event.cause<=cfg.nMode && event.cause>0, ...
                    'mrfp:BenchmarkCause','Expected a unique first cause in this continuous-input benchmark.');
                cause(j,event.cause) = is.weight(j);
                cause(j,end) = is.weight(j);
                response(:,1) = response(:,1)/1.05;
                eventChanged = mrfp.firstEvent(time,response,1);
                if eventChanged.cause>0 && eventChanged.cause<=cfg.nMode
                    changed(j,eventChanged.cause) = is.weight(j);
                    changed(j,end) = is.weight(j);
                end
            end
            values(i,:) = [mean(cause,1),mean(changed-cause,1)];
        end
        seconds(rep,1) = toc(clockIS);
        estimates(rep,1,:) = mean(values,1);
        clockConditional = tic;
        inputs = mrfp.sampleInputs(nConditional,cfg.nInput,167211+rep);
        values = zeros(nConditional,2*(cfg.nMode+1));
        for i = 1:nConditional
            s = mrfp.makeResponseSeries(cfg,inputs(i,:),zeros(1,cfg.nPathParameter+2));
            demand = mrfp.evaluateSeriesField(s,time);
            r = mrfp.integrateBranches(time,[demand,-demand],[1:cfg.nMode,1:cfg.nMode],s.law);
            base = [r.uniqueCause(end,:),r.failure(end)];
            demand(:,1) = demand(:,1)/1.05;
            rc = mrfp.integrateBranches(time,[demand,-demand],[1:cfg.nMode,1:cfg.nMode],s.law);
            values(i,:) = [base,[rc.uniqueCause(end,:),rc.failure(end)]-base];
        end
        seconds(rep,2) = toc(clockConditional);
        estimates(rep,2,:) = mean(values,1);
        fprintf('%s: independent importance baseline %d/%d\n',name,rep,nReplicate);
    end
    output = summarize(estimates,seconds,cfg.modeNames);
    output.caseName = repmat(name,height(output),1);
    output.nReplicate = repmat(nReplicate,height(output),1);
    writetable(output,fullfile(folder,name+'_comparison.csv'));
    save(fullfile(folder,name+'_comparison.mat'),'cfg','time','estimates','seconds', ...
        'nOuter','nInner','nConditional','nReplicate','output');
    summary = [summary;output]; %#ok<AGROW>
end
writetable(summary,fullfile(folder,'summary.csv'));
disp(summary);
end

function output = summarize(estimates,seconds,names)
nReplicate = size(estimates,1);
names = [names,"system"];
names = [names,"delta5percent_"+names];
nQuantity = numel(names);
data = zeros(2*nQuantity,6);
method = strings(2*nQuantity,1);
quantity = method;
for j = 1:2
    for i = 1:nQuantity
        row = (j-1)*nQuantity+i;
        values = estimates(:,j,i);
        variance = var(values);
        averageSeconds = mean(seconds(:,j));
        % No observed contribution is not evidence of zero sampling error.
        if all(values==0)
            variance = NaN;
        end
        standardError = sqrt(variance/nReplicate);
        data(row,:) = [mean(values),standardError, ...
            tinv(0.975,nReplicate-1)*standardError, ...
            averageSeconds,variance*averageSeconds,nnz(values)];
        methods = ["Gaussian mixture IS (existing)","Marked amplitude integration"];
        method(row) = methods(j);
        quantity(row) = names(i);
    end
end
output = [table(method,quantity),array2table(data,'VariableNames', ...
    {'estimate','standardError','approximate95HalfWidth','secondsPerReplicate', ...
    'replicateVarianceTimesSeconds','nonzeroReplicates'})];
end
