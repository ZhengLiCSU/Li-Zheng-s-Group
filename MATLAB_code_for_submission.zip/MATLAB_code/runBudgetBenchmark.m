function output = runBudgetBenchmark(profile)
%runBudgetBenchmark Multi-budget comparison of identical probability/score tasks.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","study"])} = "study"
end
root = fileparts(mfilename('fullpath')); oldPath = path;
cleanup = onCleanup(@() path(oldPath)); addpath(root);
budgets = [64,128,256]; nReplicate = 16; nReference = 1024; nReferenceRep = 16;
dt = 0.01; nInner = 32;
if profile=="smoke"
    budgets = [8,16]; nReplicate = 2; nReference = 16; nReferenceRep = 2;
    dt = 0.04; nInner = 8;
end
folder = fullfile(root,'results','budget_'+profile);
if ~isfolder(folder), mkdir(folder); end
methods = ["conditional","mixture_is","direct_mc"];
output = table();
for name = ["sdof","building"]
    cfg = mrfp.makeConfig(name,"study"); time = (0:dt:cfg.duration)';
    nQuantity = 3*(cfg.nMode+2);
    reference = zeros(nReferenceRep,nQuantity);
    referenceSeconds = zeros(nReferenceRep,1);
    for rep = 1:nReferenceRep
        r = mrfp.reliabilityBatch(cfg,time,nReference,2100011+rep,"conditional");
        reference(rep,:) = r.estimate; referenceSeconds(rep) = r.seconds;
        fprintf('%s: independent budget reference %d/%d\n',name,rep,nReferenceRep);
    end
    estimates = zeros(nReplicate,numel(methods),numel(budgets),nQuantity);
    seconds = zeros(nReplicate,numel(methods),numel(budgets));
    for b = 1:numel(budgets)
        count = [budgets(b),max(2,budgets(b)/8),4*budgets(b)];
        for rep = 1:nReplicate
            % Rotate evaluation order to reduce a fixed warm-up/order bias.
            order = circshift(1:numel(methods),mod(rep-1,numel(methods)));
            for j = order
                r = mrfp.reliabilityBatch(cfg,time,count(j),2200011+10000*b+100*j+rep,methods(j),nInner);
                estimates(rep,j,b,:) = r.estimate;
                seconds(rep,j,b) = r.seconds;
            end
        end
        fprintf('%s: all %d replicates at nominal budget %d finished\n',name,nReplicate,budgets(b));
    end
    names = r.names;
    report = summarize(estimates,seconds,reference,budgets,methods,names,name);
    output = [output;report]; %#ok<AGROW>
    writetable(report,fullfile(folder,name+'_budget.csv'));
    save(fullfile(folder,name+'_budget.mat'),'cfg','time','budgets','methods','nInner', ...
        'nReference','nReferenceRep','reference','referenceSeconds','estimates','seconds','report');
    writeFigure(report,fullfile(folder,name+'_budget.png'),name);
end
writetable(output,fullfile(folder,'summary.csv'));
end

function report = summarize(values,seconds,reference,budgets,methods,names,name)
report = table(); n = size(values,1);
referenceMean = mean(reference,1); referenceSE = std(reference,0,1)/sqrt(size(reference,1));
for b = 1:numel(budgets)
    for j = 1:numel(methods)
        for k = 1:numel(names)
            sample = values(:,j,b,k); variance = var(sample);
            nonzero = nnz(sample);
            status = "estimated";
            if nonzero==0, variance = NaN; status = "unresolved_zero";
            elseif nonzero<4, status = "sparse"; end
            se = sqrt(variance/n); cost = mean(seconds(:,j,b));
            % Reference is an independent estimate, never an exact truth.
            rmsToReference = sqrt(mean((sample-referenceMean(k)).^2));
            row = table(name,methods(j),budgets(b),names(k),mean(sample),se, ...
                tinv(0.975,n-1)*se,cost,variance*cost,referenceMean(k),referenceSE(k), ...
                rmsToReference,nonzero,status, ...
                'VariableNames',{'caseName','method','nominalBudget','quantity','estimate', ...
                'standardError','approximate95HalfWidth','secondsPerReplicate', ...
                'replicateVarianceTimesSeconds','referenceEstimate','referenceStandardError', ...
                'rmsDistanceToEstimatedReference','nonzeroReplicates','status'});
            report = [report;row]; %#ok<AGROW>
        end
    end
end
end

function writeFigure(report,file,name)
fig = figure('Visible','off','Color','w','Position',[100,100,1100,440]);
cleanup = onCleanup(@() close(fig)); tiledlayout(1,2,'Padding','compact');
for quantity = ["system","d_log_stiffness__system"]
    nexttile; hold on;
    for method = ["conditional","mixture_is","direct_mc"]
        selected = report.method==method & report.quantity==quantity;
        loglog(report.secondsPerReplicate(selected),report.standardError(selected),'-o', ...
            'DisplayName',method,'LineWidth',1.3);
    end
    set(gca,'XScale','log','YScale','log'); grid on;
    xlabel('Seconds per replicate'); ylabel('SE of mean over 16 replicates');
    title(name+": "+quantity,'Interpreter','none'); legend('Location','best','Interpreter','none');
end
exportgraphics(fig,file,'Resolution',180);
end
