function output = runSensitivityAudit(profile)
%runSensitivityAudit Recompute dynamics at both signs of several design steps.
% Compare to exact finite density reweighting, and separately to the score.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","study"])} = "study"
end
root = fileparts(mfilename('fullpath')); oldPath = path;
cleanup = onCleanup(@() path(oldPath)); addpath(root);
n = 128; nReplicate = 16; steps = [0.04,0.02,0.01]; dt = 0.01;
if profile=="smoke", n = 4; nReplicate = 2; steps = [0.04,0.02]; dt = 0.04; end
folder = fullfile(root,'results','sensitivity_'+profile);
if ~isfolder(folder), mkdir(folder); end
output = table();
for name = ["sdof","building"]
    cfg = mrfp.makeConfig(name,"study"); time = (0:dt:cfg.duration)';
    nCategory = cfg.nMode+2;
    score = zeros(nCategory,2,nReplicate);
    density = zeros(nCategory,2,numel(steps),nReplicate); dynamic = density;
    seconds = zeros(nReplicate,1); conservation = 0;
    for rep = 1:nReplicate
        timer = tic;
        random = mrfp.sampleInputs(n,cfg.nInput,3100111+rep);
        base = mrfp.conditionalBatch(cfg,time,random);
        % E[score]=E[density difference]=0; subtract the known constant safe
        % baseline. This enforces sum of all category derivatives = 0.
        centered = base.probability; centered(:,end) = centered(:,end)-1;
        sd = [cfg.stiffnessLogSd,cfg.dampingLogSd];
        score(:,:,rep) = mrfp.scoreSensitivity(centered,random(:,1:2),sd,ones(n,1)/n);
        for k = 1:numel(steps)
            weight = mrfp.gaussianLocationDifference(random(:,1:2),sd,steps(k));
            density(:,:,k,rep) = centered'*weight/n;
            for j = 1:2
                design = zeros(1,cfg.nPathParameter+2); design(j) = steps(k);
                plus = mrfp.conditionalBatch(cfg,time,random,design);
                minus = mrfp.conditionalBatch(cfg,time,random,-design);
                dynamic(:,j,k,rep) = mean(plus.probability-minus.probability,1)'/(2*steps(k));
            end
        end
        conservation = max(conservation,max(abs(sum(dynamic(:,:,:,rep),1)),[],'all'));
        seconds(rep) = toc(timer);
        fprintf('%s: direct dynamics sensitivity audit %d/%d\n',name,rep,nReplicate);
    end
    report = summarize(cfg,steps,score,density,dynamic);
    output = [output;report]; %#ok<AGROW>
    writetable(report,fullfile(folder,name+'_sensitivity.csv'));
    save(fullfile(folder,name+'_sensitivity.mat'),'cfg','time','n','nReplicate', ...
        'steps','score','density','dynamic','seconds','conservation','report');
    mrfp.writeSensitivityAuditFigure(report,fullfile(folder,name+'_sensitivity.png'),cfg);
end
writetable(output,fullfile(folder,'summary.csv'));
end

function report = summarize(cfg,steps,score,density,dynamic)
nReplicate = size(score,3); names = [cfg.modeNames,"joint","safe"];
parameters = ["log_stiffness","log_damping"]; report = table();
critical = tinv(0.975,nReplicate-1);
familyCritical = tinv(1-0.05/(2*numel(names)*2*numel(steps)),nReplicate-1);
for k = 1:numel(steps)
    for j = 1:2
        for i = 1:numel(names)
            s = squeeze(score(i,j,:)); d = squeeze(dynamic(i,j,k,:));
            r = squeeze(density(i,j,k,:)); difference = d-r;
            pairSE = std(difference)/sqrt(nReplicate);
            flag = "estimated";
            if max(abs([s;d;r]))<1e-12, flag = "roundoff_scale"; end
            row = table(cfg.caseName,names(i),parameters(j),steps(k),mean(s), ...
                critical*std(s)/sqrt(nReplicate),mean(d),critical*std(d)/sqrt(nReplicate), ...
                mean(r),mean(difference),pairSE,critical*pairSE,familyCritical*pairSE, ...
                mean(r-s),flag,'VariableNames',{'caseName','category','parameter','step', ...
                'scoreEstimate','score95HalfWidth','dynamicDifference','dynamic95HalfWidth', ...
                'densityDifference','pairedDynamicMinusDensity','pairedStandardError', ...
                'paired95HalfWidth','pairedFamily95HalfWidth','densityMinusScore','status'});
            report = [report;row]; %#ok<AGROW>
        end
    end
end
end
