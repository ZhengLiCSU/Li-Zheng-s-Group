function summary = runBuilding16Study(profile)
%runBuilding16Study Validate the cited 16-story model and its 16 first causes.
% Existing three-story result directories are retained as historical results.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","study"])} = "study"
end
root = fileparts(mfilename('fullpath'));
oldPath = path; cleanup = onCleanup(@() path(oldPath));
addpath(root);
cfg = mrfp.makeBuilding16Config("study");
n = 128; nReplicate = 16; nMC = 1024;
if profile=="smoke", n = 4; nReplicate = 2; nMC = 16; end
folder = fullfile(root,'results','building16_nf'+string(cfg.nFrequency)+'_'+profile);
if ~isfolder(folder), mkdir(folder); end
time = (0:cfg.dt:cfg.duration)';
design = zeros(1,cfg.nPathParameter+2);
nCategory = cfg.nMode+2;
categoryNames = [cfg.modeNames,"joint","safe"];
probabilityRep = zeros(nReplicate,nCategory);
everRep = zeros(nReplicate,cfg.nMode);
weakRep = zeros(nCategory,2,nReplicate);
curveRep = zeros(numel(time),nReplicate);
transportRep = zeros(nCategory,nCategory,nReplicate);
mcRep = zeros(nReplicate,nCategory);
seconds = zeros(nReplicate,2);
capacityFactor = 1.2;
timeAudit = zeros(nReplicate,5);
maxMarginalError = 0;
for rep = 1:nReplicate
    mainTimer = tic;
    inputs = mrfp.sampleInputs(n,cfg.nInput,619001+rep);
    q = zeros(n,nCategory);
    for k = 1:n
        series = mrfp.makeResponseSeries(cfg,inputs(k,:),design);
        demand = mrfp.evaluateSeriesField(series,time);
        before = mrfp.integrateBranches(time,[demand,-demand], ...
            [1:cfg.nMode,1:cfg.nMode],series.law,StorePartition=true);
        q(k,:) = [before.uniqueCause(end,:),before.joint(end),1-before.failure(end)];
        curveRep(:,rep) = curveRep(:,rep)+before.failure/n;
        record = max(abs(demand),[],1);
        marginal = 0.5*erfc(-(log(max(record,realmin))+series.law.mu)/(sqrt(2)*series.law.sigma));
        everRep(rep,:) = everRep(rep,:)+marginal/n;
        changed = demand; changed(:,1) = changed(:,1)/capacityFactor;
        after = mrfp.integrateBranches(time,[changed,-changed], ...
            [1:cfg.nMode,1:cfg.nMode],series.law,StorePartition=true);
        paired = mrfp.transportPartitions(before.partition,after.partition,series.law,nCategory);
        transportRep(:,:,rep) = transportRep(:,:,rep)+paired.matrix/n;
        afterQ = [after.uniqueCause(end,:),after.joint(end),1-after.failure(end)];
        maxMarginalError = max([maxMarginalError;abs(paired.beforeMarginal-q(k,:)'); ...
            abs(paired.afterMarginal-afterQ')]);
        if k==1
            timeAudit(rep,:) = auditTime(series,time,before);
        end
    end
    probabilityRep(rep,:) = mean(q,1);
    centered = q; centered(:,end) = centered(:,end)-1;
    weakRep(:,:,rep) = mrfp.scoreSensitivity(centered,inputs(:,1:2), ...
        [cfg.stiffnessLogSd,cfg.dampingLogSd],ones(n,1)/n);
    seconds(rep,1) = toc(mainTimer);
    mcTimer = tic;
    mcInput = mrfp.sampleInputs(nMC,cfg.nInput+1,719001+rep,"mc");
    counts = zeros(1,nCategory);
    for k = 1:nMC
        series = mrfp.makeResponseSeries(cfg,mcInput(k,1:end-1),design);
        demand = mrfp.evaluateSeriesField(series,time);
        amplitude = cfg.amplitudeMedian*exp(cfg.amplitudeLogSd*mcInput(k,end));
        event = mrfp.firstEvent(time,demand,amplitude);
        category = event.cause;
        if category==0, category = nCategory; end
        counts(category) = counts(category)+1;
    end
    mcRep(rep,:) = counts/nMC;
    seconds(rep,2) = toc(mcTimer);
    fprintf('16-story: %d/%d independent replicates complete.\n',rep,nReplicate);
end
critical = tinv(0.975,nReplicate-1);
probability = mean(probabilityRep,1);
halfWidth = critical*std(probabilityRep,0,1)/sqrt(nReplicate);
mcProbability = mean(mcRep,1);
mcHalfWidth = critical*std(mcRep,0,1)/sqrt(nReplicate);
z = norminv(0.975); totalMC = nMC*nReplicate;
wilsonCenter = (mcProbability+z^2/(2*totalMC))/(1+z^2/totalMC);
wilsonRadius = z*sqrt(mcProbability.*(1-mcProbability)/totalMC+z^2/(4*totalMC^2))/(1+z^2/totalMC);
probabilityTable = table(categoryNames',probability',halfWidth',mcProbability', ...
    (wilsonCenter-wilsonRadius)',(wilsonCenter+wilsonRadius)',all(probabilityRep==0,1)', ...
    'VariableNames',{'category','conditional','approximate95HalfWidth','directMC', ...
    'mcWilson95Lower','mcWilson95Upper','noConditionalContributionObserved'});
writetable(probabilityTable,fullfile(folder,'probabilities.csv'));
gradient = mean(weakRep,3); gradientHalf = critical*std(weakRep,0,3)/sqrt(nReplicate);
[category,parameter] = ndgrid(categoryNames,["log_stiffness","log_damping"]);
writetable(table(category(:),parameter(:),gradient(:),gradientHalf(:), ...
    'VariableNames',{'category','parameter','scoreDerivative','approximate95HalfWidth'}), ...
    fullfile(folder,'sensitivities.csv'));
transport = mean(transportRep,3);
transportHalf = critical*std(transportRep,0,3)/sqrt(nReplicate);
[from,to] = ndgrid(categoryNames,categoryNames);
writetable(table(from(:),to(:),transport(:),transportHalf(:), ...
    'VariableNames',{'from','to','probability','approximate95HalfWidth'}),fullfile(folder,'transport.csv'));
frequency = sqrt(sort(eig(cfg.stiffness,cfg.mass)))/(2*pi);
parameterTable = table((1:16)',cfg.storyMass',cfg.storyStiffness',cfg.storyHeight', ...
    cfg.thresholds',frequency,'VariableNames',{'story','massKg','stiffnessNperM', ...
    'heightM','driftLimit','orderedModalFrequencyHz'});
writetable(parameterTable,fullfile(folder,'model_parameters.csv'));
writetable(array2table(timeAudit,'VariableNames',{'coarsePf','halfStepPf', ...
    'systemTimeWidth','causeUnresolvedMass','finePWLBoundViolation'}),fullfile(folder,'time_audit.csv'));
rescuedRep = squeeze(transportRep(1,end,:));
substituteRep = squeeze(sum(transportRep(1,2:end-1,:),2));
summary = struct('caseName',cfg.caseName,'nStory',16,'nMode',cfg.nMode, ...
    'nInput',cfg.nInput,'nFrequency',cfg.nFrequency,'nPerReplicate',n, ...
    'nReplicate',nReplicate,'nMCPerReplicate',nMC,'dt',cfg.dt, ...
    'systemFailure',1-probability(end),'systemHalfWidth',halfWidth(end), ...
    'mcFailure',1-mcProbability(end),'mcHalfWidth',mcHalfWidth(end), ...
    'firstStoryShare',probability(1)/max(realmin,1-probability(end)), ...
    'capacityFactor',capacityFactor,'rescued',mean(rescuedRep), ...
    'rescuedHalfWidth',critical*std(rescuedRep)/sqrt(nReplicate), ...
    'substituted',mean(substituteRep), ...
    'substitutedHalfWidth',critical*std(substituteRep)/sqrt(nReplicate), ...
    'marginalError',maxMarginalError,'frequencyHz',frequency(1:5)', ...
    'publishedFrequencyMaxDifference',max(abs(frequency(1:5)'-cfg.publishedFrequencyHz)), ...
    'meanSelectedCauseUnresolved',mean(timeAudit(:,4)), ...
    'maxSelectedTimeViolation',max(timeAudit(:,5)), ...
    'secondsMain',sum(seconds(:,1)),'secondsMC',sum(seconds(:,2)), ...
    'scope',"PWL probability and log-location gradients; selected-path time audit only; " + ...
    "capacity change modifies a criterion, not physical stiffness.");
save(fullfile(folder,'study.mat'),'cfg','summary','time','probabilityRep','everRep', ...
    'weakRep','curveRep','transportRep','mcRep','seconds','timeAudit');
file = fopen(fullfile(folder,'summary.json'),'w','n','UTF-8');
fileCleanup = onCleanup(@() fclose(file));
fprintf(file,'%s',jsonencode(summary,'PrettyPrint',true));
drawResults(folder,cfg,time,curveRep,probabilityRep,everRep,transport,critical,summary);
disp(summary);
end

function audit = auditTime(series,time,before)
trajectory = mrfp.evaluateResponseSeries(series,time);
bounds = mrfp.boundFirstCause(time,trajectory.demand,trajectory.radius,series.law);
fineTime = (time(1):(time(2)-time(1))/2:time(end))';
fine = mrfp.evaluateSeriesField(series,fineTime);
nMode = size(fine,2);
event = mrfp.integrateBranches(fineTime,[fine,-fine],[1:nMode,1:nMode],series.law);
violation = max([0,bounds.lower(end,:)-event.uniqueCause(end,:), ...
    event.uniqueCause(end,:)-bounds.upper(end,:)]);
audit = [before.failure(end),event.failure(end), ...
    bounds.failureUpper(end)-bounds.failureLower(end),bounds.unresolvedMassUpper(end),violation];
end

function drawResults(folder,cfg,time,curves,q,ever,transport,critical,summary)
fig = figure('Visible','off','Color','w','Position',[60,60,1250,800]);
cleanup = onCleanup(@() close(fig));
tiledlayout(2,2,'Padding','compact');
nexttile;
mu = mean(curves,2); band = critical*std(curves,0,2)/sqrt(size(curves,2));
fill([time;flipud(time)],[max(0,mu-band);flipud(min(1,mu+band))],[0.8,0.88,1], ...
    'EdgeColor','none','DisplayName','Pointwise approximate 95% interval'); hold on;
plot(time,mu,'b-','LineWidth',1.5,'DisplayName','Conditional integration');
errorbar(time(end),summary.mcFailure,summary.mcHalfWidth,'ko','DisplayName','Independent MC');
xlabel('Time (s)'); ylabel('System first-passage probability'); grid on; legend('Location','northwest');
nexttile;
bar(1:16,[mean(ever,1)',mean(q(:,1:16),1)']);
xlabel('Story'); ylabel('Probability'); xticks(1:16); grid on;
legend('Ever exceeded','First cause'); title('The same drift limit at all stories');
nexttile;
flow = transport; flow(1:size(flow,1)+1:end) = 0;
imagesc(flow); axis square; colorbar;
labels = ["D"+string(1:16),"J","S"];
xticks(1:18); yticks(1:18); xticklabels(labels); yticklabels(labels); xtickangle(90);
xlabel('After capacity change'); ylabel('Before capacity change');
title('Off-diagonal transport: story 1 capacity +20%');
nexttile;
bar([summary.rescued,summary.substituted]); hold on;
errorbar(1:2,[summary.rescued,summary.substituted], ...
    [summary.rescuedHalfWidth,summary.substitutedHalfWidth],'k.');
xticks(1:2); xticklabels({'Failure prevented','First cause changed'}); ylabel('Probability mass'); grid on;
sgtitle('16-story elastic benchmark: 16 interstory drift criteria');
exportgraphics(fig,fullfile(folder,cfg.caseName+'_overview.png'),'Resolution',180);
print(fig,fullfile(folder,cfg.caseName+'_overview.svg'),'-dsvg');
end
