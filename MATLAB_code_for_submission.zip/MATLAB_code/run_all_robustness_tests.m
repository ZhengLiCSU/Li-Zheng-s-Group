function run_all_robustness_tests(stage)
%run_all_robustness_tests Reproduce version-2 evidence in a clean MATLAB session.
% Usage: matlab -batch "run_all_robustness_tests". Individual restartable
% stages: exact, balanced, audit_sdof, audit_building16, benchmark, verify.
% Publication figures require separate Python scripts and an explicit
% "figures" stage; "all" runs the numerical stages and regression tests.
arguments
    stage (1,1) string = "all"
end
root = fileparts(mfilename('fullpath'));
oldPath = path;
cleanup = onCleanup(@() path(oldPath));
addpath(root,fullfile(root,'code','robustness'));
folder = fullfile(root,'results','robustness_v2');
if ~isfolder(folder), mkdir(folder); end
protocol = robustnessConfig();
writeJson(fullfile(folder,'preregistered_protocol.json'),protocol);
started = datetime('now',TimeZone='UTC');
timer = tic;
fprintf('MATLAB %s / %s / %s / stage %s\n',version,computer,string(started),stage);
if stage=="all" || stage=="exact"
    run_exact_partition_test(protocol,folder);
end
if stage=="all" || stage=="balanced"
    run_balanced_competing_cause_test(protocol,folder);
end
if stage=="all" || stage=="balanced_grid"
    run_balanced_grid_check(protocol,folder);
end
if stage=="all" || stage=="balanced_confirmation"
    run_balanced_confirmation(protocol,folder);
end
if stage=="all" || stage=="audit_sdof"
    run_global_resolution_audit(protocol,folder,"sdof");
end
if stage=="all" || stage=="audit_building16"
    run_global_resolution_audit(protocol,folder,"building16");
end
if stage=="all" || stage=="production_labels"
    run_nominal_transfer_audit(protocol,folder,"sdof");
    run_nominal_transfer_audit(protocol,folder,"building16");
end
if stage=="all" || stage=="audit_tail"
    run_capped_path_followup(protocol,folder);
end
if stage=="all" || stage=="benchmark"
    run_transfer_benchmark(protocol,folder);
end
if stage=="all" || stage=="verify"
    tests = runtests(fullfile(root,'tests'));
    writetable(table(tests),fullfile(folder,'test_results.csv'));
    assert(all([tests.Passed]),'v2:Tests','A regression test failed or was incomplete.');
end
if stage=="figures"
    assert(isfile(fullfile(root,'manuscript','final','build_robustness_figures.py')), ...
        'mrfp:MissingPlotScripts', ...
        'Publication-figure scripts are not included in the public source archive.');
    exportRobustnessFigures(root,folder);
end
manifest = struct('stage',stage,'startedUTC',string(started), ...
    'completedUTC',string(datetime('now',TimeZone='UTC')),'seconds',toc(timer), ...
    'matlab',version,'computer',computer,'toolboxes',{ver},'protocol',protocol, ...
    'fileHashes',hashRobustnessFiles(string(root)));
writeJson(fullfile(folder,'run_manifest_'+stage+'.json'),manifest);
end
