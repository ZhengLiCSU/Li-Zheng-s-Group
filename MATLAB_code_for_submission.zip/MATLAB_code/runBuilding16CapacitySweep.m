function summary = runBuilding16CapacitySweep(profile)
%runBuilding16CapacitySweep Paired 16-story first-story capacity intervention.
% The same 4096 production outer inputs are used at every multiplier. The
% conditional partition estimates use the retained audit inputs; an
% independent direct-MC cohort supplies binomial intervals for the same
% categories. The multiplier changes only the first-story criterion limit.
arguments
    profile (1,1) string {mustBeMember(profile,["study","smoke"])} = "study"
end
root = fileparts(mfilename('fullpath'));
oldPath = path; cleanup = onCleanup(@() path(oldPath)); addpath(root);
cfg = mrfp.makeBuilding16Config("study");
folder = fullfile(root,'results','robustness_v2');
if ~isfolder(folder), mkdir(folder); end
factors = [1.00,1.05,1.10,1.20,1.40];
if profile=="smoke", factors=[1.00,1.20,1.40]; end
batchFiles = dir(fullfile(folder,'building16_audit_batch_*.mat'));
generatedInputs = {};
if isempty(batchFiles)
    if profile=="smoke"
        % Keep the smoke entry point portable: production studies use the
        % retained audit batches, whereas the smoke profile creates two tiny
        % deterministic batches locally.
        generatedInputs = {mrfp.sampleInputs(4,cfg.nInput,619001), ...
                           mrfp.sampleInputs(4,cfg.nInput,619002)};
        nGenerated = numel(generatedInputs);
    else
        error('mrfp:MissingAuditInputs','Study profile requires building16_audit_batch_*.mat. Run run_all_robustness_tests("audit_building16") first.');
    end
elseif profile=="smoke"
    batchFiles=batchFiles(1:min(2,numel(batchFiles)));
    nGenerated = 0;
else
    nGenerated = 0;
end
time = (0:cfg.dt:cfg.duration)';
nCategory = cfg.nMode+2;
categoryNames = [cfg.modeNames,"joint","safe"];
nBatch = max(nGenerated,numel(batchFiles)); nOuter = zeros(nBatch,1);
assert(nBatch>=2,'mrfp:InsufficientBatches', ...
    'At least two independent batches are required for batch-t intervals.');
if nGenerated>0
    inputProvenance=struct('conditionalSource','generated smoke inputs', ...
        'conditionalSeeds',[619001,619002],'direct',819321);
else
    inputProvenance=struct('conditionalSource','retained audit inputs', ...
        'conditionalBatchFiles',{string({batchFiles.name})},'direct',819321);
end
conditional = zeros(nBatch,numel(factors),nCategory);
transfer = zeros(nBatch,numel(factors),nCategory,nCategory);
responseEvaluations = 0; partitionEvaluations = 0; t0=tic;
for b=1:nBatch
    if nGenerated>0
        inputs = generatedInputs{b};
    else
        load(fullfile(batchFiles(b).folder,batchFiles(b).name),'inputs');
    end
    nOuter(b)=size(inputs,1); assert(size(inputs,2)==cfg.nInput);
    for k=1:nOuter(b)
        series=mrfp.makeResponseSeries(cfg,inputs(k,:),zeros(1,cfg.nPathParameter+2));
        demand=mrfp.evaluateSeriesField(series,time); responseEvaluations=responseEvaluations+1;
        labels=[1:cfg.nMode,1:cfg.nMode];
        before=mrfp.integrateBranches(time,[demand,-demand],labels,series.law,StorePartition=true);
        q0=[before.uniqueCause(end,:),before.joint(end),1-before.failure(end)];
        for j=1:numel(factors)
            if factors(j)==1
                conditional(b,j,:)=conditional(b,j,:)+reshape(q0,1,1,nCategory);
                transfer(b,j,:,:)=transfer(b,j,:,:)+reshape(eye(nCategory),1,1,nCategory,nCategory).*reshape(q0,1,1,1,nCategory);
            else
                changed=demand; changed(:,1)=changed(:,1)/factors(j);
                after=mrfp.integrateBranches(time,[changed,-changed],labels,series.law,StorePartition=true);
                qa=[after.uniqueCause(end,:),after.joint(end),1-after.failure(end)];
                paired=mrfp.transportPartitions(before.partition,after.partition,series.law,nCategory);
                conditional(b,j,:)=conditional(b,j,:)+reshape(qa,1,1,nCategory);
                transfer(b,j,:,:)=transfer(b,j,:,:)+reshape(paired.matrix,1,1,nCategory,nCategory);
                partitionEvaluations=partitionEvaluations+1;
            end
        end
    end
    conditional(b,:,:)=conditional(b,:,:)/nOuter(b);
    transfer(b,:,:,:)=transfer(b,:,:,:)/nOuter(b);
    fprintf('16-story capacity sweep: batch %d/%d complete.\n',b,nBatch);
end
% Independent direct cohort: one response evaluation per input, five labels
% classified with the same amplitude and common random input.
nDirect=4096; if profile=="smoke", nDirect=256; end
directInputs=mrfp.sampleInputs(nDirect,cfg.nInput+1,819321,"mc");
directCounts=zeros(numel(factors),nCategory); directResponseEvaluations=0; td=tic;
for k=1:nDirect
    series=mrfp.makeResponseSeries(cfg,directInputs(k,1:end-1),zeros(1,cfg.nPathParameter+2));
    demand=mrfp.evaluateSeriesField(series,time); directResponseEvaluations=directResponseEvaluations+1;
    amplitude=cfg.amplitudeMedian*exp(cfg.amplitudeLogSd*directInputs(k,end));
    for j=1:numel(factors)
        changed=demand; changed(:,1)=changed(:,1)/factors(j);
        event=mrfp.firstEvent(time,changed,amplitude); category=event.cause;
        if category==0, category=nCategory; end
        directCounts(j,category)=directCounts(j,category)+1;
    end
end
elapsed=toc(t0); directElapsed=toc(td);
critical=tinv(0.975,nBatch-1);
% Build category/system summary with both conditional batch-t and direct-Wilson intervals.
rows={};
for j=1:numel(factors)
    cond=squeeze(conditional(:,j,:));
    direct=directCounts(j,:)/nDirect;
    z=norminv(0.975); ph=direct;
    low=(ph+z^2/(2*nDirect)-z*sqrt(ph.*(1-ph)/nDirect+z^2/(4*nDirect^2)))/(1+z^2/nDirect);
    high=(ph+z^2/(2*nDirect)+z*sqrt(ph.*(1-ph)/nDirect+z^2/(4*nDirect^2)))/(1+z^2/nDirect);
    for c=1:nCategory
        x=cond(:,c); rows(end+1,:)={factors(j),categoryNames(c),mean(x),critical*std(x)/sqrt(nBatch),direct(c),low(c),high(c),sum(nOuter),nDirect,"unconditional with respect to full input ensemble"}; %#ok<AGROW>
    end
    systemCond=1-cond(:,end); systemDirect=1-direct(end);
    lowS=(systemDirect+z^2/(2*nDirect)-z*sqrt(systemDirect*(1-systemDirect)/nDirect+z^2/(4*nDirect^2)))/(1+z^2/nDirect);
    highS=(systemDirect+z^2/(2*nDirect)+z*sqrt(systemDirect*(1-systemDirect)/nDirect+z^2/(4*nDirect^2)))/(1+z^2/nDirect);
    rows(end+1,:)={factors(j),"system_failure",mean(systemCond),critical*std(systemCond)/sqrt(nBatch),systemDirect,lowS,highS,sum(nOuter),nDirect,"unconditional with respect to full input ensemble"}; %#ok<AGROW>
end
probabilityTable=cell2table(rows,'VariableNames',{'capacityMultiplier','category','conditionalEstimate','conditionalT95HalfWidth','directEstimate','directWilson95Lower','directWilson95Upper','NConditional','NDirect','estimand'});
writetable(probabilityTable,fullfile(folder,'building16_capacity_sweep.csv'));
% Transfer matrix for the required anchor multiplier lambda=1.20.
j=find(abs(factors-1.20)<eps,1); assert(~isempty(j));
tm=squeeze(transfer(:,j,:,:)); tmMean=squeeze(mean(tm,1)); tmHalf=critical*squeeze(std(tm,0,1))/sqrt(nBatch);
[from,to]=ndgrid(categoryNames,categoryNames);
transferTable=table(from(:),to(:),tmMean(:),tmHalf(:),repmat(sum(nOuter),numel(from),1), ...
    'VariableNames',{'from','to','conditionalTransfer','conditionalT95HalfWidth','NConditional'});
writetable(transferTable,fullfile(folder,'building16_capacity_transfer_lambda1p20.csv'));
% Batch-level intervention quantities and machine-readable provenance.
batchRows=[];
for j=1:numel(factors)
    c=squeeze(conditional(:,j,:));
    rescued=squeeze(transfer(:,j,1,end)); substitute=squeeze(sum(transfer(:,j,1,2:end-1),4));
    if factors(j)==1, rescued(:)=0; substitute(:)=0; end
    row=table(repmat(factors(j),nBatch,1),(1:nBatch)',1-c(:,end),rescued,substitute, ...
        rescued./max(eps,rescued+substitute),'VariableNames',{'capacityMultiplier','batch','systemFailure','preventedMass','substitutedMass','preventedFraction'});
    batchRows=[batchRows;row]; %#ok<AGROW>
end
writetable(batchRows,fullfile(folder,'building16_capacity_batch_metrics.csv'));
summary=struct('caseName','building16','capacityMultipliers',factors,'target','story1_drift', ...
    'nConditional',sum(nOuter),'nBatches',nBatch,'nDirect',nDirect,'dt',cfg.dt, ...
    'responseEvaluations',responseEvaluations+directResponseEvaluations, ...
    'conditionalResponseEvaluations',responseEvaluations,'directResponseEvaluations',directResponseEvaluations, ...
    'partitionEvaluationsByMultiplier',[0,repmat(sum(nOuter),1,numel(factors)-1)], ...
    'conditionalPartitionEvaluations',partitionEvaluations,'elapsedSeconds',elapsed, ...
    'directElapsedSeconds',directElapsed,'randomSeeds',inputProvenance, ...
    'interpretation','Capacity multiplier is a controlled limit-state intervention experiment, not a physical retrofit.');
file=fopen(fullfile(folder,'building16_capacity_sweep_summary.json'),'w','n','UTF-8'); c=onCleanup(@()fclose(file)); fprintf(file,'%s',jsonencode(summary,'PrettyPrint',true));
end
