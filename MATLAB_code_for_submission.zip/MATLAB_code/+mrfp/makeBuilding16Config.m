function cfg = makeBuilding16Config(profile,options)
%makeBuilding16Config Literature-based 16-DOF elastic shear-building benchmark.
% Nominal M,K,h,zeta: doi:10.1590/0370-44672015700065, Sec.2.3, Tables1-2.
% The uncontrolled elastic structure is used; no friction dampers are added.
% Drift serviceability threshold: adapted from RESS2026,112389, Sec.6.3.
% This combines cited model properties with OUR stochastic input assumptions;
% it is not a reproduction of either source's complete numerical experiment.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","quick","study","paper"])} = "study"
    options.NFrequency (1,1) double {mustBeInteger,mustBePositive} = 512
    options.FrequencyMax (1,1) double {mustBePositive,mustBeFinite} = 30
end
cfg = mrfp.makeConfig("building",profile);
cfg.caseName = "building16";
cfg.nStory = 16;
cfg.storyMass = [68530,57940*ones(1,12),56660*ones(1,3)];
cfg.storyStiffness = [2.56e9*ones(1,13),1.74e9*ones(1,3)];
cfg.storyHeight = 3*ones(1,16);
incidence = eye(16)-diag(ones(15,1),-1);
cfg.mass = diag(cfg.storyMass);
cfg.stiffness = incidence'*diag(cfg.storyStiffness)*incidence;
cfg.dampingRatio = 0.005;
cfg.rayleighModes = [1,2];
cfg.publishedFrequencyHz = [3.18,9.28,14.96,20.74,26.59];
cfg.thresholds = 0.002*ones(1,16);
cfg.modeNames = "story"+string(1:16)+"_drift";
cfg.outputDisplacement = diag(1./cfg.storyHeight)*incidence;
cfg.outputVelocity = zeros(16);
cfg.outputAcceleration = zeros(16);
% Finite-band Clough-Penzien-shaped Gaussian series, not white-noise filtering.
% The filter frequencies and ratios below follow RESS2026,112389, Sec.6.3;
% finite-band normalization, sin^2 envelope and amplitude mixing are our choices.
cfg.nFrequency = options.NFrequency;
cfg.frequencyMax = options.FrequencyMax;
cfg.frequency = ((1:cfg.nFrequency)-0.5)*cfg.frequencyMax/cfg.nFrequency;
omega = 2*pi*cfg.frequency;
wg = 15.6; zg = 0.6; wf = 1.0; zf = 0.9;
spectrum = (wg^4+4*zg^2*wg^2*omega.^2)./ ...
    ((wg^2-omega.^2).^2+4*zg^2*wg^2*omega.^2).* ...
    omega.^4./((wf^2-omega.^2).^2+4*zf^2*wf^2*omega.^2);
cfg.frequencyWeights = sqrt(spectrum/sum(spectrum));
cfg.excitationScale = 1.0; % m/s^2; unit-amplitude peak-envelope pointwise SD.
cfg.dt = 0.0025;
cfg.nMode = numel(cfg.thresholds);
cfg.nInput = 2+2*cfg.nFrequency;
cfg.nPathParameter = 2+cfg.nMode;
cfg.parameterNames = ["log_stiffness","log_damping", ...
    "log_capacity_"+cfg.modeNames,"log_amplitude_median","log_amplitude_logsd"];
cfg.modelSource = "https://doi.org/10.1590/0370-44672015700065";
cfg.thresholdSource = "https://doi.org/10.1016/j.ress.2026.112389";
cfg.provenance = "Adapted elastic benchmark; source nominal M,K,h,damping; " + ...
    "adopted serviceability drift limit; author-defined random structure and finite-band load.";
end
