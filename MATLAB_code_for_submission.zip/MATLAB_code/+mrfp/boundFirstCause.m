function result = boundFirstCause(time, demand, radius, law, options)
%boundFirstCause Cause-wise bounds from a continuous signed response tube.
% Assumption: |true demand_i(t)-PWL(demand)_i(t)| <= PWL(radius)_i(t).
% Guarantees L_i <= P(unique first cause i) <= P(i among first causes) <= U_i.
% No differentiation of the bounds is used or justified.
arguments
    time (:,1) double {mustBeFinite}
    demand (:,:) double {mustBeFinite}
    radius (:,:) double {mustBeFinite,mustBeNonnegative}
    law (1,1) struct
    options.StorePartition (1,1) logical = false
end
assert(isequal(size(demand),size(radius)), ...
    'mrfp:TubeSize','Demand and tube radius must have the same size.');
nMode = size(demand,2);
labels = [1:nMode,1:nMode];
positive = [demand+radius,-demand+radius];
negative = [demand-radius,-demand-radius];
nominal = mrfp.integrateBranches(time,[demand,-demand],labels,law);
slow = mrfp.integrateBranches(time,negative,labels,law);
fast = mrfp.integrateBranches(time,positive,labels,law,StorePartition=options.StorePartition);
certified = zeros(0,3);
lower = zeros(size(demand));
upper = lower;
for i = 1:nMode
    target = labels==i;
    % Delay target and accelerate every competitor: sufficient unique cause.
    pessimistic = positive;
    pessimistic(:,target) = negative(:,target);
    low = mrfp.integrateBranches(time,pessimistic,labels,law,StorePartition=options.StorePartition);
    % Accelerate target and delay competitors: necessary for target to win.
    optimistic = negative;
    optimistic(:,target) = positive(:,target);
    high = mrfp.integrateBranches(time,optimistic,labels,law);
    lower(:,i) = low.uniqueCause(:,i);
    upper(:,i) = high.inclusiveCause(:,i);
    if options.StorePartition
        certified = [certified;low.partition(low.partition(:,3)==i,:)]; %#ok<AGROW>
    end
end
result = struct('time',time,'lower',lower,'upper',upper, ...
    'nominal',nominal.uniqueCause,'nominalJoint',nominal.joint, ...
    'failureLower',slow.failure,'failureUpper',fast.failure, ...
    'failureNominal',nominal.failure,'width',upper-lower, ...
    'unresolvedMassUpper',max(0,fast.failure-sum(lower,2)), ...
    'knownSafeLower',1-fast.failure);
if options.StorePartition
    certified = [certified;fast.partition(end,:)];
    certified = sortrows(certified,1);
    completed = zeros(2*size(certified,1)+1,3);
    count = 0;
    previous = 0;
    for j = 1:size(certified,1)
        assert(certified(j,1)>=previous-64*eps(max(1,previous)), ...
            'mrfp:CertificateOverlap','Exclusive certainty sets must not overlap.');
        if certified(j,1)>previous
            count = count+1;
            completed(count,:) = [previous,certified(j,1),0];
        end
        count = count+1;
        completed(count,:) = certified(j,:);
        previous = certified(j,2);
    end
    result.certifiedPartition = completed(1:count,:);
end
end
