function [probability, derivative] = amplitudeMass(record, recordDerivative, law)
%amplitudeMass Integrate a positive lognormal amplitude above 1/record.
% Derivative columns: supplied path parameters, log median, log log-SD.
arguments
    record (1,1) double {mustBeNonnegative}
    recordDerivative (1,:) double
    law (1,1) struct
end
derivative = zeros(1, numel(recordDerivative)+2);
probability = 0;
if record > 0
    z = (log(record)+law.mu)/law.sigma;
    probability = 0.5*erfc(-z/sqrt(2));
    density = exp(-0.5*z*z)/sqrt(2*pi);
    derivative = [density/(law.sigma*record)*recordDerivative, ...
        density/law.sigma, -z*density];
end
end
