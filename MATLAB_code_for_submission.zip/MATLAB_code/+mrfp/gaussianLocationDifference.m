function weight = gaussianLocationDifference(normal,logSd,step)
%gaussianLocationDifference Exact symmetric density ratio difference / (2h).
% Its expectation against q equals the finite difference of shifted-model
% expectations, even when q is discontinuous. Stable as h approaches zero.
arguments
    normal (:,:) double {mustBeFinite}
    logSd (1,:) double {mustBePositive,mustBeFinite}
    step (1,1) double {mustBePositive,mustBeFinite}
end
assert(size(normal,2)==numel(logSd),'mrfp:InputSize','One log-SD per normal column is required.');
shift = step./logSd;
weight = exp(-shift.^2/2).*sinh(normal.*shift)/step;
assert(all(isfinite(weight),'all'),'mrfp:DensityOverflow','Density ratio overflow: reduce the design step.');
end
