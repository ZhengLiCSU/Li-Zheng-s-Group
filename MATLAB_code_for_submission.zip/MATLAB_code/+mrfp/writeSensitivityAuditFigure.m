function writeSensitivityAuditFigure(report,file,cfg)
%writeSensitivityAuditFigure Show paired uncertainty for the equality audit.
% Plotting only dynamics CI next to score/density points would falsely suggest
% the latter have no sampling uncertainty. Plot the paired discrepancy instead.
fig = figure('Visible','off','Color','w','Position',[100,100,1100,430]);
cleanup = onCleanup(@() close(fig)); tiledlayout(1,2,'Padding','compact');
for parameter = ["log_stiffness","log_damping"]
    nexttile; hold on;
    selected = report.parameter==parameter & report.category==cfg.modeNames(1);
    r = sortrows(report(selected,:),'step');
    errorbar(r.step,r.pairedDynamicMinusDensity,r.paired95HalfWidth,'-o', ...
        'DisplayName','Paired difference, approximate 95% CI','LineWidth',1.2);
    yline(0,'--','DisplayName','Equal finite-step expectation');
    xlabel('Log-design finite step'); ylabel('Dynamics minus density finite difference');
    title(cfg.caseName+": "+parameter,'Interpreter','none'); grid on; legend('Location','best');
end
exportgraphics(fig,file,'Resolution',180);
end
