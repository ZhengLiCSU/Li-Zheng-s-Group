function result = reliabilityBatch(cfg,time,n,seed,method,nInner)
%reliabilityBatch Comparable cause probabilities and structural score outputs.
% All branches integrate the same physical model and analytic-node PWL event.
arguments
    cfg (1,1) struct
    time (:,1) double {mustBeFinite}
    n (1,1) double {mustBeInteger,mustBePositive}
    seed (1,1) double {mustBeInteger,mustBeNonnegative}
    method (1,1) string {mustBeMember(method,["conditional","mixture_is","direct_mc"])}
    nInner (1,1) double {mustBeInteger,mustBePositive} = 32
end
timer = tic;
if method=="conditional"
    inputs = mrfp.sampleInputs(n,cfg.nInput,seed);
    batch = mrfp.conditionalBatch(cfg,time,inputs);
    contribution = batch.probability(:,1:end-1);
    normal = inputs(:,1:2);
    responseCount = n;
elseif method=="direct_mc"
    inputs = mrfp.sampleInputs(n,cfg.nInput+1,seed,"mc");
    normal = inputs(:,1:2);
    contribution = zeros(n,cfg.nMode+1);
    for i = 1:n
        series = mrfp.makeResponseSeries(cfg,inputs(i,1:end-1),zeros(1,cfg.nPathParameter+2));
        demand = mrfp.evaluateSeriesField(series,time);
        amplitude = cfg.amplitudeMedian*exp(cfg.amplitudeLogSd*inputs(i,end));
        event = mrfp.firstEvent(time,demand,amplitude);
        if event.cause>0, contribution(i,event.cause) = 1; end
    end
    responseCount = n;
else
    outside = mrfp.sampleInputs(n,3,seed);
    innerStream = RandStream('mt19937ar','Seed',seed+100003);
    normal = outside(:,1:2);
    contribution = zeros(n,cfg.nMode+1);
    for i = 1:n
        operator = mrfp.makeGaussianOperator(cfg,normal(i,:),time);
        amplitude = cfg.amplitudeMedian*exp(cfg.amplitudeLogSd*outside(i,3));
        sample = mrfp.sampleGaussianUnion(amplitude*operator,nInner,seed,Stream=innerStream);
        for j = 1:nInner
            demand = reshape(sample.response(:,j),numel(time),cfg.nMode);
            event = mrfp.firstEvent(time,demand,1);
            assert(event.cause>0,'mrfp:ISSupport','Mixture sample must fail.');
            contribution(i,event.cause) = contribution(i,event.cause)+sample.weight(j)/nInner;
        end
    end
    responseCount = n*2*cfg.nFrequency;
end
[estimate,names] = mrfp.reliabilityStatistics(contribution,normal,cfg);
result = struct('estimate',estimate,'names',names,'seconds',toc(timer), ...
    'basisOrTrajectoryEvaluations',responseCount,'nOuter',n,'nInner',nInner);
end
