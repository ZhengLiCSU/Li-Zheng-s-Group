function result = analyzeWeightedPaths(time, responses, capacity, weights)
%analyzeWeightedPaths Adapt existing paired DPIM trajectories to marked exits.
% responses: time-by-mode-by-realization, using SHARED realizations.
% This generic weighted event estimator does not require amplitude scaling.
% It is a baseline/adapter, not the proposed conditional-amplitude algorithm.
arguments
    time (:,1) double {mustBeFinite}
    responses (:,:,:) double {mustBeFinite}
    capacity (1,:) double {mustBePositive,mustBeFinite}
    weights (:,1) double {mustBeNonnegative,mustBeFinite}
end
n = size(responses,3);
m = size(responses,2);
assert(numel(weights) == n && numel(capacity) == m && numel(time) == size(responses,1), ...
    'mrfp:PathSize','Use matching time, mode, sample, capacity and weight dimensions.');
assert(abs(sum(weights)-1) <= 1e-8,'mrfp:Weights', ...
    'Probability weights must sum to one; do not silently renormalize importance weights.');
increments = zeros(numel(time),m+1);
firstTime = inf(n,1);
firstCause = zeros(n,1);
for sample = 1:n
    event = mrfp.firstEvent(time,responses(:,:,sample)./capacity,1);
    firstTime(sample) = event.time;
    firstCause(sample) = event.cause;
    if event.cause > 0
        k = find(time >= event.time,1);
        increments(k,event.cause) = increments(k,event.cause) + weights(sample);
    end
end
cause = cumsum(increments,1);
result = struct('time',time,'cause',cause,'failure',sum(cause,2), ...
    'survival',1-sum(cause,2),'firstTime',firstTime,'firstCause',firstCause);
end
