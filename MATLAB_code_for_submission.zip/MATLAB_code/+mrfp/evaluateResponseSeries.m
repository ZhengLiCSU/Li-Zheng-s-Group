function path = evaluateResponseSeries(series, time)
%evaluateResponseSeries Evaluate analytic paths and a curvature error tube.
% The h^2*M/8 interpolation bound is rigorous in exact arithmetic. Ordinary
% doubles here do not provide an outward-rounded floating-point certificate.
arguments
    series (1,1) struct
    time (:,1) double {mustBeFinite,mustBeNonnegative}
end
assert(numel(time)>=2 && all(diff(time)>0), ...
    'mrfp:Time','At least two strictly increasing times are required.');
demand = mrfp.evaluateSeriesField(series,time,0);
firstDerivative = mrfp.evaluateSeriesField(series,time,1);
secondDerivative = mrfp.evaluateSeriesField(series,time,2);
growth = real(series.poles).';
endpointExponent = max(time(1:end-1)*growth,time(2:end)*growth);
curvature = exp(endpointExponent)*abs(series.poles.^2.*series.coefficients);
if isfield(series,'transientGenerators')
    for j = 1:size(series.transientGenerators,3)
        generator = series.transientGenerators(:,:,j);
        states = mrfp.evaluateModalState(generator,series.transientInitial(:,j),time(1:end-1));
        % The energy-scaled generator has negative semidefinite symmetric part.
        output = (generator'^2)*series.transientDemand(:,:,j);
        curvature = curvature+vecnorm(states,2,2)*vecnorm(output,2,1);
    end
end
cellRadius = diff(time).^2.*curvature/8;
% Both node radii exceed each adjacent cell's constant interpolation bound.
radius = max([cellRadius;zeros(1,size(demand,2))], ...
    [zeros(1,size(demand,2));cellRadius]);
path = struct('time',time,'demand',demand,'radius',radius, ...
    'cellRadius',cellRadius,'curvatureBound',curvature, ...
    'firstDerivative',firstDerivative,'secondDerivative',secondDerivative, ...
    'law',series.law);
end
