function result = integrateBranches(time, values, labels, law, options)
%integrateBranches First-cause masses for a piecewise-linear branch envelope.
% Several branches can belong to one physical mode. Values may be negative.
% inclusiveCause includes ties involving that mode; uniqueCause excludes ties.
arguments
    time (:,1) double {mustBeFinite}
    values (:,:) double {mustBeFinite}
    labels (1,:) double {mustBeInteger,mustBePositive}
    law (1,1) struct
    options.StorePartition (1,1) logical = false
end
assert(size(values,1)==numel(time) && all(diff(time)>0), ...
    'mrfp:Time','Time must increase and match the branch rows.');
assert(size(values,2)==numel(labels) && law.sigma>0, ...
    'mrfp:Branches','Labels and branches must match; sigma must be positive.');
nMode = max(labels);
nTime = numel(time);
uniqueCause = zeros(nTime,nMode);
inclusiveCause = uniqueCause;
partition = zeros(0,3);
% At t=0 several modes can already exceed a threshold even if their values
% differ. Partition by ALL positive initial values, not only the maximum.
cuts = unique([0,values(1,values(1,:)>0)]);
for j = 2:numel(cuts)
    threshold = (cuts(j-1)+cuts(j))/2;
    active = unique(labels(values(1,:)>=threshold));
    mass = massAt(cuts(j),law)-massAt(cuts(j-1),law);
    inclusiveCause(1,active) = inclusiveCause(1,active)+mass;
    if isscalar(active)
        uniqueCause(1,active) = uniqueCause(1,active)+mass;
    end
    if options.StorePartition
        partition = appendInterval(partition,cuts(j-1),cuts(j),active,nMode);
    end
end
record = max([0,values(1,:)]);
failure = zeros(nTime,1);
failure(1) = massAt(record,law);
for k = 2:nTime
    uniqueCause(k,:) = uniqueCause(k-1,:);
    inclusiveCause(k,:) = inclusiveCause(k-1,:);
    failure(k) = failure(k-1);
    if max(values(k,:))<=record
        continue
    end
    keep = max(values(k-1:k,:),[],1)>record;
    start = values(k-1,keep);
    slope = values(k,keep)-start;
    owner = labels(keep);
    cuts = branchCuts(start,slope);
    for j = 2:numel(cuts)
        middle = (cuts(j-1)+cuts(j))/2;
        [~,winner] = max(start+middle*slope);
        next = start(winner)+cuts(j)*slope(winner);
        if next<=record
            continue
        end
        same = abs(start-start(winner))<=32*eps(max(realmin,abs(start(winner)))) & ...
            abs(slope-slope(winner))<=32*eps(max(realmin,abs(slope(winner))));
        active = unique(owner(same));
        mass = massAt(next,law)-massAt(record,law);
        inclusiveCause(k,active) = inclusiveCause(k,active)+mass;
        if isscalar(active)
            uniqueCause(k,active) = uniqueCause(k,active)+mass;
        end
        if options.StorePartition
            partition = appendInterval(partition,record,next,active,nMode);
        end
        record = next;
    end
    failure(k) = massAt(record,law);
end
result = struct('time',time,'uniqueCause',uniqueCause, ...
    'inclusiveCause',inclusiveCause,'failure',failure, ...
    'joint',failure-sum(uniqueCause,2));
if options.StorePartition
    partition(end+1,:) = [record,Inf,nMode+2];
    result.partition = partition;
end
end

function partition = appendInterval(partition,left,right,active,nMode)
category = nMode+1;
if isscalar(active)
    category = active;
end
if ~isempty(partition) && partition(end,3)==category
    partition(end,2) = right;
else
    partition(end+1,:) = [left,right,category];
end
end

function cuts = branchCuts(start,slope)
n = numel(start);
cuts = zeros(2+n*(n-1)/2,1);
cuts(2) = 1;
count = 2;
for i = 1:n-1
    for j = i+1:n
        denominator = slope(i)-slope(j);
        if denominator==0
            continue
        end
        alpha = (start(j)-start(i))/denominator;
        if alpha>0 && alpha<1
            count = count+1;
            cuts(count) = alpha;
        end
    end
end
cuts = unique(cuts(1:count));
end

function mass = massAt(record,law)
mass = 0;
if record>0
    mass = 0.5*erfc(-(log(record)+law.mu)/(sqrt(2)*law.sigma));
end
end
