function writeFigures(result, reference, verification, views, directory)
%writeFigures Export scientific figures without external palettes or fonts.
arguments
    result (1,1) struct
    reference (1,1) struct
    verification (1,1) struct
    views (1,1) struct
    directory (1,1) string
end
cfg = result.config;
names = [cfg.modeNames,"joint"];
f = figure('Visible','off','Position',[100,100,1200,480],'Color','w');
cleanup = onCleanup(@() close(f));
tiledlayout(1,2);
nexttile;
mcBand = fill([reference.time;flipud(reference.time)], ...
    [reference.ciLow;flipud(reference.ciHigh)], ...
    [0.85,0.85,0.85],'EdgeColor','none','FaceAlpha',0.6);
hold on;
rqmcBand = fill([result.time;flipud(result.time)], ...
    [max(0,result.failure-result.ciHalfWidth);flipud(min(1,result.failure+result.ciHalfWidth))], ...
    [0.8,0.87,1],'EdgeColor','none');
mainLine = plot(result.time,result.failure,'b-','LineWidth',1.8);
mcLine = plot(reference.time,reference.failure,'k--','LineWidth',1.3);
xlabel('Time (s)'); ylabel('First-passage probability');
legend([rqmcBand,mcBand,mainLine,mcLine], ...
    'Approx. 95% RQMC interval','95% MC Wilson interval','Conditional integral','Independent MC','Location','best');
grid on;
title(cfg.caseName,'Interpreter','none');
nexttile;
plot(result.time,result.cause,'LineWidth',1.5);
xlabel('Time (s)'); ylabel('Cause-specific cumulative probability');
legend(names,'Interpreter','none','Location','best'); grid on;
exportgraphics(f,fullfile(directory,'first_passage.png'),'Resolution',180);
clear cleanup

f = figure('Visible','off','Position',[100,100,1350,600],'Color','w');
cleanup = onCleanup(@() close(f));
tiledlayout(1,2);
nexttile;
imagesc(result.gradient(1:cfg.nMode,:)); colorbar;
colorLimit = max(abs(result.gradient),[],'all');
clim([-colorLimit,colorLimit]);
colormap(gca,[linspace(0.15,1,128)',linspace(0.35,1,128)',ones(128,1); ...
    ones(128,1),linspace(1,0.2,128)',linspace(1,0.15,128)']);
xticks(1:numel(cfg.parameterNames)); xticklabels(cfg.parameterNames); xtickangle(40);
yticks(1:cfg.nMode); yticklabels(cfg.modeNames);
set(gca,'TickLabelInterpreter','none'); title('d F_i / d log parameter');
nexttile;
bar([verification.analytic(1:cfg.nMode,3),verification.finiteDifference(1:cfg.nMode,3,2), ...
    verification.frozen(1:cfg.nMode,3)]);
xticks(1:cfg.nMode); xticklabels(cfg.modeNames); set(gca,'TickLabelInterpreter','none');
legend('Moving frontier','Central difference','Frozen-switch ablation','Location','southoutside');
ylabel('Sensitivity to log capacity 1'); grid on;
exportgraphics(f,fullfile(directory,'sensitivities.png'),'Resolution',180);
clear cleanup

f = figure('Visible','off','Position',[100,100,1200,480],'Color','w');
cleanup = onCleanup(@() close(f));
tiledlayout(1,2);
nexttile;
bar([result.individualModeProbability(end,:)',result.cause(end,1:cfg.nMode)']);
xticks(1:cfg.nMode); xticklabels(cfg.modeNames); set(gca,'TickLabelInterpreter','none');
ylabel('Probability at T'); legend('Ever exceeded alone','First system-failure cause','Location','northoutside');
grid on;
nexttile;
bar([result.boundaryGradient(1:cfg.nMode,3),result.exchangeGradient(1:cfg.nMode,3),result.gradient(1:cfg.nMode,3)]);
xticks(1:cfg.nMode); xticklabels(cfg.modeNames); set(gca,'TickLabelInterpreter','none');
ylabel('Sensitivity to log capacity 1');
legend('External failure boundary','Internal mode exchange','Total cause derivative','Location','northoutside');
grid on;
exportgraphics(f,fullfile(directory,'mode_competition.png'),'Resolution',180);
clear cleanup

f = figure('Visible','off','Position',[100,100,1250,520],'Color','w');
cleanup = onCleanup(@() close(f));
tiledlayout(1,2);
nexttile;
surf(repmat(views.time',size(views.x,1),1),views.x,views.density,'EdgeColor','none');
xlabel('Time (s)'); ylabel(cfg.modeNames(1),'Interpreter','none'); zlabel('PDF');
view(40,28); colorbar; title('Evolutionary 1D response density');
nexttile;
contourf(views.joint.x,views.joint.y,views.joint.density',20,'LineColor','none');
xlabel(cfg.modeNames(1),'Interpreter','none'); ylabel(cfg.modeNames(2),'Interpreter','none');
colorbar; title(sprintf('Joint response density, t = %.3f s',views.jointTime));
exportgraphics(f,fullfile(directory,'evolving_pdf.png'),'Resolution',180);
end
