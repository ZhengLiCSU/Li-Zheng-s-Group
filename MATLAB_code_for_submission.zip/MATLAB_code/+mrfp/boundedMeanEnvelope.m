function result = boundedMeanEnvelope(lower, upper, valueRange, alpha)
%boundedMeanEnvelope Fixed-budget Hoeffding bounds for INDEPENDENT observations.
% Each row is an independent bounded observation or independent RQMC batch.
% User must supply valid deterministic ranges. No optional-stopping guarantee.
arguments
    lower (:,:) double {mustBeFinite}
    upper (:,:) double {mustBeFinite}
    valueRange (2,:) double {mustBeFinite}
    alpha (1,1) double {mustBePositive,mustBeLessThan(alpha,1)} = 0.05
end
assert(isequal(size(lower),size(upper)) && size(lower,2)==size(valueRange,2) && ...
    all(lower<=upper+1e-12,'all') && all(lower>=valueRange(1,:)-1e-12,'all') && ...
    all(upper<=valueRange(2,:)+1e-12,'all'), ...
    'mrfp:ConfidenceRange','Bounds and deterministic ranges must match.');
n = size(lower,1);
q = size(lower,2);
radius = diff(valueRange,1,1)*sqrt(log(2*q/alpha)/(2*n));
result = struct('lower',max(valueRange(1,:),mean(lower,1)-radius), ...
    'upper',min(valueRange(2,:),mean(upper,1)+radius), ...
    'alpha',alpha,'independentObservations',n,'simultaneousQuantities',q);
end
