function reference = referenceMonteCarlo(cfg)
%referenceMonteCarlo Independent direct MC, including random load amplitude.
arguments
    cfg (1,1) struct
end
timer = tic;
random = mrfp.sampleInputs(cfg.nReference,cfg.nInput+1,cfg.seed+91000,"mc");
time = (0:cfg.dt:cfg.duration)';
nTime = numel(time);
counts = zeros(nTime,cfg.nMode+1);
firstTime = inf(cfg.nReference,1);
firstCause = zeros(cfg.nReference,1);
design = zeros(1,cfg.nPathParameter+2);
for sample = 1:cfg.nReference
    path = mrfp.solveTrajectory(cfg,random(sample,1:cfg.nInput),design,cfg.dt,false);
    amplitude = exp(path.law.mu+path.law.sigma*random(sample,end));
    event = mrfp.firstEvent(path.time,path.demand,amplitude);
    firstTime(sample) = event.time;
    firstCause(sample) = event.cause;
    if event.cause > 0
        firstGrid = find(time >= event.time,1);
        counts(firstGrid,event.cause) = counts(firstGrid,event.cause) + 1;
    end
end
cause = cumsum(counts,1)/cfg.nReference;
failure = sum(cause,2);
% Wilson interval remains informative when the observed number is zero.
z = 1.95996398454005;
denominator = 1 + z^2/cfg.nReference;
center = (failure + z^2/(2*cfg.nReference))/denominator;
half = z*sqrt(failure.*(1-failure)/cfg.nReference + z^2/(4*cfg.nReference^2))/denominator;
reference = struct('time',time,'cause',cause,'failure',failure, ...
    'ciLow',max(0,center-half),'ciHigh',min(1,center+half), ...
    'firstTime',firstTime,'firstCause',firstCause,'seconds',toc(timer), ...
    'dynamicCalls',cfg.nReference);
end
