function result = systemCapacityDerivative(modeRecord,target,law)
%systemCapacityDerivative One-sided log-capacity derivatives, allowing ties.
% Records are nonnegative per-mode maxima of normalized absolute demand.
% Exact equality here concerns the supplied records; near ties are not
% arbitrarily collapsed into exact ties by a numerical tolerance.
arguments
    modeRecord (1,:) double {mustBeFinite,mustBeNonnegative}
    target (1,1) double {mustBeInteger,mustBePositive}
    law (1,1) struct
end
assert(~isempty(modeRecord) && target<=numel(modeRecord), ...
    'mrfp:InputSize','Target must name a supplied mode.');
own = modeRecord(target);
others = modeRecord; others(target) = 0;
competitor = max(others);
record = max(own,competitor);
[probability,gradient] = mrfp.amplitudeMass(record,-record,law);
right = gradient(1)*(own>competitor);
left = gradient(1)*(own>=competitor);
ordinary = right;
if right~=left, ordinary = NaN; end
result = struct('probability',probability,'left',left,'right',right, ...
    'ordinary',ordinary,'differentiable',right==left);
end
