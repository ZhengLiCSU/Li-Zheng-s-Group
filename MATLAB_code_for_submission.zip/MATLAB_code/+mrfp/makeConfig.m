function cfg = makeConfig(caseName, profile)
%makeConfig Create reproducible forced-SDOF or three-story benchmark.
arguments
    caseName (1,1) string {mustBeMember(caseName,["sdof","building"])}
    profile (1,1) string {mustBeMember(profile,["smoke","quick","study","paper"])} = "quick"
end
cfg = struct('caseName',caseName,'profile',profile,'seed',73021, ...
    'nFrequency',6,'stiffnessLogSd',0.12,'dampingLogSd',0.15, ...
    'amplitudeMedian',1,'amplitudeLogSd',0.45,'dampingRatio',0.04, ...
    'nSample',128,'nReplicate',4,'nReference',2048,'dt',0.025, ...
    'duration',12,'nConvergence',24,'nSensitivity',24);
switch profile
    case "smoke"
        cfg.nSample = 12;
        cfg.nReplicate = 2;
        cfg.nReference = 48;
        cfg.dt = 0.08;
        cfg.nConvergence = 4;
        cfg.nSensitivity = 4;
    case "study"
        cfg.nSample = 256;
        cfg.nReplicate = 6;
        cfg.nReference = 4096;
        cfg.dt = 0.01;
    case "paper"
        cfg.nSample = 1024;
        cfg.nReplicate = 8;
        cfg.nReference = 32768;
        cfg.dt = 0.005;
        cfg.nConvergence = 128;
        cfg.nSensitivity = 128;
    otherwise
        % Quick profile uses the defaults.
end
if caseName == "sdof"
    cfg.mass = 1;
    cfg.stiffness = (2*pi*1.1)^2;
    cfg.frequency = linspace(0.5,2.1,cfg.nFrequency);
    cfg.thresholds = [0.055,0.38];
    cfg.modeNames = ["displacement","velocity"];
    cfg.excitationScale = 0.35;
else
    cfg.mass = 2.0e4*eye(3);
    story = 2.0e6*[1.15,1,0.85];
    incidence = [1,0,0;-1,1,0;0,-1,1];
    cfg.stiffness = incidence'*diag(story)*incidence;
    cfg.frequency = linspace(0.5,4.0,cfg.nFrequency);
    cfg.thresholds = [0.0035,0.0035,0.75];
    cfg.modeNames = ["story1_drift","story3_drift","roof_acceleration"];
    cfg.storyHeight = 3.0;
    cfg.excitationScale = 0.12;
end
cfg.nMode = numel(cfg.thresholds);
cfg.nInput = 2 + 2*cfg.nFrequency;
cfg.nPathParameter = 2 + cfg.nMode;
cfg.parameterNames = ["log_stiffness","log_damping", ...
    "log_capacity_"+cfg.modeNames,"log_amplitude_median","log_amplitude_logsd"];
end
