function result = sampleGaussianUnion(operator, n, seed, options)
%sampleGaussianUnion Existing Gaussian component-mixture importance sampler.
% Event: any abs(operator*Z)>=1, Z~N(0,I). Not a new proposed algorithm.
% Mixture weights proportional to component Gaussian exceedance probabilities.
% The unbiased union weight is sum(component probabilities)/exceedance count.
arguments
    operator (:,:) double {mustBeFinite}
    n (1,1) double {mustBePositive,mustBeInteger}
    seed (1,1) double {mustBeNonnegative,mustBeInteger}
    options.Stream = []
end
stream = options.Stream;
if isempty(stream)
    state = rng;
    cleanup = onCleanup(@() rng(state));
    rng(seed,'twister');
    stream = RandStream.getGlobalStream;
else
    assert(isa(stream,'RandStream'),'mrfp:RandomStream','Stream must be a RandStream.');
end
rowNorm = vecnorm(operator,2,2);
tail = 0.5*erfc(1./rowNorm/sqrt(2));
normalizer = 2*sum(tail);
assert(normalizer>0 && isfinite(normalizer), 'mrfp:ISUnderflow', ...
    'All component tails underflowed or the operator is zero. Do not silently return zero.');
keep = tail>0;
directions = operator(keep,:)./rowNorm(keep);
tail = tail(keep);
distribution = cumsum(tail)/sum(tail);
distribution(end) = 1;
points = randn(stream,size(operator,2),n);
choice = rand(stream,1,n);
orientation = 2*(rand(stream,1,n)>=0.5)-1;
tailQuantile = rand(stream,1,n);
for i = 1:n
    index = find(distribution>=choice(i),1);
    direction = orientation(i)*directions(index,:)';
    coordinate = sqrt(2)*erfcinv(2*max(realmin,tailQuantile(i)*tail(index)));
    points(:,i) = points(:,i)+(coordinate-direction'*points(:,i))*direction;
end
response = operator*points;
count = sum(abs(response)>=1,1);
assert(all(count>0),'mrfp:ISSupport','A sampled point left the selected failure support.');
weight = normalizer./count;
result = struct('points',points,'response',response,'weight',weight, ...
    'estimate',mean(weight),'standardError',std(weight)/sqrt(n), ...
    'normalizer',normalizer,'exceedanceCount',count);
end
