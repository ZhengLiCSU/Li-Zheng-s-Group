function result = transportPartitions(before, after, law, nCategory)
%transportPartitions Integrate paired first-cause changes over one shared B.
% Partitions cover [0,Inf], rows [left,right,category]. Category zero means
% uncertified. With zero labels matrix is a lower bound; otherwise exact PWL.
arguments
    before (:,3) double
    after (:,3) double
    law (1,1) struct
    nCategory (1,1) double {mustBePositive,mustBeInteger}
end
validatePartition(before,nCategory);
validatePartition(after,nCategory);
matrix = zeros(nCategory);
i = 1;
j = 1;
while i<=size(before,1) && j<=size(after,1)
    left = max(before(i,1),after(j,1));
    right = min(before(i,2),after(j,2));
    if right>left && before(i,3)>0 && after(j,3)>0
        mass = cdfAt(right,law)-cdfAt(left,law);
        matrix(before(i,3),after(j,3)) = matrix(before(i,3),after(j,3))+mass;
    end
    nextBefore = before(i,2)<=after(j,2);
    nextAfter = after(j,2)<=before(i,2);
    i = i+nextBefore;
    j = j+nextAfter;
end
unresolved = max(0,1-sum(matrix,'all'));
result = struct('matrix',matrix,'unresolvedMass',unresolved, ...
    'entryUpper',min(1,matrix+unresolved), ...
    'beforeMarginal',sum(matrix,2),'afterMarginal',sum(matrix,1)', ...
    'netChange',sum(matrix,1)'-sum(matrix,2));
end

function validatePartition(partition,nCategory)
assert(~isempty(partition) && partition(1,1)==0 && isinf(partition(end,2)) && ...
    all(partition(:,2)>partition(:,1)) && ...
    all(partition(2:end,1)==partition(1:end-1,2)) && ...
    all(partition(:,3)>=0 & partition(:,3)<=nCategory & mod(partition(:,3),1)==0), ...
    'mrfp:Partition','Expected an ordered gap-free partition of [0,Inf].');
end

function probability = cdfAt(value,law)
probability = 0;
if value>0
    probability = 0.5*erfc(-(log(value)+law.mu)/(sqrt(2)*law.sigma));
end
end
