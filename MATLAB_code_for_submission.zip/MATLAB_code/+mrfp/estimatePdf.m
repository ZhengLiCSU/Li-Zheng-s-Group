function pdf = estimatePdf(samples, weights, nIndependent, nGrid, options)
%estimatePdf Weighted one/two-dimensional Gaussian DPIM visualization.
% Paired rows preserve dependence. PDF smoothing is NOT used for reliability.
arguments
    samples (:,:) double {mustBeFinite}
    weights (:,1) double {mustBeNonnegative,mustBeFinite}
    nIndependent (1,1) double {mustBePositive}
    nGrid (1,1) double {mustBeInteger,mustBePositive} = 100
    options.StandardDeviationRange (1,1) double {mustBePositive} = Inf
end
[n,d] = size(samples);
assert(d <= 2 && numel(weights) == n && sum(weights) > 0, ...
    'mrfp:PdfSize','Use one or two columns and a positive matching weight vector.');
weights = weights/sum(weights);
location = weights'*samples;
centered = samples-location;
covariance = centered'*(centered.*weights);
floorScale = max([max(diag(covariance)),max(abs(samples),[],'all')^2*1e-10,1e-14]);
[vectors,values] = eig((covariance+covariance')/2);
bandwidth = vectors*diag(max(diag(values),floorScale*1e-6))*vectors'*nIndependent^(-2/(d+4));
sd = sqrt(diag(bandwidth));
lower = min(samples,[],1)'-4*sd;
upper = max(samples,[],1)'+4*sd;
if isfinite(options.StandardDeviationRange)
    displaySd = sqrt(diag(covariance+bandwidth));
    lower = location' - options.StandardDeviationRange*displaySd;
    upper = location' + options.StandardDeviationRange*displaySd;
end
x = linspace(lower(1),upper(1),nGrid)';
if d == 1
    density = exp(-0.5*((x-samples(:,1)')/sd(1)).^2)*weights/(sqrt(2*pi)*sd(1));
    pdf = struct('x',x,'y',[],'density',density,'mass',trapz(x,density),'bandwidth',bandwidth);
else
    y = linspace(lower(2),upper(2),nGrid)';
    [xx,yy] = ndgrid(x,y);
    points = [xx(:),yy(:)];
    density = zeros(size(points,1),1);
    precisionFactor = chol(bandwidth);
    scale = 1/(2*pi*sqrt(det(bandwidth)));
    for j = 1:n
        delta = points-samples(j,:);
        whitened = delta/precisionFactor;
        density = density + weights(j)*scale*exp(-0.5*sum(whitened.^2,2));
    end
    density = reshape(density,nGrid,nGrid);
    pdf = struct('x',x,'y',y,'density',density, ...
        'mass',trapz(y,trapz(x,density,1)),'bandwidth',bandwidth);
end
end
