function [displacement,velocity,acceleration] = outputMaps(cfg)
%outputMaps Linear response observation maps, with legacy-config compatibility.
arguments
    cfg (1,1) struct
end
nDof = size(cfg.mass,1);
if isfield(cfg,'outputDisplacement')
    displacement = cfg.outputDisplacement;
    velocity = cfg.outputVelocity;
    acceleration = cfg.outputAcceleration;
elseif cfg.caseName=="sdof"
    displacement = [1;0];
    velocity = [0;1];
    acceleration = zeros(2,1);
else
    assert(nDof==3,'mrfp:OutputMap','Define observation maps for a new building model.');
    displacement = [1,0,0;0,-1,1;0,0,0]/cfg.storyHeight;
    velocity = zeros(3);
    acceleration = [0,0,0;0,0,0;0,0,1];
end
assert(isequal(size(displacement),[cfg.nMode,nDof]) && ...
    isequal(size(velocity),size(displacement)) && isequal(size(acceleration),size(displacement)), ...
    'mrfp:OutputMap','Observation maps must have nMode rows and nDof columns.');
assert(all(isfinite([displacement,velocity,acceleration]),'all'), ...
    'mrfp:OutputMap','Observation maps must be finite.');
end
