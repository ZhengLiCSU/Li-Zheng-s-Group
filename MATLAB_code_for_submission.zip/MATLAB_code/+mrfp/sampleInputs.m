function normal = sampleInputs(n, dimension, seed, method)
%sampleInputs Generate independent MC or independently scrambled Sobol inputs.
arguments
    n (1,1) double {mustBeInteger,mustBePositive}
    dimension (1,1) double {mustBeInteger,mustBePositive}
    seed (1,1) double {mustBeInteger,mustBeNonnegative}
    method (1,1) string {mustBeMember(method,["rqmc","mc"])} = "rqmc"
end
state = rng;
cleanup = onCleanup(@() rng(state));
rng(seed,"twister");
if method == "rqmc"
    assert(exist('sobolset','file') == 2,'mrfp:Toolbox', ...
        'Scrambled Sobol requires Statistics and Machine Learning Toolbox. Use method="mc" otherwise.');
    points = scramble(sobolset(dimension),"MatousekAffineOwen");
    uniform = net(points,n);
    uniform = min(max(uniform,eps),1-eps);
    normal = sqrt(2)*erfinv(2*uniform-1);
else
    normal = randn(n,dimension);
end
end
