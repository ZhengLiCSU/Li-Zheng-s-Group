function damping = baseDamping(cfg,frequency)
%baseDamping Nominal proportional damping with explicitly selected anchor modes.
arguments
    cfg (1,1) struct
    frequency (:,1) double {mustBePositive,mustBeFinite}
end
if isscalar(frequency)
    damping = 2*cfg.dampingRatio*sqrt(cfg.stiffness*cfg.mass);
    return
end
anchors = [1,numel(frequency)];
if isfield(cfg,'rayleighModes'), anchors = cfg.rayleighModes; end
assert(numel(anchors)==2 && all(anchors>=1 & anchors<=numel(frequency)) && ...
    all(mod(anchors,1)==0) && anchors(1)~=anchors(2), ...
    'mrfp:DampingModes','Select two distinct valid Rayleigh anchor modes.');
selected = frequency(anchors);
coefficients = [1./(2*selected),selected/2]\[cfg.dampingRatio;cfg.dampingRatio];
damping = coefficients(1)*cfg.mass+coefficients(2)*cfg.stiffness;
end
