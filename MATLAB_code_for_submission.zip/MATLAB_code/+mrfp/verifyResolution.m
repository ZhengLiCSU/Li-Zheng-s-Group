function verification = verifyResolution(cfg, inputs)
%verifyResolution Compare dt, dt/2, dt/4 and bracket a finer PWL reference.
% The bracket is certified for the two PWL paths compared, not for the ODE.
arguments
    cfg (1,1) struct
    inputs (:,:) double
end
n = min(cfg.nConvergence,size(inputs,1));
design = zeros(1,cfg.nPathParameter+2);
probability = zeros(n,3);
cause = zeros(n,cfg.nMode+1,3);
bounds = zeros(n,2);
for sample = 1:n
    paths = cell(3,1);
    for level = 1:3
        paths{level} = mrfp.solveTrajectory(cfg,inputs(sample,:),design,cfg.dt/2^(level-1),false);
        item = paths{level};
        event = mrfp.integrateFrontier(item.time,item.demand,zeros(numel(item.time),cfg.nMode,1),item.law);
        probability(sample,level) = event.failure(end);
        cause(sample,:,level) = event.cause(end,:);
    end
    coarse = paths{1};
    fine = paths{3};
    interpolated = interp1(coarse.time,coarse.demand,fine.time,'linear');
    epsilon = max(abs(interpolated-fine.demand),[],'all');
    record = max(abs(coarse.demand),[],'all');
    bounds(sample,1) = mrfp.amplitudeMass(max(0,record-epsilon),0,coarse.law);
    bounds(sample,2) = mrfp.amplitudeMass(record+epsilon,0,coarse.law);
end
verification = struct('probability',probability,'cause',cause,'fineBracket',bounds, ...
    'meanProbability',mean(probability,1),'meanCause',squeeze(mean(cause,1)), ...
    'maxBracketViolation',max([bounds(:,1)-probability(:,3);probability(:,3)-bounds(:,2);0]), ...
    'meanBracketWidth',mean(bounds(:,2)-bounds(:,1)), ...
    'coarseFineDifference',mean(probability(:,1)-probability(:,3)), ...
    'nInput',n);
end
