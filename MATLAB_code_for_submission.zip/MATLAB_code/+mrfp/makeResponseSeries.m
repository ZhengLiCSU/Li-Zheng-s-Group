function series = makeResponseSeries(cfg, random, design)
%makeResponseSeries Closed-form exponential response for the benchmark loads.
% Valid for proportional damping and positive stiffness, including critical
% damping. Use evaluateSeriesField to include any stable transient fallback.
arguments
    cfg (1,1) struct
    random (1,:) double {mustBeFinite}
    design (1,:) double {mustBeFinite}
end
assert(numel(random)==cfg.nInput && numel(design)==cfg.nPathParameter+2, ...
    'mrfp:InputSize','Random/design dimensions must match configuration.');
mass = cfg.mass;
baseK = cfg.stiffness;
[modes,eigenvalues] = eig(baseK,mass,'vector');
[eigenvalues,order] = sort(eigenvalues);
modes = modes(:,order);
modes = modes./sqrt(diag(modes'*mass*modes))';
frequency = sqrt(eigenvalues);
nDof = numel(frequency);
baseC = mrfp.baseDamping(cfg,frequency);
scaleK = exp(cfg.stiffnessLogSd*random(1)+design(1));
scaleC = exp(cfg.dampingLogSd*random(2)+design(2));
stiffness = scaleK*baseK;
damping = scaleC*sqrt(scaleK)*baseC;
modalK = scaleK*eigenvalues;
modalC = diag(modes'*damping*modes);
loadVector = ones(nDof,1);
if cfg.caseName~="sdof"
    loadVector = -mass*loadVector;
end
modalLoad = modes'*loadVector;
% sin^2(pi*t/T) produces the central frequency and two sidebands.
omega = 2*pi*cfg.frequency;
sideband = 2*pi/cfg.duration;
weights = ones(1,cfg.nFrequency)/sqrt(cfg.nFrequency);
if isfield(cfg,'frequencyWeights'), weights = cfg.frequencyWeights; end
assert(numel(weights)==cfg.nFrequency && all(isfinite(weights)), ...
    'mrfp:FrequencyWeights','Provide one finite weight per load frequency.');
forcingCoefficient = cfg.excitationScale*weights.* ...
    (random(3+cfg.nFrequency:end)-1i*random(3:2+cfg.nFrequency));
forcingOmega = [omega,omega+sideband,omega-sideband]';
forcingCoefficient = [0.5*forcingCoefficient,-0.25*forcingCoefficient, ...
    -0.25*forcingCoefficient].';
particular = (forcingCoefficient*modalLoad')./ ...
    (modalK'-forcingOmega.^2+1i*forcingOmega*modalC');
q0 = real(sum(particular,1));
v0 = real(sum((1i*forcingOmega).*particular,1));
decay = modalC/2;
split = sqrt(complex(decay.^2-modalK));
useState = any(abs(split)<1e-3*sqrt(modalK));
pole1 = -decay+split;
pole2 = -decay-split;
if useState
    poles = 1i*forcingOmega;
    displacement = particular*modes';
else
    transient1 = (-v0+pole2.'.*q0)./(pole1-pole2).';
    transient2 = -q0-transient1;
    poles = [1i*forcingOmega;pole1;pole2];
    displacement = [particular;diag(transient1);diag(transient2)]*modes';
end
velocity = poles.*displacement;
capacity = cfg.thresholds.*exp(design(3:2+cfg.nMode));
[mapU,mapV,mapA] = mrfp.outputMaps(cfg);
% Ground-input feedthrough cancels in absolute acceleration.
assert(cfg.caseName~="sdof" || ~any(mapA,'all'), ...
    'mrfp:OutputMap','External-force acceleration outputs require a feedthrough term.');
mapU = mapU-mapA*(mass\stiffness);
mapV = mapV-mapA*(mass\damping);
coefficients = (displacement*mapU'+velocity*mapV')./capacity;
series = struct('poles',poles,'coefficients',coefficients, ...
    'displacementCoefficients',displacement,'mass',mass, ...
    'stiffness',stiffness,'damping',damping,'loadVector',loadVector, ...
    'forcingOmega',forcingOmega,'forcingCoefficient',forcingCoefficient, ...
    'duration',cfg.duration,'capacity',capacity, ...
    'law',struct('mu',log(cfg.amplitudeMedian)+design(end-1), ...
    'sigma',cfg.amplitudeLogSd*exp(design(end))));
if useState
    series.transientGenerators = zeros(2,2,nDof);
    series.transientInitial = zeros(2,nDof);
    series.transientDemand = zeros(2,cfg.nMode,nDof);
    series.transientDisplacement = zeros(2,nDof,nDof);
    for j = 1:nDof
        natural = sqrt(modalK(j));
        generator = [0,natural;-natural,-modalC(j)];
        displacementOutput = [modes(:,j)'/natural;zeros(1,nDof)];
        velocityOutput = generator'*displacementOutput;
        output = (displacementOutput*mapU'+velocityOutput*mapV')./capacity;
        series.transientGenerators(:,:,j) = generator;
        series.transientInitial(:,j) = [-natural*q0(j);-v0(j)];
        series.transientDemand(:,:,j) = output;
        series.transientDisplacement(:,:,j) = displacementOutput;
    end
end
end
