function verification = verifySensitivity(cfg, inputs)
%verifySensitivity Compare tangent/moving-frontier derivatives with CRN FD.
arguments
    cfg (1,1) struct
    inputs (:,:) double
end
n = min(cfg.nSensitivity,size(inputs,1));
p = cfg.nPathParameter+2;
m = cfg.nMode+1;
analytic = zeros(m,p);
frozen = analytic;
finiteDifference = zeros(m,p,2);
steps = [2e-4,1e-4];
zero = zeros(1,p);
for sample = 1:n
    path = mrfp.solveTrajectory(cfg,inputs(sample,:),zero);
    event = mrfp.integrateFrontier(path.time,path.demand,path.tangent,path.law);
    analytic = analytic + reshape(event.gradient(end,:,:),m,p)/n;
    frozen = frozen + reshape(event.frozenGradient(end,:,:),m,p)/n;
    for parameter = 1:p
        for level = 1:2
            offset = zero;
            offset(parameter) = steps(level);
            plus = perturbPath(cfg,inputs(sample,:),path,offset,parameter);
            minus = perturbPath(cfg,inputs(sample,:),path,-offset,parameter);
            finiteDifference(:,parameter,level) = finiteDifference(:,parameter,level) + ...
                (plus.cause(end,:)'-minus.cause(end,:)')/(2*steps(level)*n);
        end
    end
end
verification = struct('analytic',analytic,'frozen',frozen,'finiteDifference',finiteDifference, ...
    'steps',steps,'maxAbsoluteError',max(abs(analytic-finiteDifference(:,:,2)),[],'all'), ...
    'maxFrozenError',max(abs(frozen-finiteDifference(:,:,2)),[],'all'), ...
    'stepDifference',max(abs(finiteDifference(:,:,1)-finiteDifference(:,:,2)),[],'all'), ...
    'transferConservation',max(abs(sum(analytic-frozen,1))),'nInput',n);
end

function event = perturbPath(cfg,input,path,offset,parameter)
if parameter <= 2
    path = mrfp.solveTrajectory(cfg,input,offset,cfg.dt,false);
elseif parameter <= cfg.nPathParameter
    mode = parameter - 2;
    path.demand(:,mode) = path.demand(:,mode)*exp(-offset(parameter));
elseif parameter == cfg.nPathParameter+1
    path.law.mu = path.law.mu + offset(parameter);
else
    path.law.sigma = path.law.sigma*exp(offset(parameter));
end
event = mrfp.integrateFrontier(path.time,path.demand,zeros(size(path.demand,1),cfg.nMode,1),path.law);
end
