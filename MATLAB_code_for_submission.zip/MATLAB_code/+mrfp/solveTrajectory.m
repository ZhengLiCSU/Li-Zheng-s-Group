function path = solveTrajectory(cfg, random, design, dt, withTangent)
%solveTrajectory Linear Newmark response and discrete-consistent tangents.
% Positive excitation amplitude is omitted and later integrated analytically.
arguments
    cfg (1,1) struct
    random (1,:) double {mustBeFinite}
    design (1,:) double {mustBeFinite}
    dt (1,1) double {mustBePositive} = cfg.dt
    withTangent (1,1) logical = true
end
assert(numel(random) == cfg.nInput && numel(design) == cfg.nPathParameter+2, ...
    'mrfp:InputSize','Random/design vector length does not match the configuration.');
time = (0:dt:cfg.duration)';
nTime = numel(time);
omega = 2*pi*cfg.frequency;
weights = ones(1,cfg.nFrequency)/sqrt(cfg.nFrequency);
if isfield(cfg,'frequencyWeights'), weights = cfg.frequencyWeights; end
assert(numel(weights)==cfg.nFrequency && all(isfinite(weights)), ...
    'mrfp:FrequencyWeights','Provide one finite weight per load frequency.');
shape = sin(time*omega)*(weights.*random(3:2+cfg.nFrequency))' + ...
    cos(time*omega)*(weights.*random(3+cfg.nFrequency:end))';
envelope = sin(pi*time/cfg.duration).^2;
forcing = cfg.excitationScale*envelope.*shape;
mass = cfg.mass;
baseStiffness = cfg.stiffness;
nDof = size(mass,1);
scaleK = exp(cfg.stiffnessLogSd*random(1)+design(1));
scaleC = exp(cfg.dampingLogSd*random(2)+design(2));
stiffness = scaleK*baseStiffness;
frequency = sqrt(sort(eig(baseStiffness,mass)));
baseDamping = mrfp.baseDamping(cfg,frequency);
damping = scaleC*sqrt(scaleK)*baseDamping;
loadVector = ones(nDof,1);
isGroundMotion = cfg.caseName~="sdof";
if isGroundMotion
    loadVector = -mass*loadVector;
end
beta = 1/4;
gamma = 1/2;
a0 = 1/(beta*dt^2);
a1 = gamma/(beta*dt);
a2 = 1/(beta*dt);
a3 = 1/(2*beta)-1;
a4 = gamma/beta-1;
a5 = dt*(gamma/(2*beta)-1);
effective = stiffness + a0*mass + a1*damping;
factor = decomposition(effective,'chol');
u = zeros(nDof,nTime);
v = u;
acc = u;
uD = zeros(nDof,2);
vD = uD;
aD = uD;
demand = zeros(nTime,cfg.nMode);
tangent = zeros(nTime,cfg.nMode,cfg.nPathParameter);
capacity = cfg.thresholds.*exp(design(3:2+cfg.nMode));
[mapU,mapV,mapA] = mrfp.outputMaps(cfg);
for k = 2:nTime
    rhs = loadVector*forcing(k) + mass*(a0*u(:,k-1)+a2*v(:,k-1)+a3*acc(:,k-1)) + ...
        damping*(a1*u(:,k-1)+a4*v(:,k-1)+a5*acc(:,k-1));
    u(:,k) = factor\rhs;
    acc(:,k) = a0*(u(:,k)-u(:,k-1)) - a2*v(:,k-1) - a3*acc(:,k-1);
    v(:,k) = v(:,k-1) + dt*((1-gamma)*acc(:,k-1)+gamma*acc(:,k));
    if withTangent
        loadD = [-stiffness*u(:,k)-0.5*damping*v(:,k),-damping*v(:,k)];
        rhsD = loadD + mass*(a0*uD+a2*vD+a3*aD) + damping*(a1*uD+a4*vD+a5*aD);
        nextUD = factor\rhsD;
        nextAD = a0*(nextUD-uD) - a2*vD - a3*aD;
        nextVD = vD + dt*((1-gamma)*aD+gamma*nextAD);
        uD = nextUD;
        vD = nextVD;
        aD = nextAD;
    end
    absoluteAcceleration = acc(:,k)+isGroundMotion*forcing(k);
    signed = (mapU*u(:,k)+mapV*v(:,k)+mapA*absoluteAcceleration)';
    signedD = mapU*uD+mapV*vD+mapA*aD;
    demand(k,:) = signed./capacity;
    if withTangent
        tangent(k,:,1:2) = signedD./capacity';
        for mode = 1:cfg.nMode
            tangent(k,mode,2+mode) = -demand(k,mode);
        end
    end
end
law = struct('mu',log(cfg.amplitudeMedian)+design(end-1), ...
    'sigma',cfg.amplitudeLogSd*exp(design(end)));
path = struct('time',time,'demand',demand,'tangent',tangent, ...
    'law',law,'forcing',forcing,'displacement',u','velocity',v', ...
    'acceleration',acc','capacity',capacity);
end
