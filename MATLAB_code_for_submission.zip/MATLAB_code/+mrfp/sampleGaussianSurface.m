function result = sampleGaussianSurface(operator, selectedRows, n, seed)
%sampleGaussianSurface Existing surface-decomposition total capacity derivative.
% Derivative w.r.t. a COMMON log-capacity scaling on selected response rows.
% Fixed Gaussian operator; zero-mean excitation; symmetric positive limits.
% Ref: Xian et al., arXiv:2510.22558, constrained component surface integrals.
arguments
    operator (:,:) double {mustBeFinite}
    selectedRows (:,1) logical
    n (1,1) double {mustBePositive,mustBeInteger}
    seed (1,1) double {mustBeNonnegative,mustBeInteger}
end
assert(numel(selectedRows)==size(operator,1),'mrfp:SurfaceSize','Row mask must match operator.');
rowNorm = vecnorm(operator,2,2);
positive = rowNorm>0;
if ~any(positive & selectedRows)
    result = struct('estimate',0,'standardError',0,'contribution',zeros(1,n), ...
        'activeFraction',0,'normalizer',0);
    return
end
canonical = operator(positive,:);
[~,first] = max(abs(canonical)>0,[],2);
orientation = sign(canonical(sub2ind(size(canonical),(1:size(canonical,1))',first)));
canonical = canonical.*orientation;
assert(size(unique(canonical,'rows'),1)==size(canonical,1), ...
    'mrfp:CoincidentSurface','Coincident boundaries need a separate nonsmooth treatment.');
beta = 1./rowNorm;
component = 2*exp(-0.5*beta.^2)./(sqrt(2*pi)*rowNorm);
component(~positive | ~selectedRows) = 0;
normalizer = sum(component);
assert(normalizer>0 && isfinite(normalizer), ...
    'mrfp:SurfaceUnderflow','No numerically resolved selected boundary.');
indices = find(component>0);
distribution = cumsum(component(indices))/normalizer;
distribution(end) = 1;
state = rng;
cleanup = onCleanup(@() rng(state));
rng(seed,'twister');
points = randn(size(operator,2),n);
choice = rand(1,n);
signs = 2*(rand(1,n)>=0.5)-1;
selected = zeros(1,n);
for i = 1:n
    row = indices(find(distribution>=choice(i),1));
    direction = signs(i)*operator(row,:)'/rowNorm(row);
    points(:,i) = points(:,i)+(beta(row)-direction'*points(:,i))*direction;
    selected(i) = row;
end
response = abs(operator*points);
response(sub2ind(size(response),selected,1:n)) = 0;
active = all(response<=1+64*eps,1);
contribution = -normalizer*double(active);
result = struct('estimate',mean(contribution),'standardError',std(contribution)/sqrt(n), ...
    'contribution',contribution,'activeFraction',mean(active),'normalizer',normalizer);
end
