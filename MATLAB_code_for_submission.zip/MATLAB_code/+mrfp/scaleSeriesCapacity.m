function series = scaleSeriesCapacity(series, mode, factor)
%scaleSeriesCapacity Change one normalized capacity without changing dynamics.
arguments
    series (1,1) struct
    mode (1,1) double {mustBePositive,mustBeInteger}
    factor (1,1) double {mustBePositive,mustBeFinite}
end
assert(mode<=size(series.coefficients,2),'mrfp:Mode','Mode index exceeds response dimension.');
series.coefficients(:,mode) = series.coefficients(:,mode)/factor;
series.capacity(mode) = series.capacity(mode)*factor;
if isfield(series,'transientDemand')
    series.transientDemand(:,mode,:) = series.transientDemand(:,mode,:)/factor;
end
end
