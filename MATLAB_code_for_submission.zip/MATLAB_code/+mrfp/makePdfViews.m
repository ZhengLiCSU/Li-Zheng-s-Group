function views = makePdfViews(time, normalizedPaths, cfg)
%makePdfViews Produce evolving 1D and paired 2D DPIM response densities.
arguments
    time (:,1) double
    normalizedPaths (:,:,:) double
    cfg (1,1) struct
end
nSample = size(normalizedPaths,3);
nNode = 12;
offDiagonal = sqrt((1:nNode-1)/2);
[vectors,values] = eig(diag(offDiagonal,1)+diag(offDiagonal,-1));
normalNodes = sqrt(2)*diag(values);
normalWeights = vectors(1,:)'.^2;
amplitudes = cfg.amplitudeMedian*exp(cfg.amplitudeLogSd*normalNodes);
weights = repmat(normalWeights/nSample,nSample,1);
% Exclude the initial near-Dirac density from the display, not the analysis.
selected = unique(round(linspace(max(2,round(0.15*numel(time))),numel(time),24)));
curveX = zeros(600,numel(selected));
curvePdf = curveX;
masses = zeros(numel(selected),1);
for j = 1:numel(selected)
    signed = reshape(normalizedPaths(selected(j),1,:),1,[])*cfg.thresholds(1);
    samples = reshape(amplitudes*signed,[],1);
    pdf = mrfp.estimatePdf(samples,weights,nSample,600,StandardDeviationRange=6);
    curveX(:,j) = pdf.x;
    curvePdf(:,j) = pdf.density;
    masses(j) = pdf.mass;
end
energy = squeeze(mean(sum(normalizedPaths.^2,2),3));
[~,snapshot] = max(energy);
first = reshape(normalizedPaths(snapshot,1,:),1,[])*cfg.thresholds(1);
second = reshape(normalizedPaths(snapshot,2,:),1,[])*cfg.thresholds(2);
paired = [reshape(amplitudes*first,[],1),reshape(amplitudes*second,[],1)];
joint = mrfp.estimatePdf(paired,weights,nSample,160,StandardDeviationRange=6);
views = struct('time',time(selected),'x',curveX,'density',curvePdf, ...
    'mass',masses,'joint',joint,'jointTime',time(snapshot));
end
