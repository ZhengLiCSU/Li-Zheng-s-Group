function result = refineCauseBounds(series, options)
%refineCauseBounds Uniform bisection stopped by cause attribution uncertainty.
% Stop controls each conditional path, not outer integration/sampling error.
arguments
    series (1,1) struct
    options.InitialStep (1,1) double {mustBePositive} = 0.08
    options.Tolerance (1,1) double {mustBePositive} = 1e-3
    options.MaxRefinement (1,1) double {mustBeInteger,mustBeNonnegative} = 6
end
nCell = ceil(series.duration/options.InitialStep);
history = zeros(options.MaxRefinement+1,5);
startClock = tic;
for level = 0:options.MaxRefinement
    time = linspace(0,series.duration,nCell+1)';
    path = mrfp.evaluateResponseSeries(series,time);
    bounds = mrfp.boundFirstCause(time,path.demand,path.radius,path.law);
    width = max(bounds.width(end,:));
    unresolved = bounds.unresolvedMassUpper(end);
    history(level+1,:) = [series.duration/nCell,nCell+1,width, ...
        bounds.failureUpper(end)-bounds.failureLower(end),unresolved];
    if unresolved<=options.Tolerance
        break
    end
    nCell = nCell*2;
end
result = struct('bounds',bounds,'path',path, ...
    'history',array2table(history(1:level+1,:), ...
    'VariableNames',{'dt','nodes','maxCauseWidth','failureWidth','unresolvedMass'}), ...
    'converged',unresolved<=options.Tolerance, ...
    'tolerance',options.Tolerance,'seconds',toc(startClock));
end
