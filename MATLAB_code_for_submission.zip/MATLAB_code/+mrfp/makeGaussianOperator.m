function operator = makeGaussianOperator(cfg, structural, time)
%makeGaussianOperator Map Gaussian load coefficients to signed demand nodes.
% Rows use MATLAB demand(:) ordering: all times in mode 1, then mode 2, etc.
arguments
    cfg (1,1) struct
    structural (1,2) double {mustBeFinite}
    time (:,1) double {mustBeFinite}
end
nShape = 2*cfg.nFrequency;
operator = zeros(numel(time)*cfg.nMode,nShape);
for i = 1:nShape
    input = [structural,zeros(1,nShape)];
    input(i+2) = 1;
    series = mrfp.makeResponseSeries(cfg,input,zeros(1,cfg.nPathParameter+2));
    demand = mrfp.evaluateSeriesField(series,time);
    operator(:,i) = demand(:);
end
end
