function [estimate,names] = reliabilityStatistics(failureContributions,normal,cfg)
%reliabilityStatistics Same estimands for conditional, MC and mixture IS.
% Contributions have columns [unique modes, joint]; they may be IS weighted.
arguments
    failureContributions (:,:) double {mustBeFinite}
    normal (:,2) double {mustBeFinite}
    cfg (1,1) struct
end
assert(size(failureContributions,1)==size(normal,1) && ...
    size(failureContributions,2)==cfg.nMode+1 && ~isempty(normal), ...
    'mrfp:InputSize','Cause contributions and structural normals must match.');
all = [failureContributions,sum(failureContributions,2)];
score = normal./[cfg.stiffnessLogSd,cfg.dampingLogSd];
estimate = [mean(all,1),mean(all.*score(:,1),1),mean(all.*score(:,2),1)];
base = [cfg.modeNames,"joint","system"];
names = [base,"d_log_stiffness__"+base,"d_log_damping__"+base];
end
