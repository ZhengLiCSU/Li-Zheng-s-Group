function writeTransportFigure(cfg,transportRep,folder)
%writeTransportFigure Display small design flows without a dominant diagonal.
matrix = mean(transportRep,3);
names = [cfg.modeNames,"joint","safe"];
count = numel(names);
flows = matrix; flows(1:count+1:end) = 0;
fig = figure('Visible','off','Color','w','Position',[100,100,1160,460]);
cleanup = onCleanup(@() close(fig));
tiledlayout(1,2,'Padding','compact');
nexttile; imagesc(flows); colorbar; axis square;
xticks(1:count); yticks(1:count); xticklabels(names); yticklabels(names);
set(gca,'TickLabelInterpreter','none');
xtickangle(25); xlabel('After strengthening'); ylabel('Before strengthening');
title(cfg.caseName+": off-diagonal first-cause transport",'Interpreter','none');
limit = max(flows,[],'all');
if limit>0, clim([0,limit]); end
for row = 1:count
    for col = 1:count
        label = "-";
        if row~=col, label = string(sprintf('%.2g',flows(row,col))); end
        color = 'w';
        if flows(row,col)>0.55*limit && limit>0, color = 'k'; end
        text(col,row,label,'HorizontalAlignment','center','Color',color,'FontSize',9);
    end
end
nexttile;
rescued = matrix(1,end); substituted = sum(matrix(1,2:cfg.nMode));
bars = [rescued,substituted];
bar(bars); xticklabels({'Failure prevented','Cause changed'});
ylabel('Probability mass'); title('First capacity +5%'); grid on;
if max(bars)>0, ylim([0,1.2*max(bars)]); end
for i = 1:2
    text(i,bars(i),sprintf(' %.4g',bars(i)),'HorizontalAlignment','center', ...
        'VerticalAlignment','bottom');
end
exportgraphics(fig,fullfile(folder,cfg.caseName+'_transport.png'),'Resolution',180);
end
