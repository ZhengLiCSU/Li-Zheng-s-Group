function event = firstEvent(time, demand, amplitude)
%firstEvent Locate the first crossing of piecewise-linear signed responses.
arguments
    time (:,1) double {mustBeFinite}
    demand (:,:) double {mustBeFinite}
    amplitude (1,1) double {mustBePositive,mustBeFinite}
end
nMode = size(demand,2);
modeTime = inf(1,nMode);
level = 1/amplitude;
for mode = 1:nMode
    k = find(abs(demand(:,mode)) >= level,1);
    if isempty(k)
        continue
    end
    if k == 1
        modeTime(mode) = time(1);
    else
        direction = sign(demand(k,mode));
        previous = direction*demand(k-1,mode);
        current = direction*demand(k,mode);
        fraction = (level-previous)/(current-previous);
        modeTime(mode) = time(k-1) + fraction*(time(k)-time(k-1));
    end
end
[firstTime,cause] = min(modeTime);
if isinf(firstTime)
    cause = 0;
elseif nnz(abs(modeTime-firstTime) <= 1e-10*max(1,abs(firstTime))) > 1
    cause = nMode + 1;
end
event = struct('time',firstTime,'cause',cause,'modeTime',modeTime);
end
