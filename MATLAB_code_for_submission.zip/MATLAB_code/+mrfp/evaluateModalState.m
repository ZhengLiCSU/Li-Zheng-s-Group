function states = evaluateModalState(generator, initial, time)
%evaluateModalState Energy-scaled damped oscillator, including critical roots.
arguments
    generator (2,2) double {mustBeFinite}
    initial (2,1) double {mustBeFinite}
    time (:,1) double {mustBeFinite,mustBeNonnegative}
end
decay = -generator(2,2)/2;
split = sqrt(complex(decay^2-generator(1,2)^2));
cosine = (exp((-decay+split)*time)+exp((-decay-split)*time))/2;
sine = zeros(size(time));
small = abs(split*time)<0.1;
z = split*time(small);
% sinh(z)/z series: omitted relative term <=0.1^12/13! < 2e-22.
sine(small) = time(small).*exp(-decay*time(small)).* ...
    (1+z.^2/6+z.^4/120+z.^6/5040+z.^8/362880+z.^10/39916800);
if split~=0
    sine(~small) = (exp((-decay+split)*time(~small))- ...
        exp((-decay-split)*time(~small)))/(2*split);
end
states = real(cosine*initial'+sine*((generator+decay*eye(2))*initial)');
end
