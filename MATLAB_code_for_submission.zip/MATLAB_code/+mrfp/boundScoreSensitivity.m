function result = boundScoreSensitivity(lower, upper, normal, logSd, weights)
%boundScoreSensitivity Propagate cause bounds through a signed Gaussian score.
% Bounds cover the fixed weighted input rule; outer integration error is extra.
arguments
    lower (:,:) double {mustBeFinite}
    upper (:,:) double {mustBeFinite}
    normal (:,:) double {mustBeFinite}
    logSd (1,:) double {mustBeFinite,mustBePositive}
    weights (:,1) double {mustBeFinite,mustBeNonnegative}
end
assert(isequal(size(lower),size(upper)) && all(lower<=upper+1e-12,'all') && ...
    size(lower,1)==size(normal,1) && numel(weights)==size(normal,1) && ...
    numel(logSd)==size(normal,2) && abs(sum(weights)-1)<1e-10, ...
    'mrfp:ScoreSize','Bounds, score inputs and normalized weights must match.');
score = normal./logSd;
positive = max(score,0).*weights;
negative = min(score,0).*weights;
result = struct('lower',lower'*positive+upper'*negative, ...
    'upper',upper'*positive+lower'*negative);
end
