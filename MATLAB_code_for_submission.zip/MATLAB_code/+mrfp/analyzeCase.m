function result = analyzeCase(cfg)
%analyzeCase Estimate marked first-passage curves and design sensitivities.
arguments
    cfg (1,1) struct
end
timer = tic;
design = zeros(1,cfg.nPathParameter+2);
nTime = numel(0:cfg.dt:cfg.duration);
nCause = cfg.nMode + 1;
nGradient = numel(design);
replicateCause = zeros(nTime,nCause,cfg.nReplicate);
replicateGradient = zeros(nCause,nGradient,cfg.nReplicate);
replicateFrozen = replicateGradient;
replicateExchange = replicateGradient;
replicateBoundary = replicateGradient;
replicateWeakStructural = zeros(nCause,2,cfg.nReplicate);
terminalRecords = zeros(cfg.nSample,cfg.nReplicate);
conditionalProbability = terminalRecords;
individualModeProbability = zeros(nTime,cfg.nMode);
legacyEstimates = zeros(cfg.nReplicate,4);
storedPaths = zeros(nTime,cfg.nMode,cfg.nSample);
unitInputs = [];
for replicate = 1:cfg.nReplicate
    allRandom = mrfp.sampleInputs(cfg.nSample,cfg.nInput+1,cfg.seed+replicate,"rqmc");
    random = allRandom(:,1:cfg.nInput);
    if replicate == 1
        unitInputs = random;
    end
    for sample = 1:cfg.nSample
        path = mrfp.solveTrajectory(cfg,random(sample,:),design);
        event = mrfp.integrateFrontier(path.time,path.demand,path.tangent,path.law);
        assert(event.gradientValid,'mrfp:Nondifferentiable', ...
            'Positive-mass coincident modes make ordinary marked derivatives undefined.');
        replicateCause(:,:,replicate) = replicateCause(:,:,replicate) + event.cause/cfg.nSample;
        score = random(sample,1:2)./[cfg.stiffnessLogSd,cfg.dampingLogSd];
        replicateWeakStructural(:,:,replicate) = replicateWeakStructural(:,:,replicate) + ...
            event.cause(end,:)'*score/cfg.nSample;
        replicateGradient(:,:,replicate) = replicateGradient(:,:,replicate) + ...
            reshape(event.gradient(end,:,:),nCause,nGradient)/cfg.nSample;
        replicateFrozen(:,:,replicate) = replicateFrozen(:,:,replicate) + ...
            reshape(event.frozenGradient(end,:,:),nCause,nGradient)/cfg.nSample;
        replicateExchange(:,:,replicate) = replicateExchange(:,:,replicate) + ...
            reshape(event.exchangeGradient(end,:,:),nCause,nGradient)/cfg.nSample;
        replicateBoundary(:,:,replicate) = replicateBoundary(:,:,replicate) + ...
            reshape(event.boundaryGradient(end,:,:),nCause,nGradient)/cfg.nSample;
        terminalRecords(sample,replicate) = event.record(end);
        conditionalProbability(sample,replicate) = event.failure(end);
        perModeRecord = cummax(abs(path.demand),1);
        perModeZ = (log(max(perModeRecord,realmin))+path.law.mu)/path.law.sigma;
        individualModeProbability = individualModeProbability + ...
            0.5*erfc(-perModeZ/sqrt(2))/(cfg.nSample*cfg.nReplicate);
        if replicate == 1
            storedPaths(:,:,sample) = path.demand;
        end
    end
    amplitude = exp(log(cfg.amplitudeMedian)+cfg.amplitudeLogSd*allRandom(:,end));
    margin = 1-amplitude.*terminalRecords(:,replicate);
    bandwidth = max(eps,min(std(margin),iqr(margin)/1.34)*cfg.nSample^(-0.2));
    factors = [0.25,0.5,1,2];
    legacyEstimates(replicate,:) = mean(0.5*erfc(margin./(bandwidth*factors)/sqrt(2)),1);
    fprintf('%s: RQMC replicate %d/%d finished.\n',cfg.caseName,replicate,cfg.nReplicate);
end
cause = mean(replicateCause,3);
failureReplicate = squeeze(sum(replicateCause,2));
standardError = std(failureReplicate,0,2)/sqrt(cfg.nReplicate);
critical = tinv(0.975,cfg.nReplicate-1);
gradient = mean(replicateGradient,3);
frozen = mean(replicateFrozen,3);
gradientSE = std(replicateGradient,0,3)/sqrt(cfg.nReplicate);
probability = conditionalProbability(:);
rbVariance = var(probability,1);
bernoulliVariance = rbVariance + mean(probability.*(1-probability));
result = struct('config',cfg,'time',path.time,'cause',cause, ...
    'failure',sum(cause,2),'survival',1-sum(cause,2),'standardError',standardError, ...
    'ciHalfWidth',critical*standardError,'gradient',gradient,'gradientSE',gradientSE, ...
    'frozenGradient',frozen,'transferGradient',gradient-frozen, ...
    'exchangeGradient',mean(replicateExchange,3),'boundaryGradient',mean(replicateBoundary,3), ...
    'replicateCause',replicateCause,'replicateGradient',replicateGradient, ...
    'weakStructuralGradient',mean(replicateWeakStructural,3), ...
    'weakStructuralGradientSE',std(replicateWeakStructural,0,3)/sqrt(cfg.nReplicate), ...
    'gradientTarget','Mean conditional PWL derivative; population interchange requires additional regularity', ...
    'terminalRecords',terminalRecords,'unitInputs',unitInputs, ...
    'individualModeProbability',individualModeProbability, ...
    'independentModesApproximation',1-prod(1-individualModeProbability,2), ...
    'legacyBandwidthFactors',[0.25,0.5,1,2],'legacyDpimEstimates',legacyEstimates, ...
    'unitPaths',storedPaths,'rbVarianceRatio',bernoulliVariance/max(rbVariance,eps), ...
    'analysisSeconds',toc(timer),'dynamicCalls',cfg.nSample*cfg.nReplicate);
end
