function result = capacityDesignPath(time,demand,law,target,factors)
%capacityDesignPath Common-input first-cause transport along a capacity path.
% Each factor is relative to the SAME original design, not the previous one.
arguments
    time (:,1) double {mustBeFinite}
    demand (:,:) double {mustBeFinite}
    law (1,1) struct
    target (1,1) double {mustBePositive,mustBeInteger}
    factors (1,:) double {mustBeFinite,mustBeGreaterThanOrEqual(factors,1)}
end
nMode = size(demand,2); nCategory = nMode+2;
assert(target<=nMode && ~isempty(factors) && all(diff(factors)>=0), ...
    'mrfp:DesignPath','Target and ordered capacity factors must be valid.');
labels = [1:nMode,1:nMode];
base = mrfp.integrateBranches(time,[demand,-demand],labels,law,StorePartition=true);
transport = zeros(nCategory,nCategory,numel(factors));
metrics = zeros(numel(factors),6);
for k = 1:numel(factors)
    if factors(k)==1
        changed = base;
    else
        scaled = demand; scaled(:,target) = scaled(:,target)/factors(k);
        changed = mrfp.integrateBranches(time,[scaled,-scaled],labels,law,StorePartition=true);
    end
    paired = mrfp.transportPartitions(base.partition,changed.partition,law,nCategory);
    transport(:,:,k) = paired.matrix;
    rescued = paired.matrix(target,end);
    substitution = sum(paired.matrix(target,1:end-1))-paired.matrix(target,target);
    metrics(k,:) = [base.failure(end),changed.failure(end), ...
        base.uniqueCause(end,target),changed.uniqueCause(end,target),rescued,substitution];
end
result = struct('transport',transport,'metrics',metrics, ...
    'metricNames',["systemBefore","systemAfter","targetBefore","targetAfter","rescued","substituted"]);
end
