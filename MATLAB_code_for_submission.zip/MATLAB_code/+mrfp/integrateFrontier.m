function result = integrateFrontier(time, demand, tangent, law)
%integrateFrontier Integrate marked first passage over excitation amplitude.
% demand: time-by-mode SIGNED normalized unit-amplitude responses.
% tangent: time-by-mode-by-parameter derivatives of demand.
% Exact for the piecewise LINEAR interpolation of the signed demands;
% not exact for the continuous ODE trajectory. Last cause is joint/tied.
arguments
    time (:,1) double {mustBeFinite}
    demand (:,:) double {mustBeFinite}
    tangent (:,:,:) double {mustBeFinite}
    law (1,1) struct
end
[nTime, nMode] = size(demand);
assert(numel(time) == nTime && all(diff(time) > 0), 'mrfp:Time', ...
    'Time must increase and match the response rows.');
assert(size(tangent,1) == nTime && size(tangent,2) == nMode, ...
    'mrfp:TangentSize', 'Tangent dimensions must match demand.');
assert(law.sigma > 0, 'mrfp:AmplitudeLaw', 'Lognormal sigma must be positive.');
nParameter = size(tangent,3);
nGradient = nParameter + 2;
cause = zeros(nTime,nMode+1);
gradient = zeros(nTime,nMode+1,nGradient);
frozen = gradient;
recordCurve = zeros(nTime,1);
direct = zeros(nTime,1);
directGradient = zeros(nTime,nGradient);
boundaryGradient = zeros(nTime,nMode+1,nGradient);
recordCause = 0;
record = max(abs(demand(1,:)));
recordD = zeros(1,nParameter);
recordFrozenD = recordD;
gradientValid = true;
switchCount = 0;
if record > 0
    winners = find(abs(abs(demand(1,:))-record) <= 32*eps(record));
    winner = winners(1);
    causeIndex = winner;
    if numel(winners) > 1
        causeIndex = nMode + 1;
        gradientValid = false;
    end
    recordD = sign(demand(1,winner))*reshape(tangent(1,winner,:),1,[]);
    recordFrozenD = recordD;
    [mass, massD] = mrfp.amplitudeMass(record,recordD,law);
    cause(1,causeIndex) = mass;
    gradient(1,causeIndex,:) = massD;
    frozen(1,causeIndex,:) = massD;
    recordCause = causeIndex;
    if nnz(demand(1,:))>1
        % At t=0 all already-failed modes are simultaneous, even when their
        % response values differ. The active subset depends on the threshold.
        initial = abs(demand(1,:));
        initialCuts = unique([0,initial]);
        cause(1,:) = 0;
        for j = 2:numel(initialCuts)
            activeInitial = find(initial>=(initialCuts(j-1)+initialCuts(j))/2);
            bucket = nMode+1;
            if isscalar(activeInitial)
                bucket = activeInitial;
            end
            increment = mrfp.amplitudeMass(initialCuts(j),zeros(1,nParameter),law) - ...
                mrfp.amplitudeMass(initialCuts(j-1),zeros(1,nParameter),law);
            cause(1,bucket) = cause(1,bucket)+increment;
        end
        gradientValid = false;
    end
end
[direct(1),directGradient(1,:)] = mrfp.amplitudeMass(record,recordD,law);
if recordCause > 0
    boundaryGradient(1,recordCause,1:nParameter) = directGradient(1,1:nParameter);
end
recordCurve(1) = record;
for k = 2:nTime
    cause(k,:) = cause(k-1,:);
    gradient(k,:,:) = gradient(k-1,:,:);
    frozen(k,:,:) = frozen(k-1,:,:);
    endpoints = [demand(k-1,:); demand(k,:)];
    if max(abs(endpoints(2,:))) > record
        y0 = [endpoints(1,:), -endpoints(1,:)];
        y1 = [endpoints(2,:), -endpoints(2,:)];
        d0Physical = reshape(tangent(k-1,:,:),nMode,nParameter);
        d1Physical = reshape(tangent(k,:,:),nMode,nParameter);
        d0 = [d0Physical; -d0Physical];
        d1 = [d1Physical; -d1Physical];
        labels = [1:nMode, 1:nMode];
        keep = max(y0,y1) > record;
        y0 = y0(keep);
        y1 = y1(keep);
        d0 = d0(keep,:);
        d1 = d1(keep,:);
        labels = labels(keep);
        slopes = y1 - y0;
        slopeD = d1 - d0;
        [cuts,cutD] = findCuts(y0,slopes,d0,slopeD);
        for j = 1:numel(cuts)-1
            midpoint = 0.5*(cuts(j)+cuts(j+1));
            values = y0 + midpoint*slopes;
            [~,active] = max(values);
            right = cuts(j+1);
            next = y0(active) + right*slopes(active);
            if next <= record
                continue
            end
            newD0 = d0(active,:) + right*slopeD(active,:);
            newD = newD0 + slopes(active)*cutD(j+1,:);
            sameLine = abs(y0-y0(active)) <= 32*eps(max(realmin,abs(y0(active)))) & ...
                abs(slopes-slopes(active)) <= 32*eps(max(realmin,abs(slopes(active))));
            ties = unique(labels(sameLine));
            causeIndex = labels(active);
            if numel(ties) > 1
                causeIndex = nMode + 1;
                gradientValid = false;
            end
            [mass, massD] = mrfp.amplitudeMass(next,newD,law);
            [oldMass, oldD] = mrfp.amplitudeMass(record,recordD,law);
            [~, massFrozenD] = mrfp.amplitudeMass(next,newD0,law);
            [~, oldFrozenD] = mrfp.amplitudeMass(record,recordFrozenD,law);
            cause(k,causeIndex) = cause(k,causeIndex) + mass - oldMass;
            gradient(k,causeIndex,:) = reshape(gradient(k,causeIndex,:),1,[]) + massD - oldD;
            frozen(k,causeIndex,:) = reshape(frozen(k,causeIndex,:),1,[]) + massFrozenD - oldFrozenD;
            switchCount = switchCount + double(right < 1 && any(cutD(j+1,:) ~= 0));
            record = next;
            recordCause = causeIndex;
            recordD = newD;
            recordFrozenD = newD0;
        end
    end
    recordCurve(k) = record;
    [direct(k),directGradient(k,:)] = mrfp.amplitudeMass(record,recordD,law);
    if recordCause > 0
        boundaryGradient(k,recordCause,1:nParameter) = directGradient(k,1:nParameter);
    end
end
exchangeGradient = gradient - boundaryGradient;
exchangeGradient(:,:,nParameter+1:end) = 0;
result = struct('time',time,'cause',cause,'failure',sum(cause,2), ...
    'survival',1-sum(cause,2),'gradient',gradient,'frozenGradient',frozen, ...
    'transferGradient',gradient-frozen,'record',recordCurve, ...
    'directFailure',direct,'directGradient',directGradient, ...
    'boundaryGradient',boundaryGradient,'exchangeGradient',exchangeGradient, ...
    'gradientValid',gradientValid,'movingBoundaries',switchCount);
if ~gradientValid
    result.gradient(:) = NaN;
    result.frozenGradient(:) = NaN;
    result.transferGradient(:) = NaN;
    result.directGradient(:) = NaN;
    result.boundaryGradient(:) = NaN;
    result.exchangeGradient(:) = NaN;
end
end

function [cuts,cutD] = findCuts(y0,slopes,d0,slopeD)
n = numel(y0);
nParameter = size(d0,2);
capacity = 2 + n*(n-1)/2;
cuts = zeros(capacity,1);
cutD = zeros(capacity,nParameter);
cuts(2) = 1;
count = 2;
for i = 1:n-1
    for j = i+1:n
        denominator = slopes(i) - slopes(j);
        if abs(denominator) <= 32*eps(max([realmin,abs(slopes(i)),abs(slopes(j))]))
            continue
        end
        alpha = -(y0(i)-y0(j))/denominator;
        if alpha > 1e-12 && alpha < 1-1e-12
            count = count + 1;
            cuts(count) = alpha;
            cutD(count,:) = -(d0(i,:)-d0(j,:) + alpha*(slopeD(i,:)-slopeD(j,:)))/denominator;
        end
    end
end
[cuts,order] = sort(cuts(1:count));
cutD = cutD(order,:);
uniqueCut = [true; diff(cuts) > 1e-12];
cuts = cuts(uniqueCut);
cutD = cutD(uniqueCut,:);
end
