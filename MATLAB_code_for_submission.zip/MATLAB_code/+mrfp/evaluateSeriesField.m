function value = evaluateSeriesField(series, time, derivativeOrder, field)
%evaluateSeriesField Stable analytic demand/displacement and time derivatives.
arguments
    series (1,1) struct
    time (:,1) double {mustBeFinite,mustBeNonnegative}
    derivativeOrder (1,1) double {mustBeNonnegative,mustBeInteger} = 0
    field (1,1) string {mustBeMember(field,["demand","displacement"])} = "demand"
end
coefficients = series.coefficients;
if field=="displacement"
    coefficients = series.displacementCoefficients;
end
% Harmonic poles depend on the forcing grid, not the random structural input.
% Cache one basis only; exact keys prevent reuse across times or spectra.
persistent cachedTime cachedPoles cachedBasis
weighted = series.poles.^derivativeOrder.*coefficients;
if isfield(series,'forcingOmega')
    nForced = numel(series.forcingOmega);
    forcedPoles = series.poles(1:nForced);
    if ~isequal(time,cachedTime) || ~isequal(forcedPoles,cachedPoles)
        cachedTime = time; cachedPoles = forcedPoles;
        cachedBasis = exp(time*forcedPoles.');
    end
    value = real(cachedBasis*weighted(1:nForced,:));
    if nForced<numel(series.poles)
        value = value+real(exp(time*series.poles(nForced+1:end).')*weighted(nForced+1:end,:));
    end
else
    value = real(exp(time*series.poles.')*weighted);
end
if isfield(series,'transientGenerators')
    for j = 1:size(series.transientGenerators,3)
        generator = series.transientGenerators(:,:,j);
        states = mrfp.evaluateModalState(generator,series.transientInitial(:,j),time);
        output = series.transientDemand(:,:,j);
        if field=="displacement"
            output = series.transientDisplacement(:,:,j);
        end
        value = value+states*(generator'^derivativeOrder)*output;
    end
end
end
