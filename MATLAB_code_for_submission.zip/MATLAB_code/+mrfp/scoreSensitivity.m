function derivative = scoreSensitivity(probability, normal, logSd, weights)
%scoreSensitivity Gaussian-location weak derivative, allowing cause jumps.
% Valid only when design p enters solely through exp(logSd.*normal+p).
% This is the classical likelihood-ratio identity, not a new estimator claim.
arguments
    probability (:,:) double {mustBeFinite}
    normal (:,:) double {mustBeFinite}
    logSd (1,:) double {mustBePositive,mustBeFinite}
    weights (:,1) double {mustBeNonnegative,mustBeFinite}
end
assert(size(probability,1)==size(normal,1) && numel(weights)==size(normal,1) && ...
    size(normal,2)==numel(logSd) && abs(sum(weights)-1)<1e-10, ...
    'mrfp:ScoreSize','Input dimensions and normalized weights must match.');
derivative = probability'*(weights.*normal./logSd);
end
