function result = conditionalBatch(cfg,time,inputs,design)
%conditionalBatch Terminal first-cause probabilities from analytic-node PWL.
% Deliberately excludes time-tube work, for identical-output cost comparisons.
arguments
    cfg (1,1) struct
    time (:,1) double {mustBeFinite}
    inputs (:,:) double {mustBeFinite}
    design (1,:) double {mustBeFinite} = []
end
if isempty(design), design = zeros(1,cfg.nPathParameter+2); end
assert(size(inputs,2)==cfg.nInput && ~isempty(inputs), ...
    'mrfp:InputSize','Inputs must have one row per trajectory.');
n = size(inputs,1);
probability = zeros(n,cfg.nMode+2);
records = zeros(n,cfg.nMode);
for i = 1:n
    series = mrfp.makeResponseSeries(cfg,inputs(i,:),design);
    demand = mrfp.evaluateSeriesField(series,time);
    event = mrfp.integrateBranches(time,[demand,-demand], ...
        [1:cfg.nMode,1:cfg.nMode],series.law);
    probability(i,:) = [event.uniqueCause(end,:),event.joint(end),1-event.failure(end)];
    records(i,:) = max(abs(demand),[],1);
end
result = struct('probability',probability,'modeRecords',records);
end
