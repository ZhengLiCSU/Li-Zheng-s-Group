function report = runExcitationAudit()
%runExcitationAudit Deterministic input covariance quadrature check on [0,T].
% This is an excitation check, not a bound on the first-passage probability.
root = fileparts(mfilename('fullpath'));
folder = fullfile(root,'results','robustness_study');
if ~isfolder(folder), mkdir(folder); end
lag = (0:0.002:12)'; levels = [128,256,512,1024,2048,8192,16384];
kernel = zeros(numel(lag),numel(levels));
for j = 1:numel(levels)
    cfg = mrfp.makeBuilding16Config(NFrequency=levels(j));
    % Blocks bound temporary storage when forming the fine reference kernel.
    for left = 1:128:numel(lag)
        index = left:min(left+127,numel(lag));
        kernel(index,j) = cos(2*pi*lag(index)*cfg.frequency)*(cfg.frequencyWeights.^2)';
    end
end
error = max(abs(kernel-kernel(:,end)),[],1);
% For the sin^2 envelope, the maximum product at a fixed lag is cos^4(pi*lag/(2T)).
envelopedError = max(cos(pi*lag/24).^4.*abs(kernel-kernel(:,end)),[],1);
report = table(levels',30./levels',levels'/30,error',envelopedError', ...
    'VariableNames',{'nFrequency','frequencySpacingHz','antiperiodSeconds','maxGridCovarianceError','maxEnvelopedCovarianceError'});
writetable(report,fullfile(folder,'excitation_covariance.csv'));
save(fullfile(folder,'excitation_covariance.mat'),'lag','levels','kernel','report');
fig = figure('Visible','off','Color','w','Position',[50,50,1100,440]);
cleanup = onCleanup(@() close(fig));
tiledlayout(1,2,'Padding','compact');
nexttile; plot(lag,kernel(:,[1,2,3,end]),'LineWidth',1.1); grid on;
xlabel('Lag (s)'); ylabel('Normalized covariance before the envelope');
legend('128 frequencies','256 frequencies','512 frequencies','16384-point quadrature');
nexttile; loglog(levels(1:end-1),error(1:end-1),'o-','LineWidth',1.3); grid on;
xlabel('Number of frequencies'); ylabel('Maximum covariance difference on the lag grid');
exportgraphics(fig,fullfile(folder,'excitation_covariance.png'),'Resolution',180);
print(fig,fullfile(folder,'excitation_covariance.svg'),'-dsvg');
disp(report);
end
