function report = runRobustnessAudit(phase,caseName,profile)
%runRobustnessAudit Fresh-seed audit, preserving all historical result folders.
% Statistical intervals describe replicated randomized QMC, not discretization.
% Spectrum comparisons use independent scrambles; time comparisons are paired.
arguments
    phase (1,1) string {mustBeMember(phase,["time","spectrum","reference","sensitivity"])}
    caseName (1,1) string {mustBeMember(caseName,["sdof","building16"])}
    profile (1,1) string {mustBeMember(profile,["smoke","pilot","study"])} = "study"
end
root = fileparts(mfilename('fullpath'));
oldPath = path; cleanup = onCleanup(@() path(oldPath)); addpath(root);
folder = fullfile(root,'results','robustness_'+profile);
if ~isfolder(folder), mkdir(folder); end
n = 128; batches = 16;
if profile=="pilot", n = 32; batches = 8; end
if profile=="smoke", n = 2; batches = 2; end
if caseName=="sdof"
    cfg = mrfp.makeConfig("sdof","study"); cfg.dt = 0.0025;
else
    cfg = mrfp.makeBuilding16Config("study",NFrequency=512); cfg.dt = 0.0025;
end
switch phase
    case "spectrum"
        assert(caseName=="building16",'mrfp:AuditCase','Spectrum audit is for the CP-shaped building load.');
        levels = [128,256,512,1024]; n = min(n,64);
    case "time"
        levels = [0.01,0.005,0.0025,0.00125];
    case "reference"
        levels = [128,256,512];
        if caseName=="building16", levels = [128,256]; end
        if profile=="smoke", levels = [2,4]; end
    otherwise
        levels = [0.04,0.02,0.01]; n = min(n,32);
end
names = [cfg.modeNames,"joint","safe","system","rescued","substituted", ...
    "system_d_logK","system_d_logC","first_d_logK","first_d_logC"];
value = zeros(batches,numel(names),numel(levels)); seconds = zeros(batches,numel(levels));
if phase=="sensitivity"
    names = ["system_logK","first_logK","system_logC","first_logC"];
    value = zeros(batches,4,numel(levels)); density = value; score = zeros(batches,4);
end
for rep = 1:batches
    seed = 91926000+rep;
    if phase=="time"
        random = mrfp.sampleInputs(n,cfg.nInput,seed);
        timer = tic; time = (0:min(levels):cfg.duration)';
        allQ = zeros(n,numel(names),numel(levels));
        for k = 1:n
            series = mrfp.makeResponseSeries(cfg,random(k,:),zeros(1,cfg.nPathParameter+2));
            fine = mrfp.evaluateSeriesField(series,time);
            for ell = 1:numel(levels)
                index = 1:round(levels(ell)/min(levels)):numel(time);
                allQ(k,:,ell) = metrics(cfg,time(index),fine(index,:),series.law,random(k,:));
            end
        end
        value(rep,:,:) = mean(allQ,1); seconds(rep,:) = toc(timer)/numel(levels);
    elseif phase=="sensitivity"
        random = mrfp.sampleInputs(n,cfg.nInput,seed+60000);
        time = (0:cfg.dt:cfg.duration)';
        base = mrfp.conditionalBatch(cfg,time,random);
        q = [1-base.probability(:,end),base.probability(:,1)];
        sd = [cfg.stiffnessLogSd,cfg.dampingLogSd];
        score(rep,:) = reshape(q'*(random(:,1:2)./sd)/n,1,[]);
        for ell = 1:numel(levels)
            timer = tic; h = levels(ell);
            density(rep,:,ell) = reshape(q'*mrfp.gaussianLocationDifference(random(:,1:2),sd,h)/n,1,[]);
            for j = 1:2
                design = zeros(1,cfg.nPathParameter+2); design(j) = h;
                plus = mrfp.conditionalBatch(cfg,time,random,design);
                minus = mrfp.conditionalBatch(cfg,time,random,-design);
                value(rep,(j-1)*2+(1:2),ell) = mean([minus.probability(:,end)-plus.probability(:,end), ...
                    plus.probability(:,1)-minus.probability(:,1)],1)/(2*h);
            end
            seconds(rep,ell) = toc(timer);
        end
    else
        for ell = 1:numel(levels)
            timer = tic;
            localCfg = cfg; localN = n;
            if phase=="spectrum"
                localCfg = mrfp.makeBuilding16Config("study",NFrequency=levels(ell));
                localCfg.dt = cfg.dt;
            else
                localN = levels(ell);
            end
            % Separate seeds across levels: no artificial pairing of Sobol nets.
            sampling = "rqmc";
            if localCfg.nInput>1111, sampling = "mc"; end % MATLAB Sobol dimension limit.
            random = mrfp.sampleInputs(localN,localCfg.nInput,seed+10000*ell+100000*(phase=="reference"),sampling);
            time = (0:localCfg.dt:localCfg.duration)'; q = zeros(localN,numel(names));
            for k = 1:localN
                series = mrfp.makeResponseSeries(localCfg,random(k,:),zeros(1,localCfg.nPathParameter+2));
                demand = mrfp.evaluateSeriesField(series,time);
                q(k,:) = metrics(localCfg,time,demand,series.law,random(k,:));
            end
            value(rep,:,ell) = mean(q,1); seconds(rep,ell) = toc(timer);
        end
    end
    fprintf('%s %s: batch %d/%d complete.\n',caseName,phase,rep,batches);
    progress = struct('caseName',caseName,'phase',phase,'completed',rep,'batches',batches);
    file = fopen(fullfile(folder,caseName+'_'+phase+'_progress.json'),'w');
    fprintf(file,'%s',jsonencode(progress)); fclose(file);
end
critical = tinv(0.975,batches-1);
family = tinv(1-0.05/(2*numel(names)*numel(levels)),batches-1);
report = table();
for ell = 1:numel(levels)
    for j = 1:numel(names)
        x = value(:,j,ell); delta = x-value(:,j,end);
        row = table(caseName,phase,levels(ell),names(j),mean(x),critical*std(x)/sqrt(batches), ...
            mean(delta),critical*std(delta)/sqrt(batches),family*std(delta)/sqrt(batches), ...
            n,batches,sum(seconds(:,ell)), ...
            'VariableNames',{'caseName','phase','level','metric','estimate','halfWidth95', ...
            'minusFinest','differenceHalf95','differenceFamilyHalf95','n','batches','seconds'});
        if phase=="reference", row.n = levels(ell); end
        report = [report;row]; %#ok<AGROW>
    end
end
report.sampling = repmat("rqmc",height(report),1);
if phase=="spectrum", report.sampling(2+2*report.level>1111) = "mc"; end
if phase=="sensitivity"
    % Compare finite dynamic differences with equal-target density differences.
    % The score is the h->0 limit, not an exactly equal finite-h target.
    for ell = 1:numel(levels)
        rows = (ell-1)*numel(names)+(1:numel(names));
        delta = value(:,:,ell)-density(:,:,ell);
        report.scoreEstimate(rows) = mean(score,1)';
        report.scoreHalf95(rows) = (critical*std(score,0,1)/sqrt(batches))';
        report.densityEstimate(rows) = mean(density(:,:,ell),1)';
        report.dynamicMinusDensity(rows) = mean(delta,1)';
        report.pairedHalf95(rows) = (critical*std(delta,0,1)/sqrt(batches))';
        report.pairedFamilyHalf95(rows) = (family*std(delta,0,1)/sqrt(batches))';
    end
    save(fullfile(folder,caseName+'_'+phase+'.mat'),'cfg','levels','names','value','density','score','seconds','n','batches');
else
    save(fullfile(folder,caseName+'_'+phase+'.mat'),'cfg','levels','names','value','seconds','n','batches');
end
writetable(report,fullfile(folder,caseName+'_'+phase+'.csv'));
disp(report(ismember(report.metric,["system","rescued","substituted","system_logK","first_logK"]),:));
end

function q = metrics(cfg,time,demand,law,random)
m = cfg.nMode; labels = [1:m,1:m];
before = mrfp.integrateBranches(time,[demand,-demand],labels,law,StorePartition=true);
changed = demand; changed(:,1) = changed(:,1)/1.2;
after = mrfp.integrateBranches(time,[changed,-changed],labels,law,StorePartition=true);
transfer = mrfp.transportPartitions(before.partition,after.partition,law,m+2);
p = [before.uniqueCause(end,:),before.joint(end),1-before.failure(end)];
q = [p,before.failure(end),transfer.matrix(1,end),sum(transfer.matrix(1,2:end-1)), ...
    before.failure(end)*random(1:2)./[cfg.stiffnessLogSd,cfg.dampingLogSd], ...
    p(1)*random(1:2)./[cfg.stiffnessLogSd,cfg.dampingLogSd]];
end
