# MATLAB code for marked first-passage reliability

This clean submission package contains the MATLAB implementation accompanying the Structural Safety manuscript *Marked first-passage reliability: cause transfer, sensitivity and numerical resolution*.

## Requirements

- MATLAB R2024b or later.
- Statistics and Machine Learning Toolbox is required for the supplied regression suite and study drivers (scrambled Sobol sampling and distribution quantiles). The core marked-partition functions use base MATLAB operations.

## Quick verification

From the package root, run:

```matlab
startup_submission
run_submission_smoke
```

The smoke run executes the packaged regression suite and writes a local test report under `results/`. The supplied package was tested with 69 passed, 0 failed and 0 incomplete tests. Test output is generated locally and is not distributed in this clean archive.

## Main entry points

```matlab
startup_submission
runStudy("quick")
runBuilding16Study("smoke")
runBuilding16CapacitySweep("smoke")
runBuilding16TimeAudit("building16_nf512_smoke")
run_all_robustness_tests("verify")
```

The SDOF and sixteen-story drivers create their own result folders relative to the package root. The production audit stages should be run in sequence with a separately selected computational budget; the corresponding functions document their checkpoint requirements. `run_submission_smoke` is intended as a quick portability check and is not a replacement for the full production runs reported in the paper.

The time-audit argument is a result-folder name, so run the building smoke study before the time audit shown above. To generate production inputs for the capacity study, run `run_all_robustness_tests("audit_building16")` before `runBuilding16CapacitySweep("study")`. Balanced grid and confirmation stages follow `run_all_robustness_tests("balanced")`; production-label bounds follow the SDOF and building resolution-audit stages. These production calculations require substantially more time than the smoke profiles.

Calling `run_all_robustness_tests("all")` runs all numerical stages and tests. Publication-figure export is separate and requires the authors' Python plotting scripts, which are not included in this source archive. Use `run_all_robustness_tests("verify")` for the short regression suite.

## Contents

- `+mrfp/`: marked record-frontier, response, sensitivity, transport and resolution functions.
- `code/robustness/`: reproducibility, audit and balanced-diagnostic drivers.
- `tests/`: MATLAB unit and regression tests.
- Root `run*.m`: SDOF, sixteen-story, theory and audit entry points.
- `seeds.txt`: seeds used for the reported batches.

The sixteen-story elastic model follows the benchmark configuration reported by Ontiveros-Pérez, Miguel and Miguel (2017) for its lumped masses, story stiffnesses and modal checks. The implementation omits the source paper's friction dampers and defines the stochastic excitation and reliability criteria used here. Model provenance is recorded by DOI in `+mrfp/makeBuilding16Config.m`.

## Reproducibility and scope

All result paths are constructed relative to the package root. This archive contains source code; raw production snapshots and publication-figure scripts are not included. The study drivers generate numerical outputs, including the intermediate results required by later stages. The implementation targets stable linear systems whose response paths are homogeneous in one positive common amplitude; it is not a nonlinear finite-element solver and does not reproduce the friction-damper optimization problem in the cited benchmark.

## Citation and availability

Please cite the accompanying manuscript when using this code. The source archive is available at https://github.com/ZhengLiCSU/Li-Zheng-s-Group/blob/main/MATLAB_code_for_submission.zip. No software DOI is assigned.
