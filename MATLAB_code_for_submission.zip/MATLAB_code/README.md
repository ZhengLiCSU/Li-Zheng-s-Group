# MATLAB code for marked first-passage reliability

This clean submission package contains the MATLAB implementation accompanying the Structural Safety manuscript *Marked first-passage reliability: cause transfer, sensitivity and numerical resolution*.

## Requirements

- MATLAB R2024b or later.
- No proprietary MATLAB toolbox is required for the core marked-partition functions or the regression tests.

## Quick verification

From the package root, run:

```matlab
startup_submission
run_submission_smoke
```

The smoke run executes the packaged regression suite and writes a local test report under `results/`. The supplied package was tested with 69 passed, 0 failed and 0 incomplete tests. Test output is generated locally and is not distributed in this clean archive.

## Main entry points

```matlab
startup_submission
runStudy("quick")
runBuilding16Study("smoke")
runBuilding16CapacitySweep("smoke")
runBuilding16TimeAudit("smoke")
run_all_robustness_tests("verify")
```

The SDOF and sixteen-story drivers create their own result folders relative to the package root. The production audit stages should be run in sequence with a separately selected computational budget; the corresponding functions document their checkpoint requirements. `run_submission_smoke` is intended as a quick portability check and is not a replacement for the full production runs reported in the paper.

## Contents

- `+mrfp/`: marked record-frontier, response, sensitivity, transport and resolution functions.
- `code/robustness/`: reproducibility, audit and balanced-diagnostic drivers.
- `tests/`: MATLAB unit and regression tests.
- Root `run*.m`: SDOF, sixteen-story, theory and audit entry points.
- `seeds.txt`: seeds used for the reported batches.

The sixteen-story elastic model follows the benchmark configuration reported by Ontiveros-Pérez, Miguel and Miguel (2017) for its lumped masses, story stiffnesses and modal checks. The implementation omits the source paper's friction dampers and defines the stochastic excitation and reliability criteria used here. Model provenance is recorded by DOI in `+mrfp/makeBuilding16Config.m`.

## Reproducibility and scope

All paths are constructed relative to the package root. Production result snapshots are intentionally excluded from this public-facing supplement so that the archive contains no machine-specific paths or editorial working history. Run the documented MATLAB entry points to regenerate results. The implementation targets stable linear systems whose response paths are homogeneous in one positive common amplitude; it is not a nonlinear finite-element solver and does not reproduce the friction-damper optimization problem in the cited benchmark.

## Citation and availability

Please cite the accompanying manuscript when using this code. The archive is a submission supplement; it does not claim a public repository DOI or a permanent software release.
