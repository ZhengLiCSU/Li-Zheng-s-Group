function summary = runPaperEvidence(profile,options)
%runPaperEvidence Reproduce V4 experiments, or summarize existing MAT evidence.
% runPaperEvidence("study",RunStudies=false) only reads completed studies.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","study"])} = "study"
    options.RunStudies (1,1) logical = true
end
root = fileparts(mfilename('fullpath')); oldPath = path;
cleanup = onCleanup(@() path(oldPath)); addpath(root);
if options.RunStudies
    runVerification();
    runBudgetBenchmark(profile);
    runSensitivityAudit(profile);
    runCapacityStudy(profile);
end
summary = struct([]);
for name = ["sdof","building"]
    files = [fullfile(root,'results','budget_'+profile,name+'_budget.mat'), ...
        fullfile(root,'results','sensitivity_'+profile,name+'_sensitivity.mat'), ...
        fullfile(root,'results','capacity_'+profile,name+'_capacity.mat')];
    assert(all(isfile(files)),'mrfp:MissingStudy','Run all three studies before summarizing.');
    budget = load(files(1),'reference','estimates','seconds','referenceSeconds','budgets');
    sensitivity = load(files(2),'n','nReplicate','conservation','seconds');
    capacity = load(files(3),'cfg','values','n','nReplicate','factors','seconds', ...
        'maxSystemMonotonicityViolation','maxIdentityError');
    comparison = compareDesigns(capacity.cfg,capacity.factors,capacity.values);
    writetable(comparison,fullfile(root,'results','capacity_'+profile,name+'_paired_designs.csv'));
    row = struct('caseName',name,'budgetReplicates',size(budget.estimates,1), ...
        'nominalBudgets',budget.budgets,'referenceReplicates',size(budget.reference,1), ...
        'sensitivityPointsPerReplicate',sensitivity.n,'sensitivityReplicates',sensitivity.nReplicate, ...
        'capacityPointsPerReplicate',capacity.n,'capacityReplicates',capacity.nReplicate, ...
        'capacityFactors',capacity.factors, ...
        'maxSystemMonotonicityViolation',capacity.maxSystemMonotonicityViolation, ...
        'maxIdentityError',capacity.maxIdentityError,'sensitivityConservation',sensitivity.conservation, ...
        'budgetSecondsIncludingReference',sum(budget.seconds,'all')+sum(budget.referenceSeconds), ...
        'sensitivitySeconds',sum(sensitivity.seconds),'capacitySeconds',sum(capacity.seconds));
    summary = [summary;row]; %#ok<AGROW>
end
folder = fullfile(root,'results','paper_'+profile);
if ~isfolder(folder), mkdir(folder); end
file = fopen(fullfile(folder,'summary.json'),'w','n','UTF-8');
fileCleanup = onCleanup(@() fclose(file));
fprintf(file,'%s',jsonencode(summary,'PrettyPrint',true));
disp(struct2table(summary));
end

function comparison = compareDesigns(cfg,factors,values)
% Compare rescue benefits using the SAME batches across target modes.
comparison = table(); n = size(values,1);
familyCount = nchoosek(cfg.nMode,2)*nnz(factors>1);
critical = tinv(1-0.05/(2*max(1,familyCount)),n-1);
for a = 1:cfg.nMode-1
    for b = a+1:cfg.nMode
        for k = 1:numel(factors)
            difference = values(:,a,k,5)-values(:,b,k,5);
            center = mean(difference); se = std(difference)/sqrt(n);
            half = critical*se;
            row = table(cfg.caseName,cfg.modeNames(a),cfg.modeNames(b),factors(k), ...
                center,se,center-half,center+half,familyCount, ...
                'VariableNames',{'caseName','targetA','targetB','capacityMultiplier', ...
                'rescuedAminusB','pairedStandardError','approximateFamily95Lower', ...
                'approximateFamily95Upper','simultaneousComparisons'});
            comparison = [comparison;row]; %#ok<AGROW>
        end
    end
end
end
