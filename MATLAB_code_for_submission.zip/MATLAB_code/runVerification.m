function result = runVerification()
%runVerification Run meaningful unit tests and save static-analysis evidence.
root = fileparts(mfilename('fullpath'));
oldPath = path;
cleanup = onCleanup(@() path(oldPath));
addpath(root);
folder = fullfile(root,'results','verification');
if ~isfolder(folder)
    mkdir(folder);
end
tests = runtests(fullfile(root,'tests'));
listing = dir(fullfile(root,'**','*.m'));
issueCount = 0;
for i = 1:numel(listing)
    fileName = fullfile(listing(i).folder,listing(i).name);
    issues = checkcode(fileName,'-struct');
    issueCount = issueCount + numel(issues);
end
[~,products] = matlab.codetools.requiredFilesAndProducts(fullfile(root,'runStudy.m'));
result = struct('matlabVersion',version,'testCount',numel(tests), ...
    'passed',nnz([tests.Passed]),'failed',nnz([tests.Failed]), ...
    'incomplete',nnz([tests.Incomplete]),'staticIssueCount',issueCount, ...
    'sourceFileCount',numel(listing),'products',{string({products.Name})});
file = fopen(fullfile(folder,'verification.json'),'w','n','UTF-8');
fileCleanup = onCleanup(@() fclose(file));
fprintf(file,'%s',jsonencode(result,'PrettyPrint',true));
save(fullfile(folder,'verification.mat'),'tests','result');
assert(all([tests.Passed]),'mrfp:TestsFailed','Unit tests did not all pass.');
disp(result);
end
