function summaries = runCertifiedStudy(profile)
%runCertifiedStudy Continuous-time cause bounds and finite design changes.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","study"])} = "study"
end
root = fileparts(mfilename('fullpath'));
oldPath = path;
cleanup = onCleanup(@() path(oldPath));
addpath(root);
folder = fullfile(root,'results','certified_'+profile);
if ~isfolder(folder)
    mkdir(folder);
end
n = 64;
nReplicate = 4;
nResolution = 16;
tolerance = 1e-3;
if profile=="smoke"
    n = 4;
    nReplicate = 2;
    nResolution = 2;
    tolerance = 5e-3;
end
summaries = struct([]);
for name = ["sdof","building"]
    cfg = mrfp.makeConfig(name,"study");
    caseFolder = fullfile(folder,name);
    if ~isfolder(caseFolder)
        mkdir(caseFolder);
    end
    startClock = tic;
    lower = zeros(n,cfg.nMode+1,nReplicate);
    upper = lower;
    nominal = lower;
    unresolved = zeros(n,nReplicate);
    steps = unresolved;
    converged = false(n,nReplicate);
    changedLower = zeros(n,cfg.nMode+1);
    changedUpper = changedLower;
    changedNominal = changedLower;
    firstInputs = [];
    for rep = 1:nReplicate
        inputs = mrfp.sampleInputs(n,cfg.nInput,91011+rep);
        if rep==1
            firstInputs = inputs;
        end
        for i = 1:n
            series = mrfp.makeResponseSeries(cfg,inputs(i,:),zeros(1,cfg.nPathParameter+2));
            r = mrfp.refineCauseBounds(series,Tolerance=tolerance,MaxRefinement=6);
            [lower(i,:,rep),upper(i,:,rep),nominal(i,:,rep)] = endpoint(r.bounds);
            unresolved(i,rep) = r.bounds.unresolvedMassUpper(end);
            steps(i,rep) = r.history.dt(end);
            converged(i,rep) = r.converged;
            if rep==1
                % Same response: strengthen only the first capacity by 5%.
                series = mrfp.scaleSeriesCapacity(series,1,1.05);
                rChange = mrfp.refineCauseBounds(series,Tolerance=tolerance,MaxRefinement=6);
                [changedLower(i,:),changedUpper(i,:),changedNominal(i,:)] = endpoint(rChange.bounds);
            end
        end
        fprintf('%s: cause bounds replicate %d/%d complete\n',name,rep,nReplicate);
    end
    mainSeconds = toc(startClock);
    probability = probabilityTable(lower,upper,nominal,cfg.modeNames);
    writetable(probability,fullfile(caseFolder,'probability_bounds.csv'));
    deltaLower = mean(changedLower-upper(:,:,1),1);
    deltaUpper = mean(changedUpper-lower(:,:,1),1);
    deltaNominal = mean(changedNominal-nominal(:,:,1),1);
    designChange = table([cfg.modeNames,"system"]',deltaLower',deltaNominal',deltaUpper', ...
        'VariableNames',{'quantity','changeLower','changeNominal','changeUpper'});
    writetable(designChange,fullfile(caseFolder,'capacity_5percent_change.csv'));
    resolution = resolutionStudy(cfg,firstInputs(1:nResolution,:));
    writetable(resolution,fullfile(caseFolder,'resolution_bounds.csv'));
    summary = struct('caseName',name,'profile',profile,'nPerReplicate',n, ...
        'nReplicate',nReplicate,'tolerance',tolerance, ...
        'converged',nnz(converged),'pathCount',numel(converged), ...
        'maxUnresolvedMass',max(unresolved,[],'all'), ...
        'meanUnresolvedMass',mean(unresolved,'all'), ...
        'minTimeStep',min(steps,[],'all'),'maxTimeStep',max(steps,[],'all'), ...
        'mainSecondsIncludingDesignChange',mainSeconds, ...
        'fineReferenceBracketViolation',max(resolution.maxViolation), ...
        'continuousODEBoundInExactArithmetic',true,'outwardRounded',false, ...
        'statisticalIntervals','Approximate Bonferroni t intervals across RQMC replicates');
    writeJson(fullfile(caseFolder,'summary.json'),summary);
    save(fullfile(caseFolder,'certified.mat'),'cfg','lower','upper','nominal', ...
        'unresolved','steps','converged','designChange','resolution','summary','probability');
    plotResults(probability,resolution,designChange,caseFolder,name);
    summaries = [summaries;summary]; %#ok<AGROW>
end
counterexample(folder);
writeJson(fullfile(folder,'summary.json'),summaries);
disp(struct2table(summaries));
end

function [lower,upper,nominal] = endpoint(bounds)
lower = [bounds.lower(end,:),bounds.failureLower(end)];
upper = [bounds.upper(end,:),bounds.failureUpper(end)];
nominal = [bounds.nominal(end,:),bounds.failureNominal(end)];
end

function output = probabilityTable(lower,upper,nominal,names)
nReplicate = size(lower,3);
nQuantity = size(lower,2);
repLow = reshape(mean(lower,1),nQuantity,nReplicate);
repHigh = reshape(mean(upper,1),nQuantity,nReplicate);
repNominal = reshape(mean(nominal,1),nQuantity,nReplicate);
averageLow = mean(repLow,2);
averageHigh = mean(repHigh,2);
critical = tinv(1-0.05/(2*nQuantity),nReplicate-1);
samplingLow = max(0,averageLow-critical*std(repLow,0,2)/sqrt(nReplicate));
samplingHigh = min(1,averageHigh+critical*std(repHigh,0,2)/sqrt(nReplicate));
output = table([names,"system"]',averageLow,mean(repNominal,2),averageHigh, ...
    averageHigh-averageLow,samplingLow,samplingHigh, ...
    'VariableNames',{'quantity','quadratureLower','nominal','quadratureUpper', ...
    'timeErrorWidth','approximate95Lower','approximate95Upper'});
end

function output = resolutionStudy(cfg,inputs)
steps = [0.08,0.04,0.02,0.01,0.005];
n = size(inputs,1);
nLevel = numel(steps);
statistics = zeros(n,nLevel,5);
for i = 1:n
    s = mrfp.makeResponseSeries(cfg,inputs(i,:),zeros(1,cfg.nPathParameter+2));
    fine = mrfp.evaluateResponseSeries(s,(0:0.000625:cfg.duration)');
    labels = [1:cfg.nMode,1:cfg.nMode];
    reference = mrfp.integrateBranches(fine.time,[fine.demand,-fine.demand],labels,s.law);
    for level = 1:nLevel
        p = mrfp.evaluateResponseSeries(s,(0:steps(level):cfg.duration)');
        b = mrfp.boundFirstCause(p.time,p.demand,p.radius,s.law);
        violation = max([b.lower(end,:)-reference.uniqueCause(end,:), ...
            reference.inclusiveCause(end,:)-b.upper(end,:), ...
            b.failureLower(end)-reference.failure(end), ...
            reference.failure(end)-b.failureUpper(end),0]);
        statistics(i,level,:) = [max(b.width(end,:)), ...
            b.failureUpper(end)-b.failureLower(end),b.unresolvedMassUpper(end), ...
            max(abs(b.nominal(end,:)-reference.uniqueCause(end,:))),violation];
    end
end
averages = reshape(mean(statistics,1),nLevel,5);
maxViolation = reshape(max(statistics(:,:,5),[],1),nLevel,1);
output = table(steps',averages(:,1),averages(:,2),averages(:,3),averages(:,4),maxViolation, ...
    'VariableNames',{'dt','meanMaxCauseWidth','meanFailureWidth', ...
    'meanUnresolvedMass','meanFineReferenceCauseError','maxViolation'});
end

function plotResults(probability,resolution,design,folder,name)
fig = figure('Visible','off','Color','w','Position',[100,100,1180,400]);
cleanup = onCleanup(@() close(fig));
layout = tiledlayout(fig,1,3,'Padding','compact');
nexttile;
loglog(resolution.dt,resolution.meanMaxCauseWidth,'o-','LineWidth',1.5); hold on;
loglog(resolution.dt,resolution.meanFineReferenceCauseError,'s-','LineWidth',1.5);
loglog(resolution.dt,resolution.meanFailureWidth,'^-','LineWidth',1.5);
grid on; xlabel('Time step (s)'); ylabel('Absolute probability');
title('Time discretization: fixed inputs');
legend('Cause interval width','Cause error vs fine PWL','System interval width','Location','northwest');
nexttile;
x = (1:height(probability))';
errorbar(x,probability.nominal,probability.nominal-probability.quadratureLower, ...
    probability.quadratureUpper-probability.nominal,'o','LineWidth',1.5,'CapSize',12);
xticks(x); xticklabels(probability.quantity); xtickangle(25); grid on;
ylabel('Probability'); title('Time bounds at the same outer points');
nexttile;
errorbar(x,design.changeNominal,design.changeNominal-design.changeLower, ...
    design.changeUpper-design.changeNominal,'o','LineWidth',1.5,'CapSize',12);
yline(0,'--'); xticks(x); xticklabels(design.quantity); xtickangle(25); grid on;
ylabel('Probability change'); title('First capacity increased by 5%');
title(layout,name+": first-cause bounds and design effects",'Interpreter','none');
exportgraphics(fig,fullfile(folder,'certified_causes.png'),'Resolution',180);
end

function counterexample(folder)
epsilon = [0.1;0.01;0.001;0.0001];
n = numel(epsilon);
data = zeros(n,4);
for i = 1:n
    d = [0,0;1,1];
    radius = [0,0;epsilon(i),epsilon(i)];
    b = mrfp.boundFirstCause([0;1],d,radius,struct('mu',0,'sigma',0.45));
    data(i,:) = [b.failureUpper(end)-b.failureLower(end), ...
        b.unresolvedMassUpper(end),b.upper(end,1)-b.lower(end,1), ...
        0.5*erfc(-log(1+epsilon(i))/(sqrt(2)*0.45))];
end
output = array2table([epsilon,data],'VariableNames', ...
    {'tubeRadius','systemWidth','unresolvedMass','causeWidth','causeSwapBetweenPaths'});
writetable(output,fullfile(folder,'near_tie_counterexample.csv'));
end

function writeJson(fileName,data)
file = fopen(fileName,'w','n','UTF-8');
assert(file>=0,'mrfp:File','Could not open output JSON.');
cleanup = onCleanup(@() fclose(file));
fprintf(file,'%s',jsonencode(data,'PrettyPrint',true));
end
