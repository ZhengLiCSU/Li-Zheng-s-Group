function summary = runBuilding16TimeAudit(resultFolder)
%runBuilding16TimeAudit Refine one fixed path per published building16 batch.
% Audits all 16 preselected inputs before/after the capacity change. This is
% not a continuous-time certificate for all outer quadrature samples.
arguments
    resultFolder (1,1) string = "building16_nf512_study"
end
root = fileparts(mfilename('fullpath'));
oldPath = path; cleanup = onCleanup(@() path(oldPath));
addpath(root);
folder = fullfile(root,'results',resultFolder);
assert(isfile(fullfile(folder,'study.mat')),'mrfp:MissingStudy','Run runBuilding16Study("study") first.');
data = load(fullfile(folder,'study.mat'),'cfg','summary');
cfg = data.cfg;
nReplicate = data.summary.nReplicate;
rows = zeros(2*nReplicate,8);
histories = cell(2*nReplicate,1);
for rep = 1:nReplicate
    inputs = mrfp.sampleInputs(data.summary.nPerReplicate,cfg.nInput,619001+rep);
    base = mrfp.makeResponseSeries(cfg,inputs(1,:),zeros(1,cfg.nPathParameter+2));
    for changed = 0:1
        series = base;
        if changed, series = mrfp.scaleSeriesCapacity(base,1,data.summary.capacityFactor); end
        result = mrfp.refineCauseBounds(series,InitialStep=cfg.dt,Tolerance=1e-3,MaxRefinement=6);
        index = 2*rep-1+changed;
        histories{index} = result.history;
        rows(index,:) = [rep,changed,result.history.unresolvedMass(1), ...
            result.history.unresolvedMass(end),result.history.dt(end), ...
            result.history.nodes(end),result.converged,result.seconds];
    end
    fprintf('16-story time audit: before/after batch %d/%d complete.\n',rep,nReplicate);
end
audit = array2table(rows,'VariableNames',{'replicate','afterChange','initialQ', ...
    'finalQ','finalDt','nodes','converged','seconds'});
writetable(audit,fullfile(folder,'adaptive_time_audit.csv'));
pairedQ = rows(1:2:end,4)+rows(2:2:end,4);
summary = struct('selectedInputs',nReplicate,'auditedPaths',2*nReplicate, ...
    'converged',nnz(rows(:,7)),'tolerance',1e-3,'maxFinalQ',max(rows(:,4)), ...
    'maxPairedQSum',max(pairedQ),'minFinalDt',min(rows(:,5)), ...
    'seconds',sum(rows(:,8)), ...
    'scope',"Selected conditional inputs; paired Q sum bound only, not full-population certification.");
save(fullfile(folder,'adaptive_time_audit.mat'),'audit','histories','pairedQ','summary');
file = fopen(fullfile(folder,'adaptive_time_summary.json'),'w','n','UTF-8');
fileCleanup = onCleanup(@() fclose(file));
fprintf(file,'%s',jsonencode(summary,'PrettyPrint',true));
drawAudit(folder,histories,rows);
disp(summary);
end

function drawAudit(folder,histories,rows)
fig = figure('Visible','off','Color','w','Position',[80,80,1100,450]);
cleanup = onCleanup(@() close(fig));
tiledlayout(1,2,'Padding','compact');
nexttile; hold on;
beforeLine = gobjects(1); afterLine = gobjects(1);
for i = 1:numel(histories)
    h = histories{i};
    if mod(i,2)==1
        beforeLine = plot(h.dt,h.unresolvedMass,'-o','Color',[0.65,0.65,0.65]);
    else
        afterLine = plot(h.dt,h.unresolvedMass,'-s','Color',[0.15,0.4,0.8]);
    end
end
set(gca,'XScale','log','YScale','log','XDir','reverse');
toleranceLine = yline(1e-3,'r--');
xlabel('Time step (s), refined to the right'); ylabel('Conditional uncertified cause mass Q');
legend([beforeLine,afterLine,toleranceLine],{'Before change','After change','Tolerance'},'Location','best');
grid on; title('All 16 selected inputs, two designs');
nexttile;
semilogy(1:size(rows,1),rows(:,3),'o-',1:size(rows,1),rows(:,4),'s-');
hold on; yline(1e-3,'r--');
xlabel('Selected path/design pair'); ylabel('Conditional uncertified cause mass Q');
legend('Initial grid','After refinement','Tolerance','Location','best'); grid on;
title('Selected-path checks, not a population error interval');
exportgraphics(fig,fullfile(folder,'building16_time_refinement.png'),'Resolution',180);
print(fig,fullfile(folder,'building16_time_refinement.svg'),'-dsvg');
end
