function summaries = runStudy(profile)
%runStudy Run forced SDOF and seismic three-story marked-reliability studies.
% Usage: runStudy("quick"); use "paper" only for a larger validation budget.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","quick","study","paper"])} = "quick"
end
root = fileparts(mfilename('fullpath'));
savedPath = path;
cleanup = onCleanup(@() path(savedPath));
addpath(root);
summaries = struct([]);
for name = ["sdof","building"]
    cfg = mrfp.makeConfig(name,profile);
    folder = string(fullfile(root,'results',profile,name));
    if ~isfolder(folder)
        mkdir(folder);
    end
    fprintf('\nRunning %s / %s\n',name,profile);
    result = mrfp.analyzeCase(cfg);
    reference = mrfp.referenceMonteCarlo(cfg);
    sensitivity = mrfp.verifySensitivity(cfg,result.unitInputs);
    resolution = mrfp.verifyResolution(cfg,result.unitInputs);
    views = mrfp.makePdfViews(result.time,result.unitPaths,cfg);
    mrfp.writeFigures(result,reference,sensitivity,views,folder);
    summary = struct('caseName',name,'profile',profile,'failure',result.failure(end), ...
        'rqmcHalfWidth',result.ciHalfWidth(end),'mcFailure',reference.failure(end), ...
        'mcLow',reference.ciLow(end),'mcHigh',reference.ciHigh(end), ...
        'probabilityConservation',max(abs(result.survival+sum(result.cause,2)-1)), ...
        'sensitivityMaxError',sensitivity.maxAbsoluteError, ...
        'frozenSensitivityMaxError',sensitivity.maxFrozenError, ...
        'transferSumError',sensitivity.transferConservation, ...
        'exchangeSumError',max(abs(sum(result.exchangeGradient,1))), ...
        'timeStepDifference',resolution.coarseFineDifference, ...
        'pwlBracketViolation',resolution.maxBracketViolation, ...
        'conditionalVarianceRatio',result.rbVarianceRatio, ...
        'dynamicCalls',result.dynamicCalls,'analysisSeconds',result.analysisSeconds, ...
        'mcDynamicCalls',reference.dynamicCalls,'mcSeconds',reference.seconds, ...
        'pdf1dMinMass',min(views.mass),'pdf1dMaxMass',max(views.mass),'pdf2dMass',views.joint.mass, ...
        'gradientTarget',result.gradientTarget, ...
        'weakGradientTarget','Population log-location derivative for independent Gaussian structural factors');
    summaries = [summaries;summary]; %#ok<AGROW> Two cases only.
    curve = array2table([result.time,result.failure,result.ciHalfWidth,result.cause], ...
        'VariableNames',cellstr(["time","system_probability","rqmc_ci_halfwidth",cfg.modeNames,"joint"]));
    writetable(curve,fullfile(folder,'first_passage.csv'));
    sensitivityTable = array2table(result.gradient, ...
        'VariableNames',cellstr(cfg.parameterNames),'RowNames',cellstr([cfg.modeNames,"joint"]));
    writetable(sensitivityTable,fullfile(folder,'sensitivities.csv'),'WriteRowNames',true);
    [category,parameter] = ndgrid([cfg.modeNames,"joint"],["log_stiffness","log_damping"]);
    weakTable = table(category(:),parameter(:),result.weakStructuralGradient(:), ...
        result.weakStructuralGradientSE(:),'VariableNames', ...
        {'category','parameter','scoreDerivative','standardError'});
    writetable(weakTable,fullfile(folder,'weak_structural_sensitivities.csv'));
    exchangeTable = array2table(result.exchangeGradient, ...
        'VariableNames',cellstr(cfg.parameterNames),'RowNames',cellstr([cfg.modeNames,"joint"]));
    writetable(exchangeTable,fullfile(folder,'mode_exchange_sensitivities.csv'),'WriteRowNames',true);
    baseline = table(result.legacyBandwidthFactors',mean(result.legacyDpimEstimates,1)', ...
        'VariableNames',{'bandwidthMultiplier','smoothedDpimProbability'});
    writetable(baseline,fullfile(folder,'legacy_dpim_bandwidth.csv'));
    individual = table(cfg.modeNames',result.individualModeProbability(end,:)',result.cause(end,1:cfg.nMode)', ...
        'VariableNames',{'mode','everFailedProbability','firstCauseProbability'});
    writetable(individual,fullfile(folder,'mode_competition.csv'));
    multipliers = [0.3;0.5;1;2];
    rare = zeros(numel(multipliers),3);
    for j = 1:numel(multipliers)
        z = (log(result.terminalRecords)+log(multipliers(j)*cfg.amplitudeMedian))/cfg.amplitudeLogSd;
        estimates = mean(0.5*erfc(-z/sqrt(2)),1);
        rare(j,:) = [multipliers(j),mean(estimates),std(estimates)/sqrt(cfg.nReplicate)];
    end
    writetable(array2table(rare,'VariableNames',{'amplitudeMedianMultiplier','probability','rqmcStandardError'}), ...
        fullfile(folder,'amplitude_sweep.csv'));
    save(fullfile(folder,'study.mat'),'result','reference','sensitivity','resolution','views','summary','-v7.3');
    file = fopen(fullfile(folder,'summary.json'),'w','n','UTF-8');
    fileCleanup = onCleanup(@() fclose(file));
    fprintf(file,'%s',jsonencode(summary,'PrettyPrint',true));
    clear fileCleanup
    disp(struct2table(summary));
end
writetable(struct2table(summaries),fullfile(root,'results',profile,'summary.csv'));
end
