function [values,transfer,before,after] = pairedMetrics(time,demand,law,factor,normal,cfg)
%pairedMetrics Integrate the same paired output vector for all new experiments.
m = size(demand,2);
labels = [1:m,1:m];
before = terminalPartition(time,[demand,-demand],labels,law);
changed = demand;
changed(:,1) = changed(:,1)/factor;
after = terminalPartition(time,[changed,-changed],labels,law);
assert(abs(before.probability(m+1))<1e-10 && abs(after.probability(m+1))<1e-10, ...
    'v2:UniqueCause','The simplified rescue/substitution identities require almost-surely unique causes.');
transport = mrfp.transportPartitions(before.partition,after.partition,law,m+2);
transfer = transport.matrix;
assert(max(abs(sum(transfer,2)'-before.probability))<1e-11,'v2:Row','Wrong transfer row marginal.');
assert(max(abs(sum(transfer,1)-after.probability))<1e-11,'v2:Column','Wrong transfer column marginal.');
pf = 1-before.probability(end);
rescue = transfer(1,end);
substitute = sum(transfer(1,2:m+1));
assert(abs(pf-(1-after.probability(end))-rescue)<1e-11,'v2:Rescue','System reduction identity failed.');
assert(abs(before.probability(1)-after.probability(1)-rescue-substitute)<1e-11, ...
    'v2:Substitute','Target reduction identity failed.');
values = [before.probability,after.probability,pf, ...
    pf*normal(1)/cfg.stiffnessLogSd,pf*normal(2)/cfg.dampingLogSd,rescue,substitute];
end
