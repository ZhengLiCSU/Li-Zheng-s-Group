function summary = run_transfer_benchmark(protocol,folder)
%run_transfer_benchmark Identical paired probability, score and transfer targets.
cfg = mrfp.makeConfig("sdof","study");
time = (0:protocol.benchmarkDt:cfg.duration)';
names = metricNames(cfg);
methods = ["conditional","direct_mc","gaussian_union_is"];
count = numel(protocol.benchmarkBudgets)*protocol.nBatch*3;
values = zeros(count,numel(names));
cost = zeros(count,8);
methodColumn = strings(count,1);
row = 0;
for budget = protocol.benchmarkBudgets
    for batch = 1:protocol.nBatch
        for index = circshift(1:3,mod(batch,3))
            row = row+1;
            method = methods(index);
            seed = protocol.seedBenchmark+1000*budget+10*batch+index;
            started = tic;
            [values(row,:),work] = benchmarkBatch(cfg,time,budget,seed,method,protocol);
            seconds = toc(started);
            cost(row,:) = [budget,batch,seconds,work];
            methodColumn(row) = method;
        end
    end
    fprintf('Paired-output benchmark budget %d complete.\n',budget);
end
raw = [table(methodColumn,VariableNames={'method'}), ...
    array2table(cost,VariableNames={'budget','batch','seconds','response_seconds','classification_seconds', ...
    'response_evaluations','event_classifications','amplitude_evaluations'}), ...
    array2table(values,VariableNames=cellstr(names))];
writetable(raw,fullfile(folder,'transfer_benchmark_batches.csv'));
summary = table();
for budget = protocol.benchmarkBudgets
    for method = methods
        selected = raw.budget==budget & raw.method==method;
        v = values(selected,:);
        s = summarizeBatches(v,names);
        s.method = repmat(method,height(s),1);
        s.budget = repmat(budget,height(s),1);
        s.seconds = repmat(mean(raw.seconds(selected)),height(s),1);
        s.response_seconds = repmat(mean(raw.response_seconds(selected)),height(s),1);
        s.classification_seconds = repmat(mean(raw.classification_seconds(selected)),height(s),1);
        s.response_evaluations = repmat(mean(raw.response_evaluations(selected)),height(s),1);
        s.event_classifications = repmat(mean(raw.event_classifications(selected)),height(s),1);
        s.batch_variance = var(v,0,1)';
        s.variance_times_seconds = s.batch_variance.*s.seconds;
        s.variance_times_responses = s.batch_variance.*s.response_evaluations;
        summary = [summary;s]; %#ok<AGROW>
    end
end
writetable(summary,fullfile(folder,'transfer_benchmark_summary.csv'));
save(fullfile(folder,'transfer_benchmark.mat'),'raw','summary','protocol','cfg','names');
end

function [estimate,work] = benchmarkBatch(cfg,time,budget,seed,method,protocol)
responseSeconds = 0;
classificationSeconds = 0;
responses = 0;
classifications = 0;
amplitudes = 0;
if method=="gaussian_union_is"
    n = budget/8;
    inputs = mrfp.sampleInputs(n,3,seed);
    stream = RandStream('mt19937ar','Seed',seed+100003);
else
    n = budget;
    sampling = "rqmc";
    if method=="direct_mc", n = 4*budget; sampling = "mc"; end
    inputs = mrfp.sampleInputs(n,cfg.nInput+double(method=="direct_mc"),seed,sampling);
end
values = zeros(n,numel(metricNames(cfg)));
for k = 1:n
    started = tic;
    if method=="gaussian_union_is"
        operator = mrfp.makeGaussianOperator(cfg,inputs(k,1:2),time);
        amplitude = exp(log(cfg.amplitudeMedian)+cfg.amplitudeLogSd*inputs(k,3));
        sample = mrfp.sampleGaussianUnion(amplitude*operator,protocol.benchmarkInner,seed,Stream=stream);
        responses = responses+2*cfg.nFrequency;
        responseSeconds = responseSeconds+toc(started);
        started = tic;
        inner = zeros(protocol.benchmarkInner,size(values,2));
        for j = 1:protocol.benchmarkInner
            demand = reshape(sample.response(:,j),numel(time),cfg.nMode);
            inner(j,:) = sample.weight(j)*directPairedMetrics(time,demand,1,1.2,inputs(k,1:2),cfg);
        end
        values(k,:) = mean(inner,1);
        % The proposal is supported on baseline failure. Its weighted safe
        % indicator is zero; use the unbiased complement for both safe margins.
        values(k,cfg.nMode+2) = 1-sum(values(k,1:cfg.nMode+1));
        values(k,2*(cfg.nMode+2)) = 1-sum(values(k,cfg.nMode+3:2*cfg.nMode+2+1));
        classifications = classifications+2*protocol.benchmarkInner;
        amplitudes = amplitudes+protocol.benchmarkInner;
    else
        series = mrfp.makeResponseSeries(cfg,inputs(k,1:cfg.nInput),zeros(1,cfg.nPathParameter+2));
        demand = mrfp.evaluateSeriesField(series,time);
        responses = responses+1;
        responseSeconds = responseSeconds+toc(started);
        started = tic;
        if method=="conditional"
            values(k,:) = pairedMetrics(time,demand,series.law,1.2,inputs(k,1:2),cfg);
            amplitudes = amplitudes+1;
        else
            amplitude = exp(series.law.mu+series.law.sigma*inputs(k,end));
            values(k,:) = directPairedMetrics(time,demand,amplitude,1.2,inputs(k,1:2),cfg);
            amplitudes = amplitudes+1;
        end
        classifications = classifications+2;
    end
    classificationSeconds = classificationSeconds+toc(started);
end
estimate = mean(values,1);
work = [responseSeconds,classificationSeconds,responses,classifications,amplitudes];
end
