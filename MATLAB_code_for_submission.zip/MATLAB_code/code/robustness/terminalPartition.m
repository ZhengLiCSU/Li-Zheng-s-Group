function result = terminalPartition(time, values, labels, law)
%terminalPartition Exact terminal PWL result after removing inactive cells.
% An omitted cell has both endpoints below the previous running record.
% Linear interpolation cannot create a new record inside such a cell.
nodeMax = max(values,[],2);
prior = cummax([0;nodeMax(1:end-1)]);
active = find(nodeMax>prior);
keep = unique([1;max(1,active-1);active;numel(time)]);
raw = mrfp.integrateBranches(time(keep),values(keep,:),labels,law,StorePartition=true);
result = struct('probability',[raw.uniqueCause(end,:),raw.joint(end),1-raw.failure(end)], ...
    'partition',raw.partition,'activeNodes',numel(keep));
end
