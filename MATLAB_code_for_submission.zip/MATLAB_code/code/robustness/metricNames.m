function names = metricNames(cfg)
%metricNames Common estimands; suffixes identify the unchanged/raised capacity.
base = [cfg.modeNames,"joint","safe"];
names = [base+"_before",base+"_after","system","system_K","system_C","rescued","substituted"];
end
