function [values,transfer] = directPairedMetrics(time,demand,amplitude,factor,normal,cfg)
%directPairedMetrics Chronological crossing classifier, independent of partitions.
m = size(demand,2);
a = mrfp.firstEvent(time,demand,amplitude);
changed = demand;
changed(:,1) = changed(:,1)/factor;
b = mrfp.firstEvent(time,changed,amplitude);
ia = a.cause;
ib = b.cause;
if ia==0, ia = m+2; end
if ib==0, ib = m+2; end
before = double((1:m+2)==ia);
after = double((1:m+2)==ib);
transfer = zeros(m+2);
transfer(ia,ib) = 1;
pf = double(ia~=m+2);
values = [before,after,pf,pf*normal(1)/cfg.stiffnessLogSd, ...
    pf*normal(2)/cfg.dampingLogSd,double(ia==1 && ib==m+2),double(ia==1 && ib>1 && ib<m+2)];
end
