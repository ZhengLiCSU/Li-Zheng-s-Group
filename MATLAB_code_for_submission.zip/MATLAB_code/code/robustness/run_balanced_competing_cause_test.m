function result = run_balanced_competing_cause_test(protocol,folder)
%run_balanced_competing_cause_test Independent-pilot four-criterion validation.
pilotFile = fullfile(folder,'balanced_pilot.mat');
if isfile(pilotFile)
    loaded = load(pilotFile,'cfg');
    cfg = loaded.cfg;
else
    cfg = calibrateBalancedPilot(protocol,folder);
end
time = (0:protocol.dt:cfg.duration)';
names = metricNames(cfg);
batches = zeros(protocol.nBatch,numel(names));
transfers = zeros(6,6,protocol.nBatch);
runtime = zeros(protocol.nBatch,1);
for batch = 1:protocol.nBatch
    started = tic;
    inputs = mrfp.sampleInputs(protocol.nOuter,cfg.nInput,protocol.seedFinal+batch);
    values = zeros(protocol.nOuter,numel(names));
    for k = 1:protocol.nOuter
        series = mrfp.makeResponseSeries(cfg,inputs(k,:),zeros(1,cfg.nPathParameter+2));
        demand = mrfp.evaluateSeriesField(series,time);
        [values(k,:),transfer] = pairedMetrics(time,demand,series.law,1.2,inputs(k,1:2),cfg);
        transfers(:,:,batch) = transfers(:,:,batch)+transfer/protocol.nOuter;
        if batch==1 && k==1
            illustration = struct('time',time,'demand',demand,'law',series.law,'input',inputs(k,:));
        end
    end
    batches(batch,:) = mean(values,1);
    runtime(batch) = toc(started);
    save(fullfile(folder,sprintf('balanced_batch_%02d.mat',batch)),'inputs','values','cfg');
    fprintf('Balanced conditional batch %d/%d: %.2f s\n',batch,protocol.nBatch,runtime(batch));
end
directValues = zeros(protocol.nMC,numel(names));
directTransfer = zeros(6);
inputsMC = mrfp.sampleInputs(protocol.nMC,cfg.nInput+1,protocol.seedMC,"mc");
started = tic;
for k = 1:protocol.nMC
    series = mrfp.makeResponseSeries(cfg,inputsMC(k,1:cfg.nInput),zeros(1,cfg.nPathParameter+2));
    demand = mrfp.evaluateSeriesField(series,time);
    amplitude = exp(series.law.mu+series.law.sigma*inputsMC(k,end));
    [directValues(k,:),transfer] = directPairedMetrics(time,demand,amplitude,1.2,inputsMC(k,1:2),cfg);
    directTransfer = directTransfer+transfer;
end
directRuntime = toc(started);
summary = summarizeBatches(batches,names);
summary.direct = mean(directValues,1)';
summary.direct_lower = nan(height(summary),1);
summary.direct_upper = nan(height(summary),1);
isProbability = ~ismember(names,["system_K","system_C"]);
p = summary.direct(isProbability);
z = 1.95996398454;
center = (p+z^2/(2*protocol.nMC))/(1+z^2/protocol.nMC);
half = z*sqrt(p.*(1-p)/protocol.nMC+z^2/(4*protocol.nMC^2))/(1+z^2/protocol.nMC);
summary.direct_lower(isProbability) = center-half;
summary.direct_upper(isProbability) = center+half;
averageTransfer = mean(transfers,3);
shares = mean(batches(:,1:4),1)/mean(batches(:,13));
result = struct('cfg',cfg,'shares',shares,'atLeastThreeAboveFivePercent',nnz(shares>0.05)>=3, ...
    'noCauseAboveEightyPercent',max(shares)<0.8,'multipleSubstitutions',nnz(averageTransfer(1,2:4)>0.001)>=2, ...
    'runtimeConditional',sum(runtime),'runtimeDirect',directRuntime);
writetable(summary,fullfile(folder,'balanced_summary.csv'));
writetable(array2table(batches,VariableNames=cellstr(names)),fullfile(folder,'balanced_batch_statistics.csv'));
writematrix(averageTransfer,fullfile(folder,'balanced_transfer_matrix.csv'));
writematrix(directTransfer,fullfile(folder,'balanced_direct_transfer_counts.csv'));
save(fullfile(folder,'balanced_results.mat'),'cfg','protocol','batches','transfers','runtime', ...
    'directValues','directTransfer','directRuntime','illustration','names');
writeJson(fullfile(folder,'balanced_diagnostics.json'),result);
disp(summary);
end
