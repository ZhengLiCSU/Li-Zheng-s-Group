function run_balanced_confirmation(protocol,folder)
%run_balanced_confirmation Fresh fixed-budget check after a marginal MC discrepancy.
% The first 16384-point MC cohort is retained. This separate 65536-point
% cohort uses unchanged model/capacities and is never pooled adaptively.
seed = 20270921;
n = 65536;
amendment = struct('dateUTC',string(datetime('now',TimeZone='UTC')),'seed',seed,'n',n, ...
    'reason',"Initial 16384-point roof-velocity first-cause Wilson interval does not overlap the conditional pointwise t interval. Run one independent fixed 65536-point confirmation; retain and report both cohorts, no tuning or pooling.");
writeJson(fullfile(folder,'confirmation_protocol_amendment.json'),amendment);
loaded = load(fullfile(folder,'balanced_pilot.mat'),'cfg');
cfg = loaded.cfg;
time = (0:protocol.dt:cfg.duration)';
inputs = mrfp.sampleInputs(n,cfg.nInput+1,seed,"mc");
values = zeros(n,numel(metricNames(cfg)));
transferCounts = zeros(6);
started = tic;
for k = 1:n
    series = mrfp.makeResponseSeries(cfg,inputs(k,1:cfg.nInput),zeros(1,cfg.nPathParameter+2));
    demand = mrfp.evaluateSeriesField(series,time);
    amplitude = exp(series.law.mu+series.law.sigma*inputs(k,end));
    [values(k,:),transfer] = directPairedMetrics(time,demand,amplitude,1.2,inputs(k,1:2),cfg);
    transferCounts = transferCounts+transfer;
end
seconds = toc(started);
names = metricNames(cfg);
estimate = mean(values,1)';
standardError = std(values,0,1)'/sqrt(n);
lower = nan(size(estimate));
upper = lower;
mask = ~ismember(names,["system_K","system_C"]);
p = estimate(mask);
z = 1.95996398454;
center = (p+z^2/(2*n))/(1+z^2/n);
half = z*sqrt(p.*(1-p)/n+z^2/(4*n^2))/(1+z^2/n);
lower(mask) = center-half;
upper(mask) = center+half;
summary = table(names',estimate,standardError,lower,upper,VariableNames={'output','estimate','standard_error','lower','upper'});
writetable(summary,fullfile(folder,'balanced_confirmation_summary.csv'));
writematrix(transferCounts,fullfile(folder,'balanced_confirmation_transfer_counts.csv'));
save(fullfile(folder,'balanced_confirmation.mat'),'cfg','protocol','values','transferCounts','seed','n','seconds');
writeJson(fullfile(folder,'balanced_confirmation_runtime.json'),struct('n',n,'seed',seed,'seconds',seconds));
disp(summary);
end
