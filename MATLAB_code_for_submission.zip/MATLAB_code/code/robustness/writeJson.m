function writeJson(file,value)
%writeJson Save readable UTF-8 experimental metadata.
fid = fopen(file,'w','n','UTF-8');
assert(fid>0,'v2:File','Could not open output file.');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid,'%s\n',jsonencode(value,PrettyPrint=true));
end
