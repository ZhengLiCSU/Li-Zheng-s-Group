function bound = resolutionBounds(time,demand,radius,law)
%resolutionBounds Lower certified category masses and their unresolved complement.
% Same pessimistic branch construction as mrfp.boundFirstCause; no upper
% per-cause or intermediate-time outputs are evaluated in a population audit.
m = size(demand,2);
labels = [1:m,1:m];
fast = [demand+radius,-demand+radius];
slow = [demand-radius,-demand-radius];
fastPart = terminalPartition(time,fast,labels,law);
certified = zeros(0,3);
lower = zeros(1,m+2);
for j = 1:m
    % Delaying only criterion j cannot introduce a unique first cause j.
    % If no positive-mass interval belongs uniquely to j in the all-fast
    % envelope, its pessimistic certified mass is already zero.
    if fastPart.probability(j)==0
        continue
    end
    mixed = fast;
    mixed(:,[j,j+m]) = slow(:,[j,j+m]);
    part = terminalPartition(time,mixed,labels,law);
    lower(j) = part.probability(j);
    certified = [certified;part.partition(part.partition(:,3)==j,:)]; %#ok<AGROW>
end
safe = fastPart.partition(end,:);
lower(end) = fastPart.probability(end);
certified = sortrows([certified;safe],1);
partition = zeros(2*size(certified,1)+1,3);
count = 0;
cursor = 0;
for j = 1:size(certified,1)
    left = certified(j,1);
    assert(left>=cursor-64*eps(max(1,cursor)),'v2:Overlap','Certified intervals overlap.');
    left = max(left,cursor);
    if left>cursor
        count = count+1;
        partition(count,:) = [cursor,left,0];
    end
    if certified(j,2)>left
        count = count+1;
        partition(count,:) = [left,certified(j,2:3)];
    end
    cursor = certified(j,2);
end
bound = struct('lower',lower,'unresolved',max(0,1-sum(lower)), ...
    'partition',partition(1:count,:));
end
