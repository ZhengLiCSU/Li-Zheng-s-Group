function hashes = hashRobustnessFiles(root)
%hashRobustnessFiles Record SHA-256 for code, configurations and numeric outputs.
files = [dir(fullfile(root,'code','robustness','*.m')); ...
    dir(fullfile(root,'results','robustness_v2','*.csv')); ...
    dir(fullfile(root,'results','robustness_v2','*config.json')); ...
    dir(fullfile(root,'run_all_robustness_tests.m'))];
hashes = struct('path',{},'sha256',{});
for k = 1:numel(files)
    file = fullfile(files(k).folder,files(k).name);
    fid = fopen(file,'r');
    bytes = fread(fid,Inf,'*uint8');
    fclose(fid);
    digest = java.security.MessageDigest.getInstance('SHA-256');
    digest.update(bytes);
    encoded = lower(reshape(dec2hex(typecast(digest.digest(),'uint8'),2)',1,[]));
    hashes(k) = struct('path',string(erase(file,root+filesep)),'sha256',string(encoded));
end
end
