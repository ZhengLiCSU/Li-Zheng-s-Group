function summary = run_global_resolution_audit(protocol,folder,caseName)
%run_global_resolution_audit Audit every original production input, paired designs.
if caseName=="sdof"
    cfg = mrfp.makeConfig("sdof","study");
    n = protocol.auditSdofN;
    baseSeed = 92056000;
else
    cfg = mrfp.makeBuilding16Config("study");
    n = protocol.auditBuildingN;
    baseSeed = 92046000;
end
allFinal = table();
allHistory = table();
for batch = 1:protocol.auditBatches
    file = fullfile(folder,caseName+"_audit_batch_"+compose('%02d',batch)+".mat");
    if isfile(file)
        loaded = load(file,'final','history','protocol');
        assert(isequaln(loaded.protocol,protocol),'v2:Checkpoint', ...
            'Checkpoint configuration differs. Use a new results directory for a changed protocol.');
        final = loaded.final;
        history = loaded.history;
    else
        inputs = mrfp.sampleInputs(n,cfg.nInput,baseSeed+batch);
        models = cell(n,1);
        rows = zeros(n,11);
        records = zeros(n*(protocol.maxLevel+1),8);
        recordCount = 0;
        active = (1:n)';
        elapsed = zeros(n,1);
        initial = zeros(n,2);
        for level = 0:protocol.maxLevel
            time = (0:protocol.dt/2^level:cfg.duration)';
            remaining = false(n,1);
            for k = active'
                started = tic;
                if level==0
                    models{k} = mrfp.makeResponseSeries(cfg,inputs(k,:),zeros(1,cfg.nPathParameter+2));
                end
                path = evaluateTube(models{k},time);
                before = resolutionBounds(time,path.demand,path.radius,path.law);
                path.demand(:,1) = path.demand(:,1)/protocol.capacityFactor;
                path.radius(:,1) = path.radius(:,1)/protocol.capacityFactor;
                after = resolutionBounds(time,path.demand,path.radius,path.law);
                paired = mrfp.transportPartitions(before.partition,after.partition,path.law,cfg.nMode+2);
                elapsed(k) = elapsed(k)+toc(started);
                q = [before.unresolved,after.unresolved];
                if level==0, initial(k,:) = q; end
                recordCount = recordCount+1;
                records(recordCount,:) = [batch,k,level,protocol.dt/2^level,q,paired.unresolvedMass,elapsed(k)];
                rows(k,:) = [batch,k,level,protocol.dt/2^level,q,paired.unresolvedMass, ...
                    elapsed(k),initial(k,:),double(max(q)<=protocol.qTolerance)];
                remaining(k) = max(q)>protocol.qTolerance;
            end
            fprintf('%s audit batch %d level %d: %d evaluated, %d unresolved\n',caseName,batch,level,numel(active),nnz(remaining));
            active = find(remaining);
            if isempty(active), break; end
        end
        names = {'batch','input_index','level','dt','Q_before','Q_after','Q_pair','seconds', ...
            'Q_before_initial','Q_after_initial','converged'};
        final = array2table(rows,VariableNames=names);
        history = array2table(records(1:recordCount,:),VariableNames=names(1:8));
        save(file,'final','history','inputs','protocol','cfg','baseSeed');
    end
    allFinal = [allFinal;final]; %#ok<AGROW>
    allHistory = [allHistory;history]; %#ok<AGROW>
end
writetable(allFinal,fullfile(folder,caseName+"_resolution_paths.csv"));
writetable(allHistory,fullfile(folder,caseName+"_resolution_history.csv"));
summary = aggregateResolution(allFinal,protocol,caseName);
writeJson(fullfile(folder,caseName+"_resolution_summary.json"),summary);
end

function summary = aggregateResolution(paths,protocol,caseName)
summary = struct('case',caseName,'scope',"all original production outer inputs", ...
    'nInputs',height(paths),'nDesignCases',2*height(paths),'tolerance',protocol.qTolerance, ...
    'fractionPairedConverged',mean(paths.converged),'maxLevel',max(paths.level), ...
    'fractionRefined',mean(paths.level>0),'seconds',sum(paths.seconds));
variables = ["Q_before","Q_after","Q_pair"];
for variable = variables
    q = paths.(variable);
    batchMeans = splitapply(@mean,q,paths.batch);
    half = tinv(0.975,numel(batchMeans)-1)*std(batchMeans)/sqrt(numel(batchMeans));
    summary.(variable) = struct('mean',mean(q),'median',median(q),'p90',prctile(q,90), ...
        'p95',prctile(q,95),'max',max(q),'fractionWithinTolerance',mean(q<=protocol.qTolerance), ...
        'approximatePopulationMeanHalfWidth',half, ...
        'approximatePopulationMeanUpper',mean(q)+half, ...
        'interpretation',"Mean Q bounds finite-input average unresolved probability; batch t interval only approximates expectation over outer inputs.");
end
end
