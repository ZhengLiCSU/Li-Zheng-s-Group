function cfg = buildBalancedModel()
%buildBalancedModel Author-defined four-story diagnostic, not a calibrated asset.
cfg = mrfp.makeConfig("building","study");
cfg.caseName = "balanced4";
cfg.mass = 2e4*eye(4);
incidence = eye(4)-diag(ones(3,1),-1);
cfg.stiffness = incidence'*diag(2e6*[1.2,1.1,0.95,0.8])*incidence;
cfg.dampingRatio = 0.04;
cfg.rayleighModes = [1,4];
cfg.nFrequency = 12;
cfg.frequency = linspace(0.5,6,12);
cfg.excitationScale = 0.35;
cfg.nMode = 4;
cfg.nInput = 26;
cfg.nPathParameter = 6;
cfg.dt = 0.0025;
cfg.thresholds = ones(1,4);
cfg.modeNames = ["first_drift","fourth_drift","roof_velocity","roof_acceleration"];
cfg.parameterNames = ["log_stiffness","log_damping","log_capacity_"+cfg.modeNames, ...
    "log_amplitude_median","log_amplitude_logsd"];
cfg.outputDisplacement = [incidence(1,:)/3;incidence(4,:)/3;zeros(2,4)];
cfg.outputVelocity = [zeros(2,4);0,0,0,1;zeros(1,4)];
cfg.outputAcceleration = [zeros(3,4);0,0,0,1];
end
