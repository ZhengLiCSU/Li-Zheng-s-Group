function path = evaluateTubeChunked(series,time,chunkSize)
%evaluateTubeChunked Bound the same analytic path with limited temporary memory.
arguments
    series (1,1) struct
    time (:,1) double
    chunkSize (1,1) double {mustBeInteger,mustBePositive} = 8192
end
assert(chunkSize>=2,'v2:Chunk','Each chunk must include at least one time cell.');
n = numel(time);
m = size(series.coefficients,2);
demand = zeros(n,m);
radius = zeros(n,m);
for first = 1:chunkSize-1:n-1
    last = min(n,first+chunkSize-1);
    indices = first:last;
    local = evaluateTube(series,time(indices));
    demand(indices,:) = local.demand;
    % Shared boundary nodes must cover the curvature bounds of both cells.
    radius(indices,:) = max(radius(indices,:),local.radius);
end
path = struct('demand',demand,'radius',radius,'law',series.law);
end
