function exportRobustnessFigures(root,folder)
%exportRobustnessFigures Export numeric illustration and invoke scientific plotting.
loaded = load(fullfile(folder,'balanced_results.mat'),'illustration');
illustration = loaded.illustration;
time = illustration.time;
demand = illustration.demand;
a = terminalPartition(time,[demand,-demand],[1:4,1:4],illustration.law);
changed = demand;
changed(:,1) = changed(:,1)/1.2;
b = terminalPartition(time,[changed,-changed],[1:4,1:4],illustration.law);
before = a.partition;
after = b.partition;
save(fullfile(folder,'balanced_illustration.mat'),'time','demand','before','after');
python = string(getenv('MRFP_PYTHON'));
if strlength(python)==0, python = "python"; end
script = fullfile(root,'manuscript','final','build_robustness_figures.py');
[status,message] = system(sprintf('"%s" "%s"',python,script));
fprintf('%s\n',message);
assert(status==0,'v2:Figures','Figure export failed. Install numpy, scipy, matplotlib and set MRFP_PYTHON.');
end
