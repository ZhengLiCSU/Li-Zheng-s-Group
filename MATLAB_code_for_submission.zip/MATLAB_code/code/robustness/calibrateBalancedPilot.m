function cfg = calibrateBalancedPilot(protocol,folder)
%calibrateBalancedPilot Freeze capacities using independent pilot inputs only.
cfg = buildBalancedModel();
time = (0:protocol.dt:cfg.duration)';
inputs = mrfp.sampleInputs(protocol.nPilot,cfg.nInput,protocol.seedPilot);
paths = zeros(numel(time),cfg.nMode,protocol.nPilot);
peaks = zeros(protocol.nPilot,cfg.nMode);
for k = 1:protocol.nPilot
    series = mrfp.makeResponseSeries(cfg,inputs(k,:),zeros(1,cfg.nPathParameter+2));
    paths(:,:,k) = mrfp.evaluateSeriesField(series,time);
    peaks(k,:) = max(abs(paths(:,:,k)),[],1);
end
cfg.thresholds = 1.6*median(peaks,1);
law = struct('mu',log(cfg.amplitudeMedian),'sigma',cfg.amplitudeLogSd);
history = zeros(protocol.pilotIterations,9);
for iteration = 1:protocol.pilotIterations
    probability = zeros(protocol.nPilot,cfg.nMode+2);
    for k = 1:protocol.nPilot
        demand = paths(:,:,k)./cfg.thresholds;
        p = terminalPartition(time,[demand,-demand],[1:4,1:4],law);
        probability(k,:) = p.probability;
    end
    average = mean(probability,1);
    shares = average(1:4)/sum(average(1:4));
    history(iteration,:) = [cfg.thresholds,shares,1-average(end)];
    cfg.thresholds = cfg.thresholds.*exp(protocol.pilotGain*(shares-protocol.pilotTargetShares));
end
save(fullfile(folder,'balanced_pilot.mat'),'cfg','protocol','history','inputs','peaks');
writematrix(history,fullfile(folder,'balanced_pilot_history.csv'));
writeJson(fullfile(folder,'balanced_config.json'),cfg);
fprintf('Pilot frozen capacities: %.10g %.10g %.10g %.10g\n',cfg.thresholds);
fprintf('Last pilot shares: %.4f %.4f %.4f %.4f\n',history(end,5:8));
end
