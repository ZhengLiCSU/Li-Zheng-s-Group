function run_capped_path_followup(protocol,folder)
%run_capped_path_followup Separately reported extension of capped audit paths.
% Original five-halving results are preserved. No primary summary is replaced.
paths = readtable(fullfile(folder,'building16_resolution_paths.csv'));
selected = find(~paths.converged);
cfg = mrfp.makeBuilding16Config("study");
records = zeros(numel(selected)*2,7);
count = 0;
for row = selected'
    batch = paths.batch(row);
    k = paths.input_index(row);
    inputs = mrfp.sampleInputs(protocol.auditBuildingN,cfg.nInput,92046000+batch);
    series = mrfp.makeResponseSeries(cfg,inputs(k,:),zeros(1,cfg.nPathParameter+2));
    for level = protocol.maxLevel+1:protocol.maxLevel+2
        started = tic;
        time = (0:protocol.dt/2^level:cfg.duration)';
        path = evaluateTubeChunked(series,time);
        before = resolutionBounds(time,path.demand,path.radius,path.law);
        path.demand(:,1) = path.demand(:,1)/1.2;
        path.radius(:,1) = path.radius(:,1)/1.2;
        after = resolutionBounds(time,path.demand,path.radius,path.law);
        count = count+1;
        records(count,:) = [batch,k,level,protocol.dt/2^level,before.unresolved,after.unresolved,toc(started)];
        fprintf('Capped-path follow-up batch %d input %d level %d: Q %.6g / %.6g\n',batch,k,level,before.unresolved,after.unresolved);
        if max(before.unresolved,after.unresolved)<=protocol.qTolerance, break; end
    end
end
tableOut = array2table(records(1:count,:),VariableNames={'batch','input_index','level','dt','Q_before','Q_after','seconds'});
writetable(tableOut,fullfile(folder,'building16_capped_followup.csv'));
end
