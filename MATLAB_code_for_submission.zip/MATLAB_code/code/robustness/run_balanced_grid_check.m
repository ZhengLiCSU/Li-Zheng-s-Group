function run_balanced_grid_check(protocol,folder)
%run_balanced_grid_check Prespecified first 32 inputs of each independent batch.
pilot = load(fullfile(folder,'balanced_pilot.mat'),'cfg');
cfg = pilot.cfg;
fineTime = (0:protocol.dt/2:cfg.duration)';
coarseTime = fineTime(1:2:end);
names = metricNames(cfg);
differences = zeros(protocol.nBatch,numel(names));
q = zeros(protocol.nBatch,3);
for batch = 1:protocol.nBatch
    input = mrfp.sampleInputs(protocol.nOuter,cfg.nInput,protocol.seedFinal+batch);
    delta = zeros(32,numel(names));
    unresolved = zeros(32,2);
    for k = 1:32
        series = mrfp.makeResponseSeries(cfg,input(k,:),zeros(1,cfg.nPathParameter+2));
        path = evaluateTube(series,fineTime);
        coarse = pairedMetrics(coarseTime,path.demand(1:2:end,:),series.law,1.2,input(k,1:2),cfg);
        fine = pairedMetrics(fineTime,path.demand,series.law,1.2,input(k,1:2),cfg);
        delta(k,:) = coarse-fine;
        a = resolutionBounds(fineTime,path.demand,path.radius,series.law);
        path.demand(:,1) = path.demand(:,1)/1.2;
        path.radius(:,1) = path.radius(:,1)/1.2;
        b = resolutionBounds(fineTime,path.demand,path.radius,series.law);
        unresolved(k,:) = [a.unresolved,b.unresolved];
    end
    differences(batch,:) = mean(delta,1);
    q(batch,:) = [mean(unresolved,1),max(unresolved,[],'all')];
end
writetable(summarizeBatches(differences,names),fullfile(folder,'balanced_grid_check.csv'));
save(fullfile(folder,'balanced_grid_check.mat'),'differences','q','protocol');
writeJson(fullfile(folder,'balanced_grid_diagnostics.json'), ...
    struct('scope',"first 32 inputs of each of 16 final batches; 512 selected paths", ...
    'fineDt',protocol.dt/2,'meanQBefore',mean(q(:,1)),'meanQAfter',mean(q(:,2)), ...
    'maxQ',max(q(:,3)),'maxAbsoluteMeanMetricChange',max(abs(mean(differences,1)))));
end
