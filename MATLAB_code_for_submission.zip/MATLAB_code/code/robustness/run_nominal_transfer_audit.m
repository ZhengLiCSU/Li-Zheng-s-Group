function run_nominal_transfer_audit(protocol,folder,caseName)
%run_nominal_transfer_audit Carry refined certificates back to production labels.
% A fine-grid tube certifies fine labels, not the earlier coarse classifier.
% Same-threshold nominal disagreement D plus Q bounds the coarse-label error.
paths = readtable(fullfile(folder,caseName+"_resolution_paths.csv"));
if caseName=="sdof"
    cfg = mrfp.makeConfig("sdof","study");
    n = protocol.auditSdofN;
    baseSeed = 92056000;
else
    cfg = mrfp.makeBuilding16Config("study");
    n = protocol.auditBuildingN;
    baseSeed = 92046000;
end
disagreement = zeros(height(paths),2);
coarseTime = (0:protocol.dt:cfg.duration)';
started = tic;
for batch = 1:protocol.auditBatches
    rows = find(paths.batch==batch & paths.level>0);
    inputs = mrfp.sampleInputs(n,cfg.nInput,baseSeed+batch);
    for level = 1:protocol.maxLevel
        selected = rows(paths.level(rows)==level);
        fineTime = (0:protocol.dt/2^level:cfg.duration)';
        for row = selected'
            k = paths.input_index(row);
            series = mrfp.makeResponseSeries(cfg,inputs(k,:),zeros(1,cfg.nPathParameter+2));
            fine = mrfp.evaluateSeriesField(series,fineTime);
            coarse = fine(1:2^level:end,:);
            for design = 1:2
                p = terminalPartition(coarseTime,[coarse,-coarse],[1:cfg.nMode,1:cfg.nMode],series.law);
                q = terminalPartition(fineTime,[fine,-fine],[1:cfg.nMode,1:cfg.nMode],series.law);
                joined = mrfp.transportPartitions(p.partition,q.partition,series.law,cfg.nMode+2);
                disagreement(row,design) = max(0,1-trace(joined.matrix));
                coarse(:,1) = coarse(:,1)/1.2;
                fine(:,1) = fine(:,1)/1.2;
            end
        end
    end
    fprintf('%s production-label audit batch %d: %d refined paths compared\n',caseName,batch,numel(rows));
end
paths.disagreement_before = disagreement(:,1);
paths.disagreement_after = disagreement(:,2);
paths.production_error_before = min(1,paths.Q_before+disagreement(:,1));
paths.production_error_after = min(1,paths.Q_after+disagreement(:,2));
paths.production_error_pair = min(1,paths.Q_pair+sum(disagreement,2));
writetable(paths,fullfile(folder,caseName+"_production_label_bounds.csv"));
summary = struct('case',caseName,'n',height(paths),'seconds',toc(started), ...
    'meanDisagreement',mean(disagreement,1),'maxDisagreement',max(disagreement,[],1), ...
    'meanProductionError',[mean(paths.production_error_before),mean(paths.production_error_after),mean(paths.production_error_pair)], ...
    'maxProductionError',[max(paths.production_error_before),max(paths.production_error_after),max(paths.production_error_pair)]);
writeJson(fullfile(folder,caseName+"_production_label_summary.json"),summary);
end
