function summary = summarizeBatches(values,names)
%summarizeBatches Approximate t intervals from independent randomized batches.
n = size(values,1);
estimate = mean(values,1)';
standardError = std(values,0,1)'/sqrt(n);
halfWidth = tinv(0.975,n-1)*standardError;
summary = table(names(:),estimate,standardError,halfWidth,estimate-halfWidth,estimate+halfWidth, ...
    VariableNames={'output','estimate','standard_error','half_width','lower','upper'});
end
