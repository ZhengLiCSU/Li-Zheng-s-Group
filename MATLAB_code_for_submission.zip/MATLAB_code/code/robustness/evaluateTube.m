function path = evaluateTube(series,time)
%evaluateTube Evaluate the existing analytic curvature tube without derivatives.
demand = mrfp.evaluateSeriesField(series,time);
growth = real(series.poles).';
constant = growth==0;
curvature = repmat(sum(abs(series.poles(constant).^2.*series.coefficients(constant,:)),1), ...
    numel(time)-1,1);
changing = ~constant;
endpoint = max(time(1:end-1)*growth(changing),time(2:end)*growth(changing));
curvature = curvature+exp(endpoint)*abs(series.poles(changing).^2.*series.coefficients(changing,:));
if isfield(series,'transientGenerators')
    for j = 1:size(series.transientGenerators,3)
        generator = series.transientGenerators(:,:,j);
        states = mrfp.evaluateModalState(generator,series.transientInitial(:,j),time(1:end-1));
        output = (generator'^2)*series.transientDemand(:,:,j);
        curvature = curvature+vecnorm(states,2,2)*vecnorm(output,2,1);
    end
end
cellRadius = diff(time).^2.*curvature/8;
radius = max([cellRadius;zeros(1,size(demand,2))],[zeros(1,size(demand,2));cellRadius]);
path = struct('demand',demand,'radius',radius,'law',series.law);
end
