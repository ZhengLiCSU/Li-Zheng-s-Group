function result = run_exact_partition_test(protocol,folder)
%run_exact_partition_test Four prescribed PWL paths with a rational intersection.
time = (0:5)';
demand = [0,0,0,0;0.74,0.68,0.70,0.62;0.3,0.95,0.8,0.4; ...
    0.3,0.3,1.2,0.4;0.3,0.3,0.3,1.6;1.9,0.4,0.4,0.4];
law = struct('mu',0,'sigma',0.45);
beforeOracle = [0,0.74,1;0.74,0.95,2;0.95,1.2,3;1.2,1.6,4;1.6,1.9,1;1.9,Inf,6];
crossing = 0.7+0.1*(0.7-0.68)/((0.95-0.68)-(0.8-0.7));
afterOracle = [0,crossing,3;crossing,0.95,2;0.95,1.2,3;1.2,1.6,4;1.6,Inf,6];
cfg = buildBalancedModel();
[values,transfer,before,after] = pairedMetrics(time,demand,law,protocol.capacityFactor,[0,0],cfg);
% Independent closed-form transfer reference; no interval-intersection code.
H = @(b) 0.5*erfc(-log(b)/(sqrt(2)*0.45));
oracleTransfer = zeros(6);
oracleTransfer(1,3) = H(crossing);
oracleTransfer(1,2) = H(0.74)-H(crossing);
oracleTransfer(1,6) = H(1.9)-H(1.6);
oracleTransfer(2,2) = H(0.95)-H(0.74);
oracleTransfer(3,3) = H(1.2)-H(0.95);
oracleTransfer(4,4) = H(1.6)-H(1.2);
oracleTransfer(6,6) = 1-H(1.9);
error = max(abs(transfer-oracleTransfer),[],'all');
assert(error<1e-12,'v2:Oracle','Analytic four-cause partition disagrees.');
assert(max(abs(before.partition-beforeOracle),[],'all','omitnan')<1e-12,'v2:Before','Baseline cuts disagree.');
assert(max(abs(after.partition-afterOracle),[],'all','omitnan')<1e-12,'v2:After','Modified cuts disagree.');
normals = mrfp.sampleInputs(65536,1,20260922,"mc");
direct = zeros(65536,numel(values));
for k = 1:65536
    direct(k,:) = directPairedMetrics(time,demand,exp(0.45*normals(k)),1.2,[0,0],cfg);
end
counts = sum(direct,1);
center = (counts/65536+1.95996398454^2/(2*65536))/(1+1.95996398454^2/65536);
half = 1.95996398454*sqrt(counts/65536.*(1-counts/65536)/65536+1.95996398454^2/(4*65536^2))/(1+1.95996398454^2/65536);
result = struct('maxPartitionError',error,'intersection',crossing,'values',values, ...
    'directEstimate',mean(direct,1),'wilsonLower',center-half,'wilsonUpper',center+half, ...
    'massError',abs(sum(transfer,'all')-1));
writeJson(fullfile(folder,'exact_partition_test.json'),result);
save(fullfile(folder,'exact_partition_test.mat'),'result','time','demand','before','after','transfer');
fprintf('Exact partition oracle: max transfer error %.3g.\n',error);
end
