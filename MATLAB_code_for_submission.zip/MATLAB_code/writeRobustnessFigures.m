function writeRobustnessFigures()
%writeRobustnessFigures Plot actual completed audits, without synthetic data.
root = fileparts(mfilename('fullpath'));
folder = fullfile(root,'results','robustness_study');
fig = figure('Visible','off','Color','w','Position',[70,70,1150,780]);
cleanup = onCleanup(@() close(fig));
tiledlayout(2,2,'Padding','compact');
colors = lines(3); names = ["system","rescued","substituted"];
for caseName = ["sdof","building16"]
    data = readtable(fullfile(folder,caseName+'_time.csv'),'TextType','string');
    nexttile; hold on;
    for j = 1:3
        rows = data.metric==names(j) & data.level>min(data.level);
        plot(data.level(rows),abs(data.minusFinest(rows)),'o-','Color',colors(j,:), ...
            'DisplayName',names(j),'LineWidth',1.2);
    end
    set(gca,'XScale','log','YScale','log'); grid on;
    xlabel('Time step (s)'); ylabel('|Paired mean difference from 0.00125 s|');
    title(caseName,'Interpreter','none'); legend('Location','northwest');
end
nexttile; hold on;
for caseName = ["sdof","building16"]
    data = readtable(fullfile(folder,caseName+'_reference.csv'),'TextType','string');
    rows = data.metric=="system";
    errorbar(data.level(rows),data.estimate(rows),data.halfWidth95(rows),'o-', ...
        'DisplayName',caseName,'LineWidth',1.2);
end
xlabel('Outer samples per independent batch'); ylabel('System failure probability');
title('16 fresh independent batches per budget'); grid on; legend('Location','best','Interpreter','none');
nexttile; hold on; estimate = zeros(2,2); half = estimate;
caseNames = ["sdof","building16"];
for k = 1:2
    data = readtable(fullfile(folder,caseNames(k)+'_reference.csv'),'TextType','string');
    for j = 1:2
        rows = data.metric==names(j+1) & data.level==max(data.level);
        estimate(k,j) = data.estimate(rows); half(k,j) = data.halfWidth95(rows);
    end
end
b = bar(estimate);
for j = 1:2, errorbar(b(j).XEndPoints,estimate(:,j),half(:,j),'k.'); end
xticks(1:2); xticklabels({'SDOF','16-story'}); ylabel('Probability mass'); grid on;
legend(b,{'Failure prevented','First cause changed'},'Location','northwest');
title('First criterion capacity +20%');
exportgraphics(fig,fullfile(folder,'robustness_overview.png'),'Resolution',180);
print(fig,fullfile(folder,'robustness_overview.svg'),'-dsvg');
end
