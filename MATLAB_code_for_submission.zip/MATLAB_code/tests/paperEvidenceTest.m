classdef paperEvidenceTest < matlab.unittest.TestCase
    methods (TestClassSetup)
        function addProject(testCase)
            root = fileparts(fileparts(mfilename('fullpath')));
            testCase.applyFixture(matlab.unittest.fixtures.PathFixture(root));
        end
    end
    methods (Test)
        function densityDifferenceHandlesDiscontinuousLabel(testCase)
            z = (-8+0.0005:0.001:8)';
            weights = exp(-z.^2/2); weights = weights/sum(weights);
            h = 0.2;
            value = sum(weights.*(0.5*double(z<0)).*mrfp.gaussianLocationDifference(z,1,h));
            exact = (0.25*erfc(h/sqrt(2))-0.25*erfc(-h/sqrt(2)))/(2*h);
            testCase.verifyEqual(value,exact,'AbsTol',1e-8);
        end
        function tinyDensityStepConvergesToScore(testCase)
            z = [-2,1;0,3]; sd = [0.12,0.15];
            actual = mrfp.gaussianLocationDifference(z,sd,1e-9);
            testCase.verifyEqual(actual,z./sd,'AbsTol',1e-12);
        end
        function capacityPathPreservesDesignIdentities(testCase)
            time = [0;1;2]; demand = [0,0;1,0;1,0.8];
            law = struct('mu',0,'sigma',0.45);
            r = mrfp.capacityDesignPath(time,demand,law,1,[1,1.5,2]);
            testCase.verifyEqual(r.transport(:,:,1),diag(diag(r.transport(:,:,1))),'AbsTol',1e-14);
            testCase.verifyLessThanOrEqual(diff(r.metrics(:,2)),zeros(2,1));
            testCase.verifyEqual(r.metrics(:,1)-r.metrics(:,2),r.metrics(:,5),'AbsTol',1e-14);
            testCase.verifyEqual(r.metrics(:,3)-r.metrics(:,4),sum(r.metrics(:,5:6),2),'AbsTol',1e-14);
        end
        function streamAdvancesWithoutGlobalRngMutation(testCase)
            state = rng;
            first = RandStream('mt19937ar','Seed',791);
            a = mrfp.sampleGaussianUnion(eye(2)/2,16,1,Stream=first);
            b = mrfp.sampleGaussianUnion(eye(2)/2,16,1,Stream=first);
            second = RandStream('mt19937ar','Seed',791);
            c = mrfp.sampleGaussianUnion(eye(2)/2,16,1,Stream=second);
            testCase.verifyEqual(a.points,c.points);
            testCase.verifyNotEqual(a.points,b.points);
            testCase.verifyEqual(rng,state);
        end
        function comparisonTargetsHaveProbabilityAndGradientConservation(testCase)
            cfg = mrfp.makeConfig("sdof","smoke");
            q = [0.1,0.2,0;0.4,0.1,0]; z = [-1,0;1,2];
            [value,names] = mrfp.reliabilityStatistics(q,z,cfg);
            testCase.verifyEqual(value(4),sum(value(1:3)),'AbsTol',1e-14);
            testCase.verifyEqual(value(8),sum(value(5:7)),'AbsTol',1e-14);
            testCase.verifyEqual(value(12),sum(value(9:11)),'AbsTol',1e-14);
            testCase.verifyEqual(numel(names),12);
        end
    end
end
