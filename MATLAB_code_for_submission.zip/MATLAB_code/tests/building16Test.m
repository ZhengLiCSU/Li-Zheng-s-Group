classdef building16Test < matlab.unittest.TestCase
    %building16Test Literature eigenvalues, state ODE, and all-story observations.
    methods (TestClassSetup)
        function addProject(testCase)
            root = fileparts(fileparts(mfilename('fullpath')));
            testCase.applyFixture(matlab.unittest.fixtures.PathFixture(root));
        end
    end
    methods (Test)
        function changedSpectrumHasConsistentDimension(testCase)
            cfg = mrfp.makeBuilding16Config(NFrequency=512,FrequencyMax=40);
            testCase.verifyEqual(cfg.nInput,1026);
            testCase.verifyEqual(cfg.frequency(1),40/1024,'AbsTol',1e-14);
            testCase.verifyEqual(cfg.frequency(end),40-40/1024,'AbsTol',1e-14);
            testCase.verifyEqual(sum(cfg.frequencyWeights.^2),1,'AbsTol',1e-14);
        end
        function harmonicCacheMatchesUncachedEvaluation(testCase)
            for count = [16,32,16]
                cfg = mrfp.makeBuilding16Config(NFrequency=count);
                z = mrfp.sampleInputs(1,cfg.nInput,91271+count);
                series = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
                for dt = [0.01,0.005,0.01]
                    time = (0:dt:1)';
                    for order = 0:2
                        actual = mrfp.evaluateSeriesField(series,time,order);
                        expected = real(exp(time*series.poles.')*(series.poles.^order.*series.coefficients));
                        testCase.verifyLessThan(max(abs(actual-expected),[],'all'),1e-9);
                    end
                end
            end
        end
        function frequenciesMatchPublishedTable(testCase)
            cfg = mrfp.makeBuilding16Config();
            hz = sqrt(sort(eig(cfg.stiffness,cfg.mass)))/(2*pi);
            testCase.verifyEqual(hz(1:5)',cfg.publishedFrequencyHz,'AbsTol',0.01);
            testCase.verifyGreaterThan(min(hz),0);
        end
        function rayleighDampingMatchesFirstTwoModes(testCase)
            cfg = mrfp.makeBuilding16Config();
            [modes,lambda] = eig(cfg.stiffness,cfg.mass,'vector');
            [lambda,order] = sort(lambda); modes = modes(:,order);
            damping = mrfp.baseDamping(cfg,sqrt(lambda));
            ratios = diag(modes'*damping*modes)./(2*sqrt(lambda).*diag(modes'*cfg.mass*modes));
            testCase.verifyEqual(ratios(1:2),[0.005;0.005],'AbsTol',1e-12);
            testCase.verifyGreaterThan(min(ratios),0);
        end
        function allStoriesUseRelativeDrifts(testCase)
            cfg = mrfp.makeBuilding16Config();
            [mapU,mapV,mapA] = mrfp.outputMaps(cfg);
            testCase.verifyEqual(mapU*ones(16,1),[1/3;zeros(15,1)],'AbsTol',1e-15);
            testCase.verifyEqual(mapU*(1:16)',ones(16,1)/3,'AbsTol',1e-15);
            testCase.verifyEqual(mapV+mapA,zeros(16));
            testCase.verifyEqual(sum(cfg.frequencyWeights.^2),1,'AbsTol',1e-14);
        end
        function analyticResponseMatchesIndependentODE(testCase)
            [actual,reference] = responseAgainstODE();
            testCase.verifyLessThan(max(abs(actual-reference),[],'all'),2e-7);
        end
        function newmarkTangentMatchesStructuralPerturbation(testCase)
            [tangent,difference] = newmarkDifference();
            testCase.verifyLessThan(max(abs(tangent-difference),[],'all'),2e-6);
        end
        function roofCapacityOnlyChangesRoofCriterion(testCase)
            [before,after] = roofCapacityChange();
            testCase.verifyEqual(after(:,1:15),before(:,1:15),'AbsTol',1e-12);
            testCase.verifyEqual(after(:,16),before(:,16)/1.2,'AbsTol',1e-12);
        end
    end
end

function [actual,reference] = responseAgainstODE()
cfg = mrfp.makeBuilding16Config(); cfg.duration = 1.5;
random = mrfp.sampleInputs(1,cfg.nInput,424201);
design = zeros(1,cfg.nPathParameter+2);
series = mrfp.makeResponseSeries(cfg,random,design);
time = (0:0.005:cfg.duration)';
actual = mrfp.evaluateSeriesField(series,time);
omega = 2*pi*cfg.frequency;
sinWeights = cfg.frequencyWeights.*random(3:2+cfg.nFrequency);
cosWeights = cfg.frequencyWeights.*random(3+cfg.nFrequency:end);
forcing = @(t) cfg.excitationScale*sin(pi*t/cfg.duration)^2* ...
    (sin(t*omega)*sinWeights'+cos(t*omega)*cosWeights');
generator = [zeros(16),eye(16);-series.mass\series.stiffness,-series.mass\series.damping];
input = [zeros(16,1);-ones(16,1)];
[~,states] = ode45(@(t,y) generator*y+input*forcing(t),time,zeros(32,1), ...
    odeset('RelTol',1e-10,'AbsTol',1e-12));
drift = [states(:,1),diff(states(:,1:16),1,2)]./cfg.storyHeight;
reference = drift./cfg.thresholds;
end

function [tangent,difference] = newmarkDifference()
cfg = mrfp.makeBuilding16Config(); cfg.duration = 1;
random = mrfp.sampleInputs(1,cfg.nInput,424202);
design = zeros(1,cfg.nPathParameter+2);
path = mrfp.solveTrajectory(cfg,random,design,0.002,true);
h = 1e-5; plus = design; minus = design;
plus(1) = h; minus(1) = -h;
a = mrfp.solveTrajectory(cfg,random,plus,0.002,false);
b = mrfp.solveTrajectory(cfg,random,minus,0.002,false);
tangent = path.tangent(:,:,1);
difference = (a.demand-b.demand)/(2*h);
end

function [before,after] = roofCapacityChange()
cfg = mrfp.makeBuilding16Config(); cfg.duration = 1;
random = mrfp.sampleInputs(1,cfg.nInput,424203);
design = zeros(1,cfg.nPathParameter+2);
a = mrfp.makeResponseSeries(cfg,random,design);
design(2+16) = log(1.2);
b = mrfp.makeResponseSeries(cfg,random,design);
time = (0:0.01:1)';
before = mrfp.evaluateSeriesField(a,time);
after = mrfp.evaluateSeriesField(b,time);
end
