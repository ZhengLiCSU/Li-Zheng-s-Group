classdef robustnessV2Test < matlab.unittest.TestCase
    %robustnessV2Test Regression guards for accelerated terminal certification.
    methods (TestClassSetup)
        function paths(testCase)
            root = fileparts(fileparts(mfilename('fullpath')));
            testCase.applyFixture(matlab.unittest.fixtures.PathFixture(root));
            testCase.applyFixture(matlab.unittest.fixtures.PathFixture(fullfile(root,'code','robustness')));
        end
    end
    methods (Test)
        function compressedMatchesFull(testCase)
            [a,b] = partitionComparison();
            testCase.verifyEqual(a,b,AbsTol=1e-12);
        end
        function lowerBoundMatchesFull(testCase)
            [a,b] = boundComparison();
            testCase.verifyEqual(a,b,AbsTol=1e-12);
        end
        function fastTubeMatchesFull(testCase)
            [a,b] = tubeComparison();
            testCase.verifyEqual(a,b,AbsTol=1e-12);
        end
        function initialTiesPreserved(testCase)
            law = struct('mu',0,'sigma',0.45);
            result = terminalPartition([0;1;2],[1,2;1,2;1,2],[1,2],law);
            testCase.verifyEqual(result.probability(1),0,AbsTol=1e-14);
            testCase.verifyEqual(result.probability(3),0.5,AbsTol=1e-14);
            testCase.verifyEqual(sum(result.probability),1,AbsTol=1e-14);
        end
        function chunkBoundaryTubesMatch(testCase)
            [a,b] = chunkComparison();
            testCase.verifyEqual(a,b,AbsTol=1e-12);
        end
        function fourCauseOracle(testCase)
            root = tempname;
            mkdir(root);
            result = run_exact_partition_test(robustnessConfig(),root);
            testCase.verifyLessThan(result.maxPartitionError,1e-12);
            testCase.verifyLessThan(result.massError,1e-12);
        end
    end
end

function [a,b] = chunkComparison()
cfg = buildBalancedModel();
input = mrfp.sampleInputs(1,cfg.nInput,985,"mc");
series = mrfp.makeResponseSeries(cfg,input,zeros(1,cfg.nPathParameter+2));
time = (0:0.01:12)';
full = evaluateTube(series,time);
chunk = evaluateTubeChunked(series,time,33);
a = [full.demand,full.radius];
b = [chunk.demand,chunk.radius];
end

function [a,b] = partitionComparison()
time = (0:0.01:5)';
values = [sin(time),0.9*sin(3*time),-sin(time),-0.9*sin(3*time)];
law = struct('mu',0,'sigma',0.45);
full = mrfp.integrateBranches(time,values,[1,2,1,2],law,StorePartition=true);
fast = terminalPartition(time,values,[1,2,1,2],law);
a = fast.partition;
b = full.partition;
end

function [a,b] = boundComparison()
time = (0:0.01:5)';
demand = [sin(time),0.9*sin(3*time),0.5*cos(4*time)];
radius = 0.002+0*demand;
law = struct('mu',0,'sigma',0.45);
full = mrfp.boundFirstCause(time,demand,radius,law,StorePartition=true);
fast = resolutionBounds(time,demand,radius,law);
a = [fast.lower(1:3),fast.unresolved];
b = [full.lower(end,:),full.unresolvedMassUpper(end)];
end

function [a,b] = tubeComparison()
cfg = mrfp.makeBuilding16Config("study",NFrequency=16);
input = mrfp.sampleInputs(1,cfg.nInput,783,"mc");
series = mrfp.makeResponseSeries(cfg,input,zeros(1,cfg.nPathParameter+2));
time = (0:0.01:12)';
full = mrfp.evaluateResponseSeries(series,time);
fast = evaluateTube(series,time);
a = [fast.demand,fast.radius];
b = [full.demand,full.radius];
end
