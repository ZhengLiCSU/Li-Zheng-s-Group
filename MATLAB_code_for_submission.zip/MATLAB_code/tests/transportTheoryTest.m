classdef transportTheoryTest < matlab.unittest.TestCase
    methods (TestClassSetup)
        function addProject(testCase)
            root = fileparts(fileparts(mfilename('fullpath')));
            testCase.applyFixture(matlab.unittest.fixtures.PathFixture(root));
        end
    end
    methods (Test)
        function transportMarginalsAndRescue(testCase)
            [transport,before,after] = analyticTransport();
            testCase.verifyEqual(sum(transport.matrix,2),before,'AbsTol',1e-12);
            testCase.verifyEqual(sum(transport.matrix,1)',after,'AbsTol',1e-12);
            testCase.verifyEqual(sum(transport.matrix,'all'),1,'AbsTol',1e-12);
            testCase.verifyEqual(transport.matrix(4,1:3),zeros(1,3),'AbsTol',1e-12);
            testCase.verifyGreaterThan(transport.matrix(1,2),0);
            testCase.verifyGreaterThan(transport.matrix(1,4),0);
        end
        function zeroTubePairedCertificateExact(testCase)
            time = [0;1;2];
            demand = [0,0;1,0;1,0.8];
            a = mrfp.boundFirstCause(time,demand,zeros(size(demand)),law(),StorePartition=true);
            b = mrfp.boundFirstCause(time,demand./[2,1],zeros(size(demand)),law(),StorePartition=true);
            r = mrfp.transportPartitions(a.certifiedPartition,b.certifiedPartition,law(),4);
            testCase.verifyEqual(r.unresolvedMass,0,'AbsTol',1e-12);
            testCase.verifyEqual(sum(r.matrix,'all'),1,'AbsTol',1e-12);
        end
        function pairedCertificateContainsExactTransport(testCase)
            time = [0;1;2];
            demand = [0,0;1,0;1,0.8];
            radius = 0.02*ones(size(demand));
            a = mrfp.boundFirstCause(time,demand,radius,law(),StorePartition=true);
            b = mrfp.boundFirstCause(time,demand./[2,1],radius,law(),StorePartition=true);
            r = mrfp.transportPartitions(a.certifiedPartition,b.certifiedPartition,law(),4);
            exact = analyticTransport();
            testCase.verifyGreaterThanOrEqual(exact.matrix-r.matrix,-1e-12);
            testCase.verifyGreaterThanOrEqual(r.entryUpper-exact.matrix,-1e-12);
            testCase.verifyLessThanOrEqual(r.unresolvedMass, ...
                a.unresolvedMassUpper(end)+b.unresolvedMassUpper(end)+1e-12);
        end
        function pathwiseDerivativeMissesJump(testCase)
            [pathwise,weak,exact] = jumpExample();
            testCase.verifyEqual(pathwise,0,'AbsTol',1e-15);
            testCase.verifyEqual(weak,exact,'AbsTol',1e-10);
            testCase.verifyGreaterThan(abs(weak-pathwise),0.19);
        end
        function signedScoreBounds(testCase)
            result = mrfp.boundScoreSensitivity([0.1;0.4],[0.2;0.6],[-2;1],0.5,[0.5;0.5]);
            testCase.verifyEqual(result.lower,0,'AbsTol',1e-14);
            testCase.verifyEqual(result.upper,0.4,'AbsTol',1e-14);
        end
        function publicScoreIntegratesDiscontinuousCause(testCase)
            z = (-8+0.0005:0.001:8)';
            weights = exp(-z.^2/2); weights = weights/sum(weights);
            q = 0.5*double(z<0);
            derivative = mrfp.scoreSensitivity(q,z,1,weights);
            testCase.verifyEqual(derivative,-0.5/sqrt(2*pi),'AbsTol',1e-8);
        end
        function tiedCapacityHasDifferentOneSidedDerivatives(testCase)
            r = mrfp.systemCapacityDerivative([1,1],1,law());
            testCase.verifyEqual(r.right,0);
            testCase.verifyEqual(r.left,-1/(0.45*sqrt(2*pi)),'AbsTol',1e-14);
            testCase.verifyTrue(isnan(r.ordinary));
            h = 1e-6;
            changed = mrfp.amplitudeMass(exp(h),0,law());
            testCase.verifyEqual((r.probability-changed)/h,r.left,'AbsTol',1e-5);
        end
        function zeroAndDominatedCapacityAreInsensitive(testCase)
            a = mrfp.systemCapacityDerivative([0,0],1,law());
            b = mrfp.systemCapacityDerivative([0.5,1],1,law());
            testCase.verifyEqual([a.left,a.right,b.left,b.right],zeros(1,4));
        end
        function criticalAndNearCriticalODE(testCase)
            errors = criticalErrors();
            testCase.verifyLessThan(max(errors),1e-8);
        end
        function criticalTubeCoversContinuousResponse(testCase)
            cfg = mrfp.makeConfig("sdof","smoke");
            cfg.dampingRatio = 1;
            z = zeros(1,cfg.nInput); z(3) = 1;
            s = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
            coarse = mrfp.evaluateResponseSeries(s,(0:0.08:12)');
            fine = mrfp.evaluateResponseSeries(s,(0:0.001:12)');
            difference = abs(fine.demand-interp1(coarse.time,coarse.demand,fine.time));
            radius = interp1(coarse.time,coarse.radius,fine.time);
            testCase.verifyLessThanOrEqual(max(difference-radius,[],'all'),1e-12);
        end
        function criticalCapacityScaling(testCase)
            cfg = mrfp.makeConfig("sdof","smoke"); cfg.dampingRatio = 1;
            z = zeros(1,cfg.nInput); z(3) = 1;
            a = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
            b = mrfp.scaleSeriesCapacity(a,1,1.1);
            time = (0:0.01:12)';
            before = mrfp.evaluateSeriesField(a,time);
            after = mrfp.evaluateSeriesField(b,time);
            testCase.verifyEqual(after,before./[1.1,1],'AbsTol',1e-12);
        end
        function surfaceSingleConstraint(testCase)
            r = mrfp.sampleGaussianSurface(0.5,true,64,101);
            testCase.verifyEqual(r.estimate,-4*exp(-2)/sqrt(2*pi),'AbsTol',1e-14);
        end
        function zeroSelectedSurfaceHasZeroDerivative(testCase)
            r = mrfp.sampleGaussianSurface([0;0.5],[true;false],8,101);
            testCase.verifyEqual(r.estimate,0);
            testCase.verifyEqual(r.normalizer,0);
        end
        function surfaceIndependentConstraints(testCase)
            r = mrfp.sampleGaussianSurface(eye(2)/2,[true;false],50000,101);
            exact = -4*exp(-2)/sqrt(2*pi)*(1-erfc(2/sqrt(2)));
            testCase.verifyLessThan(abs(r.estimate-exact),5*r.standardError);
        end
        function surfaceRejectsCoincidentBoundaries(testCase)
            testCase.verifyError(@() mrfp.sampleGaussianSurface([0.5;-0.5],[true;true],64,101), ...
                'mrfp:CoincidentSurface');
        end
        function finiteBudgetBoundIsNondegenerate(testCase)
            r = mrfp.boundedMeanEnvelope(zeros(100,1),zeros(100,1),[0;1]);
            testCase.verifyEqual(r.lower,0);
            testCase.verifyGreaterThan(r.upper,0.1);
        end
    end
end

function result = law()
result = struct('mu',0,'sigma',0.45);
end

function [transport,before,after] = analyticTransport()
time = [0;1;2];
demand = [0,0;1,0;1,0.8];
a = mrfp.integrateBranches(time,[demand,-demand],[1,2,1,2],law(),StorePartition=true);
newDemand = demand./[2,1];
b = mrfp.integrateBranches(time,[newDemand,-newDemand],[1,2,1,2],law(),StorePartition=true);
transport = mrfp.transportPartitions(a.partition,b.partition,law(),4);
before = [a.uniqueCause(end,:),a.joint(end),1-a.failure(end)]';
after = [b.uniqueCause(end,:),b.joint(end),1-b.failure(end)]';
end

function [pathwise,weak,exact] = jumpExample()
% d1(t)=t*exp(Z+p), d2(t)=t: conditional F2=H(1)*1{Z+p<0}.
pathwise = 0;
weak = integral(@(z) 0.5*z.*exp(-z.^2/2)/sqrt(2*pi),-Inf,0,'AbsTol',1e-12);
exact = -0.5/sqrt(2*pi);
end

function errors = criticalErrors()
ratios = [1,1-1e-12,1+1e-12];
errors = zeros(size(ratios));
for i = 1:numel(ratios)
    cfg = mrfp.makeConfig("sdof","smoke"); cfg.dampingRatio = ratios(i);
    z = zeros(1,cfg.nInput); z(3) = 1;
    s = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
    time = (0:0.04:12)';
    u = mrfp.evaluateSeriesField(s,time,0,"displacement");
    v = mrfp.evaluateSeriesField(s,time,1,"displacement");
    a = mrfp.evaluateSeriesField(s,time,2,"displacement");
    force = cfg.excitationScale/sqrt(cfg.nFrequency)*sin(pi*time/12).^2.* ...
        sin(2*pi*cfg.frequency(1)*time);
    residual = a*s.mass+v*s.damping+u*s.stiffness-force;
    errors(i) = max(abs([residual;u(1);v(1)]));
end
end
