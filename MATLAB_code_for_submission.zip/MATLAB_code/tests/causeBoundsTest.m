classdef causeBoundsTest < matlab.unittest.TestCase
    %causeBoundsTest Analytic event bounds and independent dynamics checks.
    methods (TestClassSetup)
        function addProject(testCase)
            root = fileparts(fileparts(mfilename('fullpath')));
            testCase.applyFixture(matlab.unittest.fixtures.PathFixture(root));
        end
    end
    methods (Test)
        function exactZeroTube(testCase)
            d = [0,0;0.2,0;1,1.2];
            b = mrfp.boundFirstCause([0;1;2],d,zeros(size(d)),law());
            expected = [cdf(0.6),cdf(1.2)-cdf(0.6)];
            testCase.verifyEqual(b.lower(end,:),expected,'AbsTol',1e-13);
            testCase.verifyEqual(b.upper,b.lower,'AbsTol',1e-13);
            testCase.verifyEqual(b.unresolvedMassUpper,zeros(3,1),'AbsTol',1e-13);
        end
        function initialFailureSubsets(testCase)
            b = mrfp.integrateBranches([0;1],[1,2;1,2],[1,2],law());
            testCase.verifyEqual(b.uniqueCause(end,:),[0,cdf(2)-cdf(1)],'AbsTol',1e-13);
            testCase.verifyEqual(b.inclusiveCause(end,:),[cdf(1),cdf(2)],'AbsTol',1e-13);
            testCase.verifyEqual(b.joint(end),cdf(1),'AbsTol',1e-13);
        end
        function initialFailureSubsetsInSensitivityEngine(testCase)
            r = mrfp.integrateFrontier([0;1],[1,2;1,2],zeros(2,2,1),law());
            testCase.verifyEqual(r.cause(end,:),[0,cdf(2)-cdf(1),cdf(1)],'AbsTol',1e-13);
            testCase.verifyFalse(r.gradientValid);
        end
        function positiveMassTieRemainsUnresolved(testCase)
            d = [0,0;1,1];
            b = mrfp.boundFirstCause([0;1],d,zeros(size(d)),law());
            testCase.verifyEqual(b.lower(end,:),[0,0],'AbsTol',1e-14);
            testCase.verifyEqual(b.upper(end,:),[0.5,0.5],'AbsTol',1e-14);
            testCase.verifyEqual(b.unresolvedMassUpper(end),0.5,'AbsTol',1e-14);
        end
        function differentCausesSameTotalProbability(testCase)
            time = [0;1];
            d = [0,0;1,1];
            radius = [0,0;0.01,0.01];
            b = mrfp.boundFirstCause(time,d,radius,law());
            a = mrfp.integrateBranches(time,[0,0;1.01,0.99],[1,2],law());
            z = mrfp.integrateBranches(time,[0,0;0.99,1.01],[1,2],law());
            testCase.verifyEqual(a.failure,z.failure,'AbsTol',1e-14);
            testCase.verifyGreaterThan(abs(a.uniqueCause(end,1)-z.uniqueCause(end,1)),0.5);
            testCase.verifyLessThan(b.failureUpper(end)-b.failureLower(end),0.02);
            testCase.verifyGreaterThan(b.unresolvedMassUpper(end),0.5);
        end
        function oscillatoryTubeContainsIndependentEvents(testCase)
            [violation,conservation] = oscillatoryCheck();
            testCase.verifyLessThanOrEqual(violation,2e-5);
            testCase.verifyLessThanOrEqual(conservation,1e-12);
        end
        function seriesSatisfiesBuildingODE(testCase)
            cfg = mrfp.makeConfig("building","smoke");
            z = mrfp.sampleInputs(1,cfg.nInput,1729,"mc");
            s = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
            [relativeResidual,initialError] = odeResidual(s);
            testCase.verifyLessThan(relativeResidual,1e-11);
            testCase.verifyLessThan(initialError,1e-11);
        end
        function seriesAgainstIndependentOde45(testCase)
            [seriesValue,reference] = compareOde45();
            testCase.verifyLessThan(max(abs(seriesValue-reference),[],'all'),1e-8);
        end
        function overdampedSeriesSatisfiesODE(testCase)
            cfg = mrfp.makeConfig("sdof","smoke");
            cfg.dampingRatio = 1.4;
            z = mrfp.sampleInputs(1,cfg.nInput,117,"mc");
            s = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
            [relativeResidual,initialError] = odeResidual(s);
            testCase.verifyLessThan(relativeResidual,1e-11);
            testCase.verifyLessThan(initialError,1e-11);
        end
        function analyticTubeCoversDenseContinuousResponse(testCase)
            cfg = mrfp.makeConfig("building","smoke");
            z = mrfp.sampleInputs(1,cfg.nInput,7304,"mc");
            s = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
            coarse = mrfp.evaluateResponseSeries(s,(0:0.08:12)');
            fine = mrfp.evaluateResponseSeries(s,(0:0.001:12)');
            center = interp1(coarse.time,coarse.demand,fine.time);
            radius = interp1(coarse.time,coarse.radius,fine.time);
            testCase.verifyLessThanOrEqual(max(abs(fine.demand-center)-radius,[],'all'),1e-12);
        end
        function continuousCauseBoundsContainFineReference(testCase)
            cfg = mrfp.makeConfig("building","smoke");
            z = mrfp.sampleInputs(1,cfg.nInput,7304,"mc");
            s = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
            coarse = mrfp.evaluateResponseSeries(s,(0:0.04:12)');
            fine = mrfp.evaluateResponseSeries(s,(0:0.0005:12)');
            b = mrfp.boundFirstCause(coarse.time,coarse.demand,coarse.radius,s.law);
            r = mrfp.integrateBranches(fine.time,[fine.demand,-fine.demand],[1:3,1:3],s.law);
            testCase.verifyGreaterThanOrEqual(r.uniqueCause(end,:)-b.lower(end,:),-1e-12);
            testCase.verifyGreaterThanOrEqual(b.upper(end,:)-r.uniqueCause(end,:),-1e-12);
        end
        function controlledRefinementStops(testCase)
            cfg = mrfp.makeConfig("sdof","smoke");
            z = mrfp.sampleInputs(1,cfg.nInput,73,"mc");
            s = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
            r = mrfp.refineCauseBounds(s,Tolerance=0.005,MaxRefinement=5);
            testCase.verifyTrue(r.converged);
            testCase.verifyLessThanOrEqual(r.bounds.unresolvedMassUpper(end),0.005);
        end
        function importanceSamplerSingleRareConstraint(testCase)
            r = mrfp.sampleGaussianUnion(1/6,64,17);
            expected = erfc(6/sqrt(2));
            testCase.verifyEqual(r.estimate,expected,'RelTol',1e-13);
            testCase.verifyEqual(r.weight,expected*ones(1,64),'RelTol',1e-13);
        end
        function importanceSamplerIndependentUnion(testCase)
            r = mrfp.sampleGaussianUnion(eye(3)/2,50000,113);
            expected = 1-(1-erfc(2/sqrt(2)))^3;
            testCase.verifyLessThan(abs(r.estimate-expected),5*r.standardError);
        end
        function importanceSamplerDuplicateConstraints(testCase)
            r = mrfp.sampleGaussianUnion([0.5;0.5;-0.5],64,17);
            testCase.verifyEqual(r.estimate,erfc(2/sqrt(2)),'RelTol',1e-13);
        end
        function importanceFiniteCapacityChange(testCase)
            r = mrfp.sampleGaussianUnion(0.5,100000,23);
            difference = r.weight.*(double(abs(r.response)>=1.05)-1);
            expected = erfc(2.1/sqrt(2))-erfc(2/sqrt(2));
            testCase.verifyLessThan(abs(mean(difference)-expected),5*std(difference)/sqrt(100000));
        end
        function gaussianOperatorMatchesTrajectory(testCase)
            cfg = mrfp.makeConfig("building","smoke");
            z = mrfp.sampleInputs(1,cfg.nInput,153,"mc");
            time = (0:0.04:cfg.duration)';
            operator = mrfp.makeGaussianOperator(cfg,z(1:2),time);
            s = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
            p = mrfp.evaluateResponseSeries(s,time);
            testCase.verifyEqual(operator*z(3:end)',p.demand(:),'AbsTol',1e-12);
        end
    end
end

function result = law()
result = struct('mu',0,'sigma',0.45);
end

function result = cdf(r)
result = 0.5*erfc(-log(r)/(sqrt(2)*0.45));
end

function [violation,conservation] = oscillatoryCheck()
% Independent amplitude quadrature plus direct event location; not the
% branch integral under test. Includes zero-crossings and changing tube size.
time = (0:0.1:2)';
center = [sin(4*time),0.8*sin(3*time)];
radius = 0.02+0.01*[time,time];
b = mrfp.boundFirstCause(time,center,radius,law());
truePath = center+radius.*[sin(7*time),cos(5*time)];
n = 100000;
amplitude = exp(0.45*sqrt(2)*erfinv(2*((1:n)'-0.5)/n-1));
counts = zeros(1,2);
for i = 1:n
    event = mrfp.firstEvent(time,truePath,amplitude(i));
    if event.cause>=1 && event.cause<=2
        counts(event.cause) = counts(event.cause)+1;
    end
end
reference = counts/n;
violation = max([b.lower(end,:)-reference,reference-b.upper(end,:),0]);
conservation = max(sum(b.lower,2)-b.failureUpper);
end

function [relativeResidual,initialError] = odeResidual(s)
time = linspace(0,s.duration,317)';
e = exp(time*s.poles.');
u = real(e*s.displacementCoefficients);
v = real(e*(s.poles.*s.displacementCoefficients));
a = real(e*(s.poles.^2.*s.displacementCoefficients));
f = real(exp(1i*time*s.forcingOmega.')*s.forcingCoefficient);
residual = a*s.mass'+v*s.damping'+u*s.stiffness'-f*s.loadVector';
relativeResidual = max(abs(residual),[],'all')/max(1,max(abs(f*s.loadVector'),[],'all'));
initialError = max(abs([u(1,:),v(1,:)]));
end

function [seriesValue,reference] = compareOde45()
cfg = mrfp.makeConfig("sdof","smoke");
z = mrfp.sampleInputs(1,cfg.nInput,117,"mc");
s = mrfp.makeResponseSeries(cfg,z,zeros(1,cfg.nPathParameter+2));
time = linspace(0,cfg.duration,301)';
e = exp(time*s.poles.');
seriesValue = [real(e*s.displacementCoefficients), ...
    real(e*(s.poles.*s.displacementCoefficients))];
% Construct forcing directly from the ORIGINAL sin^2 envelope, not series.
force = @(t) cfg.excitationScale*sin(pi*t/cfg.duration).^2.* ...
    (sin(t*2*pi*cfg.frequency)*z(3:2+cfg.nFrequency)' + ...
    cos(t*2*pi*cfg.frequency)*z(3+cfg.nFrequency:end)')/sqrt(cfg.nFrequency);
rhs = @(t,y) [y(2);(force(t)-s.damping*y(2)-s.stiffness*y(1))/s.mass];
[~,reference] = ode45(rhs,time,[0;0],odeset('RelTol',1e-11,'AbsTol',1e-13));
end
