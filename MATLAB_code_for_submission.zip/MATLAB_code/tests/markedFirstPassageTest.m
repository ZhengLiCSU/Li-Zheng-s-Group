classdef markedFirstPassageTest < matlab.unittest.TestCase
    %markedFirstPassageTest Independent identities and numerical checks.
    methods (TestClassSetup)
        function addProject(testCase)
            root = fileparts(fileparts(mfilename('fullpath')));
            testCase.applyFixture(matlab.unittest.fixtures.PathFixture(root));
        end
    end
    methods (Test)
        function zeroResponse(testCase)
            r = mrfp.integrateFrontier((0:2)',zeros(3,2),zeros(3,2,1),law());
            testCase.verifyEqual(r.failure,zeros(3,1),'AbsTol',1e-14);
            testCase.verifyEqual(r.survival,ones(3,1),'AbsTol',1e-14);
        end
        function oneModeAnalytic(testCase)
            d = [0;0.5;0.2;1];
            r = mrfp.integrateFrontier((0:3)',d,zeros(4,1,1),law());
            expected = [0;normalCdf(log(0.5)/0.45);normalCdf(log(0.5)/0.45);0.5];
            testCase.verifyEqual(r.failure,expected,'AbsTol',1e-13);
            testCase.verifyGreaterThanOrEqual(diff(r.failure),-1e-14);
        end
        function markedEnvelopeClosedForm(testCase)
            d = [0.2,0;1,1.2];
            r = mrfp.integrateFrontier([0;1],d,zeros(2,2,1),law());
            h06 = normalCdf(log(0.6)/0.45);
            h12 = normalCdf(log(1.2)/0.45);
            testCase.verifyEqual(r.cause(end,:),[h06,h12-h06,0],'AbsTol',1e-12);
            testCase.verifyEqual(r.failure,r.directFailure,'AbsTol',1e-12);
        end
        function movingBoundaryDerivative(testCase)
            d = [0.2,0;1,1.2];
            tangent = [-0.2,0;-1,0];
            r = mrfp.integrateFrontier([0;1],d,tangent,law());
            z = log(0.6)/0.45;
            value = -1.8*exp(-z*z/2)/(sqrt(2*pi)*0.45*0.6);
            testCase.verifyEqual(r.gradient(end,1,1),value,'AbsTol',1e-11);
            testCase.verifyEqual(sum(r.gradient(end,:,1)),0,'AbsTol',1e-11);
            testCase.verifyGreaterThan(abs(r.transferGradient(end,1,1)),0.1);
            testCase.verifyEqual(sum(r.transferGradient(end,:,1)),0,'AbsTol',1e-11);
            testCase.verifyEqual(r.exchangeGradient(end,1,1),value,'AbsTol',1e-11);
            testCase.verifyEqual(sum(r.exchangeGradient(end,:,1)),0,'AbsTol',1e-11);
        end
        function movingBoundaryFiniteDifference(testCase)
            d = [0.2,0;1,1.2];
            h = 1e-5;
            plus = d.*[exp(-h),1];
            minus = d.*[exp(h),1];
            rp = mrfp.integrateFrontier([0;1],plus,zeros(2,2,1),law());
            rm = mrfp.integrateFrontier([0;1],minus,zeros(2,2,1),law());
            r = mrfp.integrateFrontier([0;1],d,[-0.2,0;-1,0],law());
            fd = (rp.cause(end,:)-rm.cause(end,:))/(2*h);
            testCase.verifyEqual(reshape(r.gradient(end,:,1),1,[]),fd,'AbsTol',1e-7);
        end
        function trueCoincidenceReported(testCase)
            d = [0,0;1,1];
            r = mrfp.integrateFrontier([0;1],d,zeros(2,2,1),law());
            testCase.verifyEqual(r.cause(end,:),[0,0,0.5],'AbsTol',1e-14);
            testCase.verifyFalse(r.gradientValid);
            testCase.verifyTrue(all(isnan(r.gradient),'all'));
        end
        function negativeExcursion(testCase)
            r = mrfp.integrateFrontier([0;1;2],[0;-1;0],zeros(3,1,1),law());
            testCase.verifyEqual(r.failure,[0;0.5;0.5],'AbsTol',1e-14);
        end
        function smallResponsesAreNotTies(testCase)
            d = [0,0;1e-12,0.8e-12;1,1.2];
            r = mrfp.integrateFrontier([0;1;2],d,zeros(3,2,1),law());
            testCase.verifyTrue(r.gradientValid);
            testCase.verifyEqual(r.cause(end,end),0,'AbsTol',1e-14);
        end
        function independentEventLocation(testCase)
            d = [0.2,0;1,1.2];
            e = mrfp.firstEvent([0;1],d,1/0.8);
            testCase.verifyEqual(e.cause,2);
            testCase.verifyEqual(e.time,2/3,'AbsTol',1e-12);
        end
        function newmarkTangent(testCase)
            cfg = mrfp.makeConfig("building","smoke");
            z = mrfp.sampleInputs(1,cfg.nInput,901,"mc");
            base = zeros(1,cfg.nPathParameter+2);
            offset = base;
            offset(1) = 1e-5;
            path = mrfp.solveTrajectory(cfg,z,base);
            plus = mrfp.solveTrajectory(cfg,z,offset,cfg.dt,false);
            minus = mrfp.solveTrajectory(cfg,z,-offset,cfg.dt,false);
            fd = (plus.demand-minus.demand)/(2e-5);
            testCase.verifyLessThan(max(abs(path.tangent(:,:,1)-fd),[],'all'),1e-6);
        end
        function lawDerivatives(testCase)
            [~,derivative] = mrfp.amplitudeMass(0.7,0,law());
            h = 1e-5;
            plusLaw = struct('mu',h,'sigma',0.45);
            minusLaw = struct('mu',-h,'sigma',0.45);
            fd = (mrfp.amplitudeMass(0.7,0,plusLaw)-mrfp.amplitudeMass(0.7,0,minusLaw))/(2*h);
            testCase.verifyEqual(derivative(2),fd,'AbsTol',1e-8);
        end
        function pdfNormalization(testCase)
            points = [-2;-1;0;1;2];
            pdf = mrfp.estimatePdf(points,ones(5,1),5,400);
            testCase.verifyEqual(pdf.mass,1,'AbsTol',5e-5);
        end
        function unequalWeights(testCase)
            pdf = mrfp.estimatePdf([0;1],[1;3],2,400);
            testCase.verifyEqual(trapz(pdf.x,pdf.x.*pdf.density),0.75,'AbsTol',2e-4);
        end
        function pairedJointPdf(testCase)
            samples = [-1,-1;0,0.5;1,2;2,0];
            pdf = mrfp.estimatePdf(samples,ones(4,1),4,180);
            xCenter = mean(samples(:,1));
            yCenter = mean(samples(:,2));
            [x,y] = ndgrid(pdf.x,pdf.y);
            covariance = mean((samples(:,1)-xCenter).*(samples(:,2)-yCenter)) + pdf.bandwidth(1,2);
            numerical = trapz(pdf.y,trapz(pdf.x,(x-xCenter).*(y-yCenter).*pdf.density,1));
            testCase.verifyEqual(pdf.mass,1,'AbsTol',1e-4);
            testCase.verifyEqual(numerical,covariance,'AbsTol',5e-4);
        end
        function weightedPathAdapter(testCase)
            data = zeros(2,2,3);
            data(:,:,1) = [0,0;2,0];
            data(:,:,2) = [0,0;0,2];
            data(:,:,3) = [0,0;0.1,0.1];
            r = mrfp.analyzeWeightedPaths([0;1],data,[1,1],[0.2;0.3;0.5]);
            testCase.verifyEqual(r.cause(end,:),[0.2,0.3,0],'AbsTol',1e-14);
            testCase.verifyEqual(r.survival(end),0.5,'AbsTol',1e-14);
        end
        function fineReferenceBracket(testCase)
            cfg = mrfp.makeConfig("sdof","smoke");
            inputs = mrfp.sampleInputs(2,cfg.nInput,43);
            r = mrfp.verifyResolution(cfg,inputs);
            testCase.verifyLessThanOrEqual(r.maxBracketViolation,1e-12);
        end
        function sdofAgainstOde45(testCase)
            cfg = mrfp.makeConfig("sdof","smoke");
            cfg.dt = 0.003;
            z = zeros(1,cfg.nInput);
            z(3) = 1;
            path = mrfp.solveTrajectory(cfg,z,zeros(1,cfg.nPathParameter+2),cfg.dt,false);
            omega = 2*pi*cfg.frequency(1);
            force = @(t) cfg.excitationScale*sin(pi*t/cfg.duration).^2.*sin(omega*t)/sqrt(cfg.nFrequency);
            damping = 2*cfg.dampingRatio*sqrt(cfg.stiffness*cfg.mass);
            rhs = @(t,y) [y(2);(force(t)-damping*y(2)-cfg.stiffness*y(1))/cfg.mass];
            [~,reference] = ode45(rhs,path.time,[0;0],odeset('RelTol',1e-10,'AbsTol',1e-12));
            testCase.verifyLessThan(max(abs(path.displacement-reference(:,1))),2e-6);
        end
    end
end

function result = law()
result = struct('mu',0,'sigma',0.45);
end

function p = normalCdf(z)
p = 0.5*erfc(-z/sqrt(2));
end
