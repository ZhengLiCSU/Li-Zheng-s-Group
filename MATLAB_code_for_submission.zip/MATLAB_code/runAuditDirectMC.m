function report = runAuditDirectMC(caseName)
%runAuditDirectMC Independent inputs and separate crossing classifier.
arguments
    caseName (1,1) string {mustBeMember(caseName,["sdof","building16"])}
end
root = fileparts(mfilename('fullpath'));
folder = fullfile(root,'results','robustness_study');
if ~isfolder(folder), mkdir(folder); end
cfg = mrfp.makeConfig("sdof","study");
if caseName=="building16", cfg = mrfp.makeBuilding16Config(NFrequency=512); end
cfg.dt = 0.0025; time = (0:cfg.dt:cfg.duration)';
n = 1024; batches = 16; names = [cfg.modeNames,"joint","safe"];
counts = zeros(batches,cfg.nMode+2); seconds = zeros(batches,1);
transferCounts = zeros(cfg.nMode+2,cfg.nMode+2,batches);
for rep = 1:batches
    timer = tic;
    random = mrfp.sampleInputs(n,cfg.nInput+1,120926000+rep,"mc");
    for k = 1:n
        series = mrfp.makeResponseSeries(cfg,random(k,1:end-1),zeros(1,cfg.nPathParameter+2));
        demand = mrfp.evaluateSeriesField(series,time);
        amplitude = cfg.amplitudeMedian*exp(cfg.amplitudeLogSd*random(k,end));
        event = mrfp.firstEvent(time,demand,amplitude);
        label = event.cause; if label==0, label = cfg.nMode+2; end
        counts(rep,label) = counts(rep,label)+1;
        changed = demand; changed(:,1) = changed(:,1)/1.2;
        after = mrfp.firstEvent(time,changed,amplitude);
        newLabel = after.cause; if newLabel==0, newLabel = cfg.nMode+2; end
        transferCounts(label,newLabel,rep) = transferCounts(label,newLabel,rep)+1;
    end
    seconds(rep) = toc(timer);
    fprintf('%s independent MC: %d/%d\n',caseName,rep,batches);
    file = fopen(fullfile(folder,caseName+'_direct_mc_progress.json'),'w');
    fprintf(file,'%s',jsonencode(struct('completed',rep,'batches',batches))); fclose(file);
end
p = sum(counts,1)'/(n*batches); z = norminv(.975); total = n*batches;
center = (p+z^2/(2*total))/(1+z^2/total);
radius = z*sqrt(p.*(1-p)/total+z^2/(4*total^2))/(1+z^2/total);
report = table(names',p,center-radius,center+radius,sum(counts,1)', ...
    'VariableNames',{'category','estimate','WilsonLower95','WilsonUpper95','count'});
writetable(report,fullfile(folder,caseName+'_direct_mc.csv'));
flow = sum(transferCounts,3); [from,to] = ndgrid(names,names);
writetable(table(from(:),to(:),flow(:)/total,flow(:), ...
    'VariableNames',{'from','to','probability','count'}),fullfile(folder,caseName+'_direct_mc_transfer.csv'));
save(fullfile(folder,caseName+'_direct_mc.mat'),'cfg','n','batches','counts','transferCounts','seconds');
disp(report); fprintf('Seconds: %.2f\n',sum(seconds));
end
