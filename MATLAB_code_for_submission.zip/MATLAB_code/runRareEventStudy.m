function summary = runRareEventStudy(profile)
%runRareEventStudy Rare dynamic first passage with an independent defensive IS.
% Existing Gaussian component-mixture IS + defensive Gaussian shift in log A.
% No claim of originality for these importance-sampling ingredients.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","study"])} = "study"
end
root = fileparts(mfilename('fullpath')); oldPath = path;
cleanup = onCleanup(@() path(oldPath)); addpath(root);
nReplicate = 32; n = 2048; nOuter = 256; nInner = 64; dt = 0.005;
if profile=="smoke"
    nReplicate = 2; n = 8; nOuter = 4; nInner = 8; dt = 0.02;
end
folder = fullfile(root,'results','rare_'+profile);
if ~isfolder(folder), mkdir(folder); end
summary = table();
for name = ["sdof","building"]
    cfg = mrfp.makeConfig(name,"study"); cfg.dt = dt;
    cfg.amplitudeMedian = 0.12;
    if name=="building", cfg.amplitudeMedian = 0.18; end
    time = (0:dt:cfg.duration)';
    data = zeros(nReplicate,4); seconds = zeros(nReplicate,2);
    underflowCount = 0;
    for rep = 1:nReplicate
        clockConditional = tic;
        random = mrfp.sampleInputs(n,cfg.nInput,702011+rep);
        value = zeros(n,3);
        for i = 1:n
            s = mrfp.makeResponseSeries(cfg,random(i,:),zeros(1,cfg.nPathParameter+2));
            trajectory = mrfp.evaluateResponseSeries(s,time);
            record = max(abs(trajectory.demand),[],'all');
            lowRecord = max(0,max(abs(trajectory.demand)-trajectory.radius,[],'all'));
            highRecord = max(abs(trajectory.demand)+trajectory.radius,[],'all');
            value(i,:) = [mass(record,s.law),mass(lowRecord,s.law),mass(highRecord,s.law)];
        end
        data(rep,1:3) = mean(value,1);
        seconds(rep,1) = toc(clockConditional);
        clockIS = tic;
        outside = mrfp.sampleInputs(nOuter,4,801211+rep);
        valueIS = zeros(nOuter,1);
        for i = 1:nOuter
            % q(z)=0.2*phi(z)+0.8*phi(z-2), selected with an independent bit.
            useShift = outside(i,4)<sqrt(2)*erfinv(0.6);
            amplitudeNormal = outside(i,3)+2*useShift;
            amplitude = cfg.amplitudeMedian*exp(cfg.amplitudeLogSd*amplitudeNormal);
            weight = 1/(0.2+0.8*exp(2*amplitudeNormal-2));
            operator = amplitude*mrfp.makeGaussianOperator(cfg,outside(i,1:2),time);
            minBeta = 1/max(vecnorm(operator,2,2));
            if minBeta>35
                % Union bound <= 2*rows*phi(35)/35 < 1e-260 here.
                % This tiny omitted conditional probability is counted, not
                % confused with a mathematically zero failure probability.
                underflowCount = underflowCount+1;
                continue
            end
            r = mrfp.sampleGaussianUnion(operator,nInner,811411+1000*rep+i);
            valueIS(i) = weight*r.estimate;
        end
        data(rep,4) = mean(valueIS);
        seconds(rep,2) = toc(clockIS);
        fprintf('%s: rare event validation %d/%d\n',name,rep,nReplicate);
    end
    critical = tinv(0.975,nReplicate-1);
    center = mean(data,1); se = std(data,0,1)/sqrt(nReplicate);
    row = table(name,cfg.amplitudeMedian,nReplicate,n,nOuter,nInner,center(1),critical*se(1), ...
        center(2),center(3),center(4),critical*se(4),mean(seconds(:,1)), ...
        mean(seconds(:,2)),underflowCount, ...
        'VariableNames',{'caseName','amplitudeMedian','nReplicate','nConditional','nOuter','nInner','conditionalEstimate', ...
        'conditional95HalfWidth','timeLower','timeUpper','defensiveISEstimate', ...
        'defensiveIS95HalfWidth','conditionalSeconds','importanceSeconds','tailTruncationTerms'});
    summary = [summary;row]; %#ok<AGROW>
    save(fullfile(folder,name+'_rare.mat'),'cfg','data','seconds','n','nOuter','nInner','row');
end
writetable(summary,fullfile(folder,'summary.csv'));
disp(summary);
end

function probability = mass(record,law)
probability = 0;
if record>0
    probability = 0.5*erfc(-(log(record)+law.mu)/(sqrt(2)*law.sigma));
end
end
