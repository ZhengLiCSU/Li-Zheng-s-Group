function report = runAuditTubes()
%runAuditTubes Preselected fresh paths for the corrected 512-frequency model.
% Does not certify all samples or every design in a capacity curve.
root = fileparts(mfilename('fullpath'));
folder = fullfile(root,'results','robustness_study');
cfg = mrfp.makeBuilding16Config(NFrequency=512);
rows = zeros(16,7); histories = cell(16,1);
for rep = 1:8
    % First path of the first eight independent highest-budget reference batches.
    random = mrfp.sampleInputs(256,cfg.nInput,92046000+rep);
    base = mrfp.makeResponseSeries(cfg,random(1,:),zeros(1,cfg.nPathParameter+2));
    for changed = 0:1
        series = base;
        if changed, series = mrfp.scaleSeriesCapacity(base,1,1.2); end
        audit = mrfp.refineCauseBounds(series,InitialStep=.0025,Tolerance=.001,MaxRefinement=5);
        index = 2*rep-1+changed; histories{index} = audit.history;
        rows(index,:) = [rep,changed,audit.history.unresolvedMass(1), ...
            audit.history.unresolvedMass(end),audit.history.dt(end),audit.converged,audit.seconds];
    end
    fprintf('512-frequency selected tubes: %d/8 pairs\n',rep);
end
report = array2table(rows,'VariableNames',{'batch','afterCapacityChange','initialQ','finalQ','finalDt','converged','seconds'});
writetable(report,fullfile(folder,'building16_selected_tubes.csv'));
save(fullfile(folder,'building16_selected_tubes.mat'),'cfg','report','histories');
disp(report);
end
