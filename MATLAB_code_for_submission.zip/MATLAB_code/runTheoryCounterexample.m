function output = runTheoryCounterexample()
%runTheoryCounterexample Exact jump term missed by mean pathwise derivatives.
root = fileparts(mfilename('fullpath'));
folder = fullfile(root,'results','theory');
if ~isfolder(folder), mkdir(folder); end
p = [-0.2;0;0.2];
sigma = 0.45;
data = zeros(numel(p),7);
for i = 1:numel(p)
    value = p(i);
    phi = @(z) exp(-z.^2/2)/sqrt(2*pi);
    h = @(z) 0.5*erfc(-z/(sqrt(2)*sigma));
    f1 = integral(@(z) h(z+value).*phi(z),-value,Inf,'AbsTol',1e-12);
    f2 = 0.5*0.5*erfc(value/sqrt(2));
    interior = integral(@(z) phi((z+value)/sigma)/sigma.*phi(z),-value,Inf,'AbsTol',1e-12);
    jump = 0.5*phi(value);
    weak1 = integral(@(z) h(z+value).*z.*phi(z),-value,Inf,'AbsTol',1e-12);
    weak2 = integral(@(z) 0.5*z.*phi(z),-Inf,-value,'AbsTol',1e-12);
    data(i,:) = [f1,f2,interior,0,weak1,weak2,jump];
end
output = array2table([p,data],'VariableNames',{'design','cause1','cause2', ...
    'meanPathwise1','meanPathwise2','weakDerivative1','weakDerivative2','missingJumpMagnitude'});
writetable(output,fullfile(folder,'jump_derivative_counterexample.csv'));
disp(output);
end
