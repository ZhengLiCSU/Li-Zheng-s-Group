function startup_submission()
%STARTUP_SUBMISSION Add the package paths for the Structural Safety code.
root = fileparts(mfilename('fullpath'));
addpath(root);
addpath(fullfile(root,'code','robustness'));
fprintf('Structural Safety marked-first-passage package ready.\n');
fprintf('Use run_submission_smoke for a short regression check.\n');
end

