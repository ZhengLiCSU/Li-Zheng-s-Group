function output = runCapacityStudy(profile)
%runCapacityStudy All-mode capacity curves, paired effects and rescue shares.
% Performance thresholds change; this is not a cost-constrained optimum.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","study"])} = "study"
end
root = fileparts(mfilename('fullpath')); oldPath = path;
cleanup = onCleanup(@() path(oldPath)); addpath(root);
n = 128; nReplicate = 16; factors = [1,1.02,1.05,1.1,1.2,1.4]; dt = 0.01;
if profile=="smoke", n = 4; nReplicate = 2; factors = [1,1.05,1.2]; dt = 0.04; end
folder = fullfile(root,'results','capacity_'+profile);
if ~isfolder(folder), mkdir(folder); end
output = table();
for name = ["sdof","building"]
    cfg = mrfp.makeConfig(name,"study"); time = (0:dt:cfg.duration)';
    values = zeros(nReplicate,cfg.nMode,numel(factors),6);
    seconds = zeros(nReplicate,1);
    maxSystemMonotonicityViolation = 0; maxIdentityError = 0;
    for rep = 1:nReplicate
        timer = tic; random = mrfp.sampleInputs(n,cfg.nInput,4100211+rep);
        for sample = 1:n
            series = mrfp.makeResponseSeries(cfg,random(sample,:),zeros(1,cfg.nPathParameter+2));
            demand = mrfp.evaluateSeriesField(series,time);
            for target = 1:cfg.nMode
                scan = mrfp.capacityDesignPath(time,demand,series.law,target,factors);
                values(rep,target,:,:) = values(rep,target,:,:) + reshape(scan.metrics,1,1,numel(factors),6)/n;
                maxSystemMonotonicityViolation = max(maxSystemMonotonicityViolation,max(diff(scan.metrics(:,2))));
                identity = scan.metrics(:,1)-scan.metrics(:,2)-scan.metrics(:,5);
                targetIdentity = scan.metrics(:,3)-scan.metrics(:,4)-sum(scan.metrics(:,5:6),2);
                maxIdentityError = max(maxIdentityError,max(abs([identity;targetIdentity])));
            end
        end
        seconds(rep) = toc(timer);
        fprintf('%s: all-mode capacity curves %d/%d\n',name,rep,nReplicate);
    end
    report = summarize(cfg,factors,values);
    output = [output;report]; %#ok<AGROW>
    writetable(report,fullfile(folder,name+'_capacity.csv'));
    save(fullfile(folder,name+'_capacity.mat'),'cfg','time','n','nReplicate','factors', ...
        'values','seconds','maxSystemMonotonicityViolation','maxIdentityError','report');
    writeFigure(report,fullfile(folder,name+'_capacity.png'),cfg);
end
writetable(output,fullfile(folder,'summary.csv'));
end

function report = summarize(cfg,factors,values)
report = table(); n = size(values,1); critical = tinv(0.975,n-1);
for target = 1:cfg.nMode
    for k = 1:numel(factors)
        x = reshape(values(:,target,k,:),n,6);
        center = mean(x,1); rescue = x(:,5); substitute = x(:,6);
        rescueSE = std(rescue)/sqrt(n); substituteSE = std(substitute)/sqrt(n);
        ratio = NaN; ratioHalfWidth = NaN;
        status = "estimated";
        if factors(k)==1
            status = "identity_design";
        else
            if nnz(rescue)<4 || nnz(substitute)<4, status = "sparse"; end
            if all(rescue==0), rescueSE = NaN; end
            if all(substitute==0), substituteSE = NaN; end
            outflow = center(5)+center(6);
            if outflow>0
                ratio = center(5)/outflow;
                if isfinite(rescueSE) && isfinite(substituteSE)
                    influence = (rescue-ratio*(rescue+substitute))/outflow;
                    ratioHalfWidth = critical*std(influence)/sqrt(n);
                end
            end
        end
        ratioLow = NaN; ratioHigh = NaN;
        if isfinite(ratioHalfWidth)
            ratioLow = max(0,ratio-ratioHalfWidth); ratioHigh = min(1,ratio+ratioHalfWidth);
        end
        row = table(cfg.caseName,cfg.modeNames(target),factors(k),center(1),center(2), ...
            critical*std(x(:,2))/sqrt(n),center(3),center(4),center(5),critical*rescueSE, ...
            center(6),critical*substituteSE,ratio,ratioLow, ...
            ratioHigh,nnz(rescue),nnz(substitute),status, ...
            'VariableNames',{'caseName','targetMode','capacityMultiplier','systemBefore', ...
            'systemAfter','systemAfter95HalfWidth','targetBefore','targetAfter', ...
            'rescuedProbability','rescued95HalfWidth','substitutedProbability', ...
            'substituted95HalfWidth','rescueShare','rescueShare95Low','rescueShare95High', ...
            'rescueNonzeroReplicates','substituteNonzeroReplicates','status'});
        report = [report;row]; %#ok<AGROW>
    end
end
end

function writeFigure(report,file,cfg)
fig = figure('Visible','off','Color','w','Position',[100,100,1160,440]);
cleanup = onCleanup(@() close(fig)); tiledlayout(1,2,'Padding','compact');
nexttile; hold on;
for mode = cfg.modeNames
    r = report(report.targetMode==mode,:);
    errorbar(r.capacityMultiplier,r.rescuedProbability,r.rescued95HalfWidth,'-o', ...
        'DisplayName',mode,'LineWidth',1.2);
end
xlabel('Capacity / original capacity'); ylabel('System failure probability reduction');
title(cfg.caseName+": failure prevented",'Interpreter','none'); grid on;
legend('Location','best','Interpreter','none');
nexttile; hold on;
for mode = cfg.modeNames
    r = report(report.targetMode==mode & report.capacityMultiplier>1,:);
    errorbar(r.capacityMultiplier,r.rescueShare, ...
        r.rescueShare-r.rescueShare95Low,r.rescueShare95High-r.rescueShare,'-o', ...
        'DisplayName',mode,'LineWidth',1.2);
end
xlabel('Capacity / original capacity'); ylabel('Fraction of outflow becoming safe');
ylim([0,1]); grid on; title('Rescue share with approximate delta intervals');
legend('Location','best','Interpreter','none');
exportgraphics(fig,file,'Resolution',180);
end
