function summaries = runTransportStudy(profile)
%runTransportStudy Paired mode transport, weak sensitivities and SDM baseline.
arguments
    profile (1,1) string {mustBeMember(profile,["smoke","study"])} = "study"
end
root = fileparts(mfilename('fullpath'));
oldPath = path; cleanup = onCleanup(@() path(oldPath));
addpath(root);
n = 64; nReplicate = 16; nSurfaceOuter = 32; nSurfaceInner = 128;
dt = 0.005;
if profile=="smoke"
    n = 2; nReplicate = 2; nSurfaceOuter = 2; nSurfaceInner = 8; dt = 0.04;
end
folder = fullfile(root,'results','transport_'+profile);
if ~isfolder(folder), mkdir(folder); end
summaries = struct([]);
for name = ["sdof","building"]
    cfg = mrfp.makeConfig(name,"study");
    cfg.dt = dt;
    time = (0:dt:cfg.duration)';
    labels = [1:cfg.nMode,1:cfg.nMode];
    nCategory = cfg.nMode+2;
    probabilityRep = zeros(nReplicate,nCategory);
    weakRep = zeros(nCategory,2,nReplicate);
    weakLower = weakRep; weakUpper = weakRep;
    transportRep = zeros(nCategory,nCategory,nReplicate);
    lowerRep = transportRep;
    unresolvedRep = zeros(nReplicate,1);
    derivativeRep = zeros(nReplicate,1);
    surfaceRep = derivativeRep;
    scoreFDRep = zeros(nCategory,2,nReplicate);
    seconds = zeros(nReplicate,2);
    maxMarginalError = 0; maxCertificateViolation = 0; maxForbiddenFlow = 0;
    for rep = 1:nReplicate
        clockMain = tic;
        random = mrfp.sampleInputs(n,cfg.nInput,314011+rep);
        q = zeros(n,nCategory); qLow = q; qHigh = q;
        for k = 1:n
            series = mrfp.makeResponseSeries(cfg,random(k,:),zeros(1,cfg.nPathParameter+2));
            trajectory = mrfp.evaluateResponseSeries(series,time);
            changed = mrfp.scaleSeriesCapacity(series,1,1.05);
            newPath = mrfp.evaluateResponseSeries(changed,time);
            before = mrfp.integrateBranches(time,[trajectory.demand,-trajectory.demand],labels,series.law,StorePartition=true);
            after = mrfp.integrateBranches(time,[newPath.demand,-newPath.demand],labels,series.law,StorePartition=true);
            paired = mrfp.transportPartitions(before.partition,after.partition,series.law,nCategory);
            low = mrfp.boundFirstCause(time,trajectory.demand,trajectory.radius,series.law,StorePartition=true);
            high = mrfp.boundFirstCause(time,newPath.demand,newPath.radius,series.law,StorePartition=true);
            certificate = mrfp.transportPartitions(low.certifiedPartition,high.certifiedPartition,series.law,nCategory);
            q(k,:) = [before.uniqueCause(end,:),before.joint(end),1-before.failure(end)];
            qAfter = [after.uniqueCause(end,:),after.joint(end),1-after.failure(end)];
            qLow(k,:) = [low.lower(end,:),0,1-low.failureUpper(end)];
            qHigh(k,:) = [low.upper(end,:),low.unresolvedMassUpper(end),1-low.failureLower(end)];
            transportRep(:,:,rep) = transportRep(:,:,rep)+paired.matrix/n;
            lowerRep(:,:,rep) = lowerRep(:,:,rep)+certificate.matrix/n;
            unresolvedRep(rep) = unresolvedRep(rep)+certificate.unresolvedMass/n;
            maxMarginalError = max(maxMarginalError,max(abs(paired.beforeMarginal-q(k,:)')));
            maxMarginalError = max(maxMarginalError,max(abs(paired.afterMarginal-qAfter')));
            maxCertificateViolation = max(maxCertificateViolation,max(certificate.matrix-paired.matrix,[],'all'));
            forbidden = paired.matrix; forbidden(1,:) = 0; forbidden(1:nCategory+1:end) = 0;
            maxForbiddenFlow = max(maxForbiddenFlow,max(abs(forbidden),[],'all'));
            modeRecord = max(abs(trajectory.demand),[],1);
            derivative = mrfp.systemCapacityDerivative(modeRecord,1,series.law);
            derivativeRep(rep) = derivativeRep(rep)+derivative.right/n;
        end
        sd = [cfg.stiffnessLogSd,cfg.dampingLogSd];
        weakRep(:,:,rep) = mrfp.scoreSensitivity(q,random(:,1:2),sd,ones(n,1)/n);
        bounds = mrfp.boundScoreSensitivity(qLow,qHigh,random(:,1:2),sd,ones(n,1)/n);
        weakLower(:,:,rep) = bounds.lower; weakUpper(:,:,rep) = bounds.upper;
        % An exact-density finite difference is an independent algebraic check
        % of score differentiation; it is not a new dynamics evaluation.
        h = 0.002;
        for j = 1:2
            shift = h/sd(j);
            densityDifference = (exp(shift*random(:,j)-shift^2/2)- ...
                exp(-shift*random(:,j)-shift^2/2))/(2*h);
            scoreFDRep(:,j,rep) = q'*densityDifference/n;
        end
        probabilityRep(rep,:) = mean(q,1);
        seconds(rep,1) = toc(clockMain);
        clockSurface = tic;
        outside = mrfp.sampleInputs(nSurfaceOuter,3,401711+rep);
        estimates = zeros(nSurfaceOuter,1);
        selectedRows = false(numel(time)*cfg.nMode,1); selectedRows(1:numel(time)) = true;
        for k = 1:nSurfaceOuter
            operator = mrfp.makeGaussianOperator(cfg,outside(k,1:2),time);
            amplitude = cfg.amplitudeMedian*exp(cfg.amplitudeLogSd*outside(k,3));
            surface = mrfp.sampleGaussianSurface(amplitude*operator,selectedRows,nSurfaceInner,514011+rep*1000+k);
            estimates(k) = surface.estimate;
        end
        surfaceRep(rep) = mean(estimates);
        seconds(rep,2) = toc(clockSurface);
        fprintf('%s: paired transport and SDM %d/%d\n',name,rep,nReplicate);
    end
    output = writeOutputs(folder,cfg,probabilityRep,transportRep,lowerRep, ...
        unresolvedRep,weakRep,weakLower,weakUpper,scoreFDRep,derivativeRep,surfaceRep,seconds);
    summary = struct('caseName',name,'nPerReplicate',n,'nReplicate',nReplicate,'dt',dt, ...
        'meanPairedUnresolvedMass',mean(unresolvedRep), ...
        'marginalError',maxMarginalError,'certificateViolation',maxCertificateViolation, ...
        'forbiddenFlow',maxForbiddenFlow,'rescuedProbability',output.rescued, ...
        'substitutedProbability',output.substituted,'rescueShare',output.rescueShare, ...
        'conditionalSystemCapacityDerivative',mean(derivativeRep), ...
        'surfaceSystemCapacityDerivative',mean(surfaceRep));
    save(fullfile(folder,name+'_transport.mat'),'cfg','probabilityRep','transportRep', ...
        'lowerRep','unresolvedRep','weakRep','weakLower','weakUpper','scoreFDRep', ...
        'derivativeRep','surfaceRep','seconds','summary');
    summaries = [summaries;summary]; %#ok<AGROW>
end
file = fopen(fullfile(folder,'summary.json'),'w','n','UTF-8');
fileCleanup = onCleanup(@() fclose(file));
fprintf(file,'%s',jsonencode(summaries,'PrettyPrint',true));
disp(struct2table(summaries));
end

function output = writeOutputs(folder,cfg,probabilityRep,transportRep,lowerRep,unresolvedRep, ...
    weakRep,weakLower,weakUpper,scoreFDRep,derivativeRep,surfaceRep,seconds)
names = [cfg.modeNames,"joint","safe"]';
nReplicate = size(probabilityRep,1);
matrix = mean(transportRep,3); lower = mean(lowerRep,3);
upper = min(1,lower+mean(unresolvedRep));
% Independent randomized batches yield a valid, usually conservative fixed-
% budget Hoeffding envelope, separate from the descriptive t intervals.
batchLower = reshape(permute(lowerRep,[3,1,2]),nReplicate,[]);
batchUpper = min(1,batchLower+unresolvedRep);
honest = mrfp.boundedMeanEnvelope(batchLower,batchUpper,[zeros(1,numel(matrix));ones(1,numel(matrix))]);
[from,to] = ndgrid(names,names);
transport = table(from(:),to(:),matrix(:),lower(:),upper(:),honest.lower',honest.upper', ...
    'VariableNames',{'from','to','probability','timeLower','timeUpper','hoeffding95Lower','hoeffding95Upper'});
writetable(transport,fullfile(folder,cfg.caseName+'_transport.csv'));
weak = mean(weakRep,3); se = std(weakRep,0,3)/sqrt(nReplicate);
[category,parameter] = ndgrid(names,["log_stiffness","log_damping"]);
weakLow = mean(weakLower,3); weakHigh = mean(weakUpper,3);
finiteDensity = mean(scoreFDRep,3);
gradient = table(category(:),parameter(:),weak(:),se(:),weakLow(:),weakHigh(:),finiteDensity(:), ...
    'VariableNames',{'category','parameter','scoreDerivative','standardError', ...
    'timeLower','timeUpper','densityFiniteDifference'});
writetable(gradient,fullfile(folder,cfg.caseName+'_weak_sensitivity.csv'));
critical = tinv(0.975,nReplicate-1);
baseline = table(["Conditional system derivative";"Constrained Gaussian surfaces"], ...
    [mean(derivativeRep);mean(surfaceRep)], ...
    critical*[std(derivativeRep);std(surfaceRep)]/sqrt(nReplicate),mean(seconds,1)', ...
    'VariableNames',{'method','estimate','approximate95HalfWidth','secondsPerReplicate'});
writetable(baseline,fullfile(folder,cfg.caseName+'_surface_comparison.csv'));
rescued = matrix(1,end); substituted = sum(matrix(1,2:cfg.nMode));
rescueRep = squeeze(transportRep(1,end,:));
substituteRep = squeeze(sum(transportRep(1,2:cfg.nMode,:),2));
effect = table(["failure_prevented";"cause_changed"], ...
    [rescued;substituted],critical*[std(rescueRep);std(substituteRep)]/sqrt(nReplicate), ...
    'VariableNames',{'quantity','estimate','approximate95HalfWidth'});
writetable(effect,fullfile(folder,cfg.caseName+'_design_effect.csv'));
output = struct('rescued',rescued,'substituted',substituted, ...
    'rescueShare',rescued/max(realmin,rescued+substituted));
mrfp.writeTransportFigure(cfg,transportRep,folder);
end
