function report = runControlledSensitivityAudit(caseName,options)
%runControlledSensitivityAudit Zero-mean conditional controls for the building.
% q0 fixes only the scored independent normal input to zero. Conditional on
% all other variables E[q0*S]=E[q0*W_h]=0, even when cause labels jump.
arguments
    caseName (1,1) string {mustBeMember(caseName,["sdof","building16"])} = "building16"
    options.Main (1,1) logical = true
end
root = fileparts(mfilename('fullpath'));
folder = fullfile(root,'results','robustness_study');
audit = load(fullfile(folder,caseName+'_sensitivity.mat'));
cfg = audit.cfg; sd = [cfg.stiffnessLogSd,cfg.dampingLogSd];
time = (0:cfg.dt:cfg.duration)';
controlledScore = audit.score; controlledDensity = audit.density;
for rep = 1:audit.batches
    random = mrfp.sampleInputs(audit.n,cfg.nInput,91986000+rep);
    for j = 1:2
        fixed = random; fixed(:,j) = 0;
        base = mrfp.conditionalBatch(cfg,time,fixed);
        q0 = [1-base.probability(:,end),base.probability(:,1)];
        columns = (j-1)*2+(1:2);
        controlledScore(rep,columns) = controlledScore(rep,columns)-(q0'*(random(:,j)/sd(j))/audit.n)';
        for ell = 1:numel(audit.levels)
            weight = mrfp.gaussianLocationDifference(random(:,j),sd(j),audit.levels(ell));
            controlledDensity(rep,columns,ell) = controlledDensity(rep,columns,ell)-(q0'*weight/audit.n)';
        end
    end
end
critical = tinv(.975,audit.batches-1);
family = tinv(1-.05/(2*numel(audit.names)*numel(audit.levels)),audit.batches-1);
report = table();
for ell = 1:numel(audit.levels)
    for j = 1:numel(audit.names)
        delta = audit.value(:,j,ell)-controlledDensity(:,j,ell);
        a = table(audit.names(j),audit.levels(ell),mean(controlledScore(:,j)), ...
            critical*std(controlledScore(:,j))/sqrt(audit.batches), ...
            mean(audit.value(:,j,ell)),mean(controlledDensity(:,j,ell)),mean(delta), ...
            critical*std(delta)/sqrt(audit.batches),family*std(delta)/sqrt(audit.batches), ...
            'VariableNames',{'metric','step','controlledScore','scoreHalf95','dynamicDifference', ...
            'controlledDensity','pairedDifference','pairedHalf95','pairedFamilyHalf95'});
        report = [report;a]; %#ok<AGROW>
    end
end
writetable(report,fullfile(folder,caseName+'_controlled_sensitivity.csv'));
save(fullfile(folder,caseName+'_controlled_sensitivity.mat'),'cfg','audit','controlledScore','controlledDensity','report');
disp(report);
if ~options.Main, return; end
% Apply the same fixed conditional controls to the main probability batches.
reference = load(fullfile(folder,caseName+'_reference.mat'));
ell = numel(reference.levels); n = reference.levels(ell);
metricNames = ["system_d_logK","first_d_logK","system_d_logC","first_d_logC"];
indices = zeros(1,4);
for j = 1:4, indices(j) = find(reference.names==metricNames(j)); end
raw = reference.value(:,indices,ell); controlled = raw;
for rep = 1:reference.batches
    random = mrfp.sampleInputs(n,cfg.nInput,91926000+rep+10000*ell+100000);
    for j = 1:2
        fixed = random; fixed(:,j) = 0;
        base = mrfp.conditionalBatch(cfg,time,fixed);
        q0 = [1-base.probability(:,end),base.probability(:,1)];
        columns = (j-1)*2+(1:2);
        controlled(rep,columns) = controlled(rep,columns)-(q0'*(random(:,j)/sd(j))/n)';
    end
    fprintf('%s controlled sensitivity: main batch %d/%d\n',caseName,rep,reference.batches);
    file = fopen(fullfile(folder,caseName+'_controlled_progress.json'),'w');
    fprintf(file,'%s',jsonencode(struct('completed',rep,'batches',reference.batches))); fclose(file);
end
critical = tinv(.975,reference.batches-1);
main = table(metricNames',mean(raw,1)',(critical*std(raw,0,1)/sqrt(reference.batches))', ...
    mean(controlled,1)',(critical*std(controlled,0,1)/sqrt(reference.batches))', ...
    ((std(raw,0,1)./std(controlled,0,1)).^2)', ...
    'VariableNames',{'metric','rawEstimate','rawHalf95','estimate','halfWidth95','empiricalVarianceRatio'});
writetable(main,fullfile(folder,caseName+'_controlled_main.csv'));
save(fullfile(folder,caseName+'_controlled_main.mat'),'cfg','n','raw','controlled','main');
disp(main);
end
