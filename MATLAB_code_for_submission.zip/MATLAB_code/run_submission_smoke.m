function run_submission_smoke()
%RUN_SUBMISSION_SMOKE Run the short, deterministic MATLAB regression suite.
root = fileparts(mfilename('fullpath'));
startup_submission();
run_all_robustness_tests("verify");
if isfile(fullfile(root,'results','robustness_v2','test_results.csv'))
    fprintf('Smoke regression completed; see results/robustness_v2/test_results.csv.\n');
end
end

