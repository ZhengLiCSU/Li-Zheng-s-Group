Recorded ground motions and peak interstorey drift

These data accompany the recorded-motion comparison in Section 5.7. The test set contains 200 two-component records from 156 earthquakes. Records from 32 other earthquakes were used for calibration, one record per event. Each pair of horizontal components was scaled to four peak ground accelerations (0.30, 0.45, 0.65 and 0.90 g).

records.csv gives the ESM25 record, event, station and recording network. The role column identifies the calibration and test sets. The window_start_s and energy_fraction columns give the start time of the selected 16 s window and its fraction of the sum of squared accelerations. The window_pga_g column gives the peak resultant horizontal acceleration in that window before scaling, in units of g.

peak_drift.csv contains one row per record and target acceleration (pga_g). The scale column gives the multiplier applied to both horizontal components. LF_peak is the peak drift from the reduced model, NN_peak includes the learned residual, and HF_peak is the high-fidelity reference. All three are drift ratios. Multiply by 100 to express them as percentages.

test_predictions.csv reports the direct and calibrated results for the test records. Match rows to peak_drift.csv using record_id and pga_g. The lf and nn prefixes denote the reduced model and the same model with the learned residual. The cal columns give results after calibration. Columns ending in p015 and p020 refer to crossing the 1.5% and 2.0% drift limits. Direct values are crossing indicators (0 or 1). Calibrated values are crossing probabilities. Reliability at a given intensity is one minus the mean crossing probability across the 200 test records.

Ground-motion source

Cianetti, S., C. Mascandola, L. Faenza, C. Felicetta, E. Russo, D. Jozinović, J. Münchmeyer, L. Luzi and A. Michelini (2026). ESM25: A Machine-Learning-Ready Snapshot of the European Engineering Strong-Motion Database. INGV. https://doi.org/10.13127/ai/esm25

The station and event metadata in records.csv are drawn from ESM25 and distributed under CC BY-SA 4.0 (https://creativecommons.org/licenses/by-sa/4.0/). The network_registry and original_data_mediator columns identify the original providers. The acceleration windows and scale factors are those used in this study. The drift values are structural simulations driven by the recorded ground motions.
